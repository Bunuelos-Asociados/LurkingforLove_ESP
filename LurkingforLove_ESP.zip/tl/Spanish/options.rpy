﻿# TODO: Translation updated at 2026-10-08 15:32

translate Spanish strings:

    # game/options.rpy:15
    old "lurkingforlove"
    new "lurkingforlove"
    
    old "News Anchor"
    new "Presentadora de noticias"

