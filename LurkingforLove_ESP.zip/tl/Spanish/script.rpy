# TODO: Translation updated at 2026-10-08 15:32

# game/script.rpy:104
translate Spanish keepgoing_b023179f:

    # "The doorbell..."
    "El timbre..."

# game/script.rpy:105
translate Spanish keepgoing_9221fe7e:

    # "I rub my eyes and wipe away the dry crust."
    "Me froto los ojos y me quito las legañas secas."

# game/script.rpy:106
translate Spanish keepgoing_afcad272:

    # "Conciousness came flooding back to me as I lay on top of my sweaty bedsheets."
    "La consciencia volvió a mí de golpe mientras yacía sobre mis sábanas sudadas."

# game/script.rpy:107
translate Spanish keepgoing_73b5ba56:

    # "Texas is pretty different from where I lived before. I've been here for a few months now, but everything still feels new."
    "Texas es bastante diferente de donde vivía antes. He estado aquí durante unos meses, pero todo todavía se siente nuevo."

# game/script.rpy:108
translate Spanish keepgoing_a2a8870d:

    # "I attempt to slide myself off the bed, my legs almost putting me off balance from my drowsy state."
    "Intento salir de la cama, pero el sueño hace que casi pierda el equilibrio al ponerme de pie."

# game/script.rpy:109
translate Spanish keepgoing_3ab8bd16:

    # "As much as I'd like to continue relaxing under the covers, I still have errands to do today."
    "Por mucho que me gustaría seguir relajándome bajo las cobijas, todavía tengo mandados que hacer hoy."

# game/script.rpy:110
translate Spanish keepgoing_9d3bd02e:

    # "Hm, let's freshen up first..."
    "Mmm, primero voy a refrescarme..."

# game/script.rpy:113
translate Spanish keepgoing_9eb9b152:

    # "I relieve myself and brush my teeth afterwards. I squint at the mirror."
    "Hago mis necesidades y luego me cepillo los dientes. Entrecierro los ojos frente al espejo."

# game/script.rpy:114
translate Spanish keepgoing_8eef2f49:

    # "Ugh...I'm so tired I almost forgot who I was..."
    "Uf... tengo tanto sueño que casi se me olvida quién soy..."

# game/script.rpy:120
translate Spanish keepgoing_adee1cb1:

    # me "[playerName]."
    me "[playerName]."

# game/script.rpy:121
translate Spanish keepgoing_91f9867b:

    # me "Yup, that's me alright."
    me "Sí, soy yo, sin duda."

# game/script.rpy:147
translate Spanish continue_7d5c894c:

    # "I follow up with my usual facial routine. As I scrub my face, I hear the doorbell again."
    "Continúo con mi rutina habitual de cuidado facial. Mientras me froto la cara, vuelvo a oír el timbre."

# game/script.rpy:148
translate Spanish continue_f69eb1a8:

    # me "Ugh..."
    me "Ugh..."

# game/script.rpy:151
translate Spanish continue_757e6bf3:

    # "I go downstairs and make my way through the living room to reach the front door."
    "Bajo las escaleras y atravieso la sala de estar hasta la puerta principal."

# game/script.rpy:162
translate Spanish peephole_521e62c9:

    # "Oh, it's him again."
    "Oh, es él de nuevo."

# game/script.rpy:167
translate Spanish opendoor_19104e2b:

    # u "Hi [playerName]! I got your mail by mistake again."
    u "¡Hola, [playerName]! Me llegó tu correo por error otra vez."

# game/script.rpy:169
translate Spanish opendoor_266f48de:

    # u "Pretty badass name you got there."
    u "Vaya nombre más rudo tienes."

# game/script.rpy:170
translate Spanish opendoor_d77c3822:

    # me "Dang, that's the fifth time this month! I wonder what's going on at the post office..."
    me "¡Caray, es la quinta vez este mes! Me pregunto qué pasa en la oficina de correos..."

# game/script.rpy:171
translate Spanish opendoor_fb040856:

    # "This guy is my next door neighbor. Honestly, I don't know anything about him, other than that I've seen him work at a retail store close by."
    "Este tipo es mi vecino de al lado. Sinceramente, no sé nada de él, aparte de que lo he visto trabajar en una tienda cercana."

# game/script.rpy:172
translate Spanish opendoor_a074d316:

    # me "Thanks again for bringing me my mail, um..."
    me "Gracias de nuevo por traerme mi correo, um ..."

# game/script.rpy:173
translate Spanish opendoor_ae2ea233:

    # "Oh no...it's happening again."
    "Oh no ... está sucediendo de nuevo."

# game/script.rpy:174
translate Spanish opendoor_e6dfd6f3:

    # me "Uhhhhh......."
    me "Uhhhhh ......."

# game/script.rpy:186
translate Spanish incorrectname_772d6ecb:

    # j "Jacob."
    j "Jacob."

# game/script.rpy:187
translate Spanish incorrectname_066c4cc4:

    # me "Oh, sorry Jacob. I'm not the best with names, haha."
    me "Ay, perdona, Jacob. Se me dan mal los nombres, jaja."

# game/script.rpy:194
translate Spanish correctname_b4fa3fc0:

    # j "..."
    j "..."

# game/script.rpy:196
translate Spanish correctname_e0a846ab:

    # j "Uh, yeah...here ya go."
    j "Eh, sí... toma."

# game/script.rpy:201
translate Spanish mailtime_8dd29208:

    # "After he hands over the package and envelopes, I place my mail on my coffee table to open, but then I noticed..."
    "Después de que entrega el paquete y los sobres, dejo mi correo en la mesa de centro para abrirlo luego, pero entonces me doy cuenta de que..."

# game/script.rpy:204
translate Spanish mailtime_8a98fc1d:

    # "Jacob is still standing there at my doorway."
    "Jacob todavía está parado allí en mi puerta."

# game/script.rpy:215
translate Spanish byestinky_e4faedf3:

    # me "Bye Jacob, thanks again."
    me "Adiós Jacob, gracias de nuevo."

# game/script.rpy:216
translate Spanish byestinky_2f0ddd4f:

    # "He stares at me, still lingering by the doorway."
    "Me mira fijamente, todavía rondando junto a la puerta."

# game/script.rpy:217
translate Spanish byestinky_95e15669:

    # j "You're welcome, [playerName]."
    j "De nada, [playerName]."

# game/script.rpy:219
translate Spanish byestinky_1912921e:

    # j "See you 'round."
    j "Nos vemos por ahí."

# game/script.rpy:227
translate Spanish jacobchat1_7ae9f1fb:

    # me "So Jacob, how's your day been going?"
    me "Entonces, Jacob, ¿cómo va tu día?"

# game/script.rpy:229
translate Spanish jacobchat1_6fdc9a43:

    # j "Oh, uh...I've been doing ok."
    j "Ah, eh... he estado bien."

# game/script.rpy:231
translate Spanish jacobchat1_70fbeb9a:

    # j "I've been needing to check out this one movie for a while..."
    j "Llevo un tiempo queriendo ver una película..."

# game/script.rpy:232
translate Spanish jacobchat1_f8dc84d7:

    # j "It's called 'Revenge Of The Jackalopes'."
    j "Se llama 'Revenge of the Jackalopes'."

# game/script.rpy:233
translate Spanish jacobchat1_36737d47:

    # me "Heh, it sounds like one of those cheesy old horror films!"
    me "¡Je, suena a una de esas viejas películas de terror cursis!"

# game/script.rpy:234
translate Spanish jacobchat1_54b66a14:

    # j "Yeah, it's an obscure one from the 1950s."
    j "Sí, es una bastante desconocida de los años 50."

# game/script.rpy:235
translate Spanish jacobchat1_0b84f63f:

    # j "It was directed by the same guy who made the movie 'Invasion Of The Shmangies'."
    j "Fue dirigido por el mismo tipo que hizo la película 'Invasion of the Shmangies'."

# game/script.rpy:236
translate Spanish jacobchat1_e863e091:

    # j "He also directed the movie 'Attack Of The Blorbo Worms'. I liked that one."
    j "También dirigió la película 'Attack of the Blorbo Worms'. Esa me gustó."

# game/script.rpy:237
translate Spanish jacobchat1_3bef7ec1:

    # "I definitely don't recognize ANY of these movies he's talking about."
    "Definitivamente no reconozco ninguna de estas películas de las que está hablando."

# game/script.rpy:238
translate Spanish jacobchat1_f56a31f6:

    # me "Those sound like pretty interesting movies! Well, I gotta get back to-{w=0.2}{nw}"
    me "¡Esas suenan como películas bastante interesantes! Bueno, tengo que volver a-{w=0.2}{nw}"

# game/script.rpy:239
translate Spanish jacobchat1_adc9ffa6:

    # j " 'Invasion Of The Shmangies' had it's positives too, but I felt like the writing in 'Attack Of The Blorbo Worms' was a little more consistent."
    j " 'Invasion of the Shmangies' también tenía sus positivos, pero sentí que el guion de 'Attack of the Blorbo Worms' era un poco más consistente."

# game/script.rpy:240
translate Spanish jacobchat1_926822d1:

    # me "Cool, uhh-{w=0.2}{nw}"
    me "Genial, uhh-{w=0.2}{nw}"

# game/script.rpy:241
translate Spanish jacobchat1_8ab1b3ea:

    # j " I think if they balanced more of the pacing and change some of the dialogue, the details of why the Shmangies were invading would of made more sense."
    j " Creo que si hubieran equilibrado mejor el ritmo y cambiado parte del diálogo, los motivos de la invasión de los Shmangies habrían tenido más sentido."

# game/script.rpy:242
translate Spanish jacobchat1_34b72e25:

    # me "Hey Jacob."
    me "Oye, Jacob."

# game/script.rpy:243
translate Spanish jacobchat1_3d5f5ccb:

    # j "Hmm?"
    j "¿Mmm?"

# game/script.rpy:244
translate Spanish jacobchat1_7859a5fb:

    # me "Your movie knowledge is great, but I gotta run some errands today, so..."
    me "Sabes un montón de cine, pero hoy tengo que hacer unos mandados, así que..."

# game/script.rpy:246
translate Spanish jacobchat1_c9f41b7b:

    # j "O-Oh! Uh, sorry 'bout my ramblin'. Didn't mean to hold you up!"
    j "¡O-oh! Eh, perdona por irme por las ramas. ¡No quería entretenerte!"

# game/script.rpy:247
translate Spanish jacobchat1_a27a3906:

    # me "It's alright, bye Jacob!"
    me "¡Está bien, adiós Jacob!"

# game/script.rpy:249
translate Spanish jacobchat1_aeec7a9e:

    # j "Goodbye [playerName]."
    j "Adiós [playerName]."

# game/script.rpy:252
translate Spanish jacobchat1_1912921e:

    # j "See you 'round."
    j "Nos vemos por ahí."

# game/script.rpy:257
translate Spanish errands_77cccd89:

    # "I close my door and focus back to my mail. Let's see here..."
    "Cierro mi puerta y vuelvo a concentrarme en mi correo. Veamos aquí ..."

# game/script.rpy:258
translate Spanish errands_a1c1471f:

    # "Bills are in the envelopes, but my package is something I've been waiting for!"
    "Las facturas están en los sobres, ¡pero mi paquete es algo que he estado esperando!"

# game/script.rpy:261
translate Spanish errands_7df71f73:

    # "I open the box and..."
    "Abro la caja y ..."

# game/script.rpy:264
translate Spanish errands_a9bf49a5:

    # "Yes! My new band T-shirt came!"
    "¡Sí! ¡Llegó mi nueva camiseta de banda!"

# game/script.rpy:265
translate Spanish errands_b1efa63e:

    # "I got into this band recently called 'Bewitched Blood', they played locally here a few months ago, but they weren't selling merch at the time."
    "Hace poco me metí en una banda llamada 'Bewitched Blood'; tocaron por aquí hace unos meses, pero entonces no vendían merchandising."

# game/script.rpy:266
translate Spanish errands_4bf45973:

    # "Looks like they got popular pretty fast, now their shirts are almost out of stock on their website."
    "Parece que se volvieron populares bastante rápido, ahora sus camisas están casi agotadas en su sitio web."

# game/script.rpy:267
translate Spanish errands_f86e9755:

    # "I'll HAVE to wear this out soon! Maybe I'll find some other fans in the area!"
    "¡TENGO que ponérmela pronto para salir! ¡A ver si encuentro a otros fans de la zona!"

# game/script.rpy:269
translate Spanish errands_3bd3fcc2:

    # "But for now, I gotta catch up with work a bit."
    "Pero por ahora, tengo que ponerme al día con el trabajo un poco."

# game/script.rpy:271
translate Spanish errands_15fb20b4:

    # "Having a remote online job has it's pros and cons. It's nice I get to work from home, but sitting down all day does take a toll on my back."
    "Tener un trabajo remoto tiene sus pros y sus contras. Está bien poder trabajar desde casa, pero pasarme todo el día sentad[letra] me pasa factura en la espalda."

# game/script.rpy:272
translate Spanish errands_5cc2b780:

    # "Most of it involves sending documents back and forth, and once in a while having to print them. I wish ink cartridges weren't so expensive..."
    "La mayor parte implica enviar documentos de un lado a otro, y de vez en cuando tengo que imprimirlos. Desearía que los cartuchos de tinta no fueran tan caros ..."

# game/script.rpy:276
translate Spanish errands_d7b1b086:

    # "Ugh...I can feel my stomach growl."
    "Ugh... me ruge el estómago."

# game/script.rpy:277
translate Spanish errands_3c840012:

    # "I've managed to get quite a good chunk of work done for today."
    "He conseguido adelantar buena parte del trabajo de hoy."

# game/script.rpy:278
translate Spanish errands_1584dd69:

    # "My fridge has been nearly cleaned out for a while, it's about time I go get some groceries."
    "Mi refrigerador lleva un tiempo casi vacío; ya va siendo hora de que vaya a comprar comida."

# game/script.rpy:280
translate Spanish errands_9c9948de:

    # "I hop into my car and went to the nearby market."
    "Me subo a mi auto y voy al mercado cercano."

# game/script.rpy:286
translate Spanish errands_933e80b6:

    # "I grab a cart and make my way through each aisle."
    "Agarro un carrito y recorro cada pasillo."

# game/script.rpy:287
translate Spanish errands_3a23ea9f:

    # "I get some canned foods, some pastas, and a few of my favorite snacks."
    "Compro unas latas de conserva, algo de pasta y algunos de mis snacks favoritos."

# game/script.rpy:288
translate Spanish errands_82de7e79:

    # "As I pass by the meat section, I see a familiar figure."
    "Al pasar por la sección de carne, veo una figura familiar."

# game/script.rpy:289
translate Spanish errands_696a4d88:

    # "It's Jacob. He seems to be deep in thought."
    "Es Jacob. Parece estar sumido en sus pensamientos."

# game/script.rpy:298
translate Spanish leavehimalone_5d12a873:

    # "I think I'll leave him be, he looks focused on that fish fillet."
    "Creo que lo dejaré tranquilo, parece muy concentrado en ese filete de pescado."

# game/script.rpy:299
translate Spanish leavehimalone_cc27dc18:

    # "I grab a few more items and prepare for check out."
    "Agarro unos cuantos artículos más y me preparo para pasar por caja."

# game/script.rpy:303
translate Spanish jacobchat2_c3556857:

    # "I stand a bit closer to the meats and catch my neighbor's attention pretty quickly."
    "Me quedo un poco más cerca de las carnes y llamo la atención de mi vecino bastante rápido."

# game/script.rpy:305
translate Spanish jacobchat2_4b57e299:

    # j "Well howdy [playerName], nice seeing you again so soon!"
    j "¡Vaya, hola, [playerName]! ¡Qué gusto verte otra vez tan pronto!"

# game/script.rpy:307
translate Spanish jacobchat2_0b219440:

    # me "Hello again! Just here picking up some groceries, I'm WAY overdue."
    me "¡Hola otra vez! Vengo a hacer la compra, me tocaba desde hace siglos."

# game/script.rpy:308
translate Spanish jacobchat2_f8d96b75:

    # "During the brief pause of our conversation, I scan over the various shades of red behind the glass."
    "Durante la breve pausa de nuestra conversación, recorro con la mirada los distintos tonos de rojo tras la vitrina."

# game/script.rpy:309
translate Spanish jacobchat2_87fe4ffc:

    # "Jacob seems to be staring intently at the fish fillets."
    "Jacob parece estar mirando atentamente los filetes de pescado."

# game/script.rpy:310
translate Spanish jacobchat2_4bae11e0:

    # me "So Jacob, you like seafood?"
    me "Entonces Jacob, ¿te gustan los mariscos?"

# game/script.rpy:312
translate Spanish jacobchat2_8c72608a:

    # j "I LOVE seafood."
    j "Me ENCANTAN los mariscos."

# game/script.rpy:314
translate Spanish jacobchat2_a8e9f449:

    # j "I've been in the mood for salmon lately."
    j "Últimamente se me antoja salmón."

# game/script.rpy:315
translate Spanish jacobchat2_ec7db11d:

    # "He fidgets in his spot for a moment."
    "Se inquieta en su lugar por un momento."

# game/script.rpy:317
translate Spanish jacobchat2_d1234512:

    # j "Hey uh, I plan on cooking the salmon tonight and I was wonderin'...maybe you wanna come over for dinner?"
    j "Oye, eh... esta noche pensaba cocinar el salmón y me preguntaba... ¿quizá te gustaría venir a cenar?"

# game/script.rpy:318
translate Spanish jacobchat2_672eed00:

    # j "I cook so much that I always have leftovers, so it'd be nice to share this with someone else."
    j "Cocino tanto que siempre tengo sobras, por lo que sería bueno compartir esto con otra persona."

# game/script.rpy:321
translate Spanish jacobchat2_bdf4957d:

    # j "You can join me for movie night too while we eat together."
    j "También puedes unirte a mí para la noche de cine mientras comemos juntos."

# game/script.rpy:323
translate Spanish jacobchat2_1477c30e:

    # j "I was gonna watch a movie tonight called 'Revenge Of The Jackalopes'. It's an obscure film from the 1950s I've been wantin' to check out. We can watch it while we eat."
    j "Iba a ver una película esta noche llamada 'Revenge of the Jackalopes'. Es una película poco conocida de los años 50 que tenía ganas de ver. Podemos verla mientras comemos."

# game/script.rpy:335
translate Spanish acceptjackalope_a6c810fc:

    # "This guy is offering free dinner AND a movie?"
    "¿Este tipo ofrece una cena gratis y una película?"

# game/script.rpy:336
translate Spanish acceptjackalope_5a164fdc:

    # "Honestly, I'll take it. Now I don't have to cook for myself tonight!"
    "La verdad, acepto. ¡Así no tengo que cocinar para mí esta noche!"

# game/script.rpy:337
translate Spanish acceptjackalope_1087c754:

    # "Plus, he seems like a nice guy. I wouldn't mind getting to know him more."
    "Además, parece un buen tipo. No me importaría conocerlo más."

# game/script.rpy:338
translate Spanish acceptjackalope_943fc8cb:

    # j "That's great! How does 6:00 PM sound? I'll be sure to have the salmon done before you get here."
    j "¡Genial! ¿Qué te parecen las 6:00 p. m.? Me aseguraré de tener el salmón listo antes de que llegues."

# game/script.rpy:339
translate Spanish acceptjackalope_ceb9b0bd:

    # me "Yeah sounds good! I'll see you then!"
    me "¡Sí, suena bien! ¡Te veré entonces!"

# game/script.rpy:346
translate Spanish nojackalope_4910aea1:

    # me "Sorry Jacob, I'm gonna be a little busy tonight. Maybe next time?"
    me "Lo siento, Jacob, voy a estar un poco ocupad[letra] esta noche. ¿Quizá la próxima vez?"

# game/script.rpy:347
translate Spanish nojackalope_10fc701e:

    # "I feel bad for lying. I had absolutely NO plans for anything other than cooking my own dinner and just relaxing."
    "Me siento mal por mentir. No tenía absolutamente ningún plan para nada más que cocinar mi propia cena y simplemente relajarme."

# game/script.rpy:348
translate Spanish nojackalope_bdb51633:

    # "But...I barely know this guy."
    "Pero ... apenas conozco a este tipo."

# game/script.rpy:349
translate Spanish nojackalope_e7eb75b9:

    # j "I see."
    j "Ya veo."

# game/script.rpy:353
translate Spanish nojackalope_c226053d:

    # j "Well, just know you're always welcome to stay over. I gotta go back to shoppin' now."
    j "Bueno, ten presente que siempre eres bienvenid[letra] en mi casa. Tengo que volver a mis compras."

# game/script.rpy:354
translate Spanish nojackalope_08f929a1:

    # me "Ok, thanks Jacob. See you later."
    me "Ok, gracias Jacob. Hasta luego."

# game/script.rpy:360
translate Spanish backhome1_1db171a4:

    # "I pay for my groceries, pack them into my car and drive home."
    "Pago la compra, la guardo en el auto y conduzco a casa."

# game/script.rpy:364
translate Spanish backhome1_022187f7:

    # "After putting all my groceries away, I let myself have a light snack so I can save my appetite for later."
    "Después de guardar todo, me permito picar algo ligero para no quitarme el apetito de más tarde."

# game/script.rpy:365
translate Spanish backhome1_eb8dcaa7:

    # "In the meantime, I'll just catch up with one of my current TV shows."
    "Mientras tanto, me pondré al día con uno de mis programas de televisión actuales."

# game/script.rpy:368
translate Spanish backhome1_6b90d417:

    # "Looks like it's 6:00 PM now, I'll start heading over to Jacob's house."
    "Parece que son las 6:00 pm ahora, comenzaré a dirigirme a la casa de Jacob."

# game/script.rpy:372
translate Spanish backhome1_56766d82:

    # "After putting my groceries away, I leave out the ingredients I need to make myself some dinner."
    "Después de guardar mis comestibles, dejo a mano los ingredientes que necesito para prepararme la cena."

# game/script.rpy:373
translate Spanish backhome1_66cbaf32:

    # "I'm gonna make a nice classic tonight: Spaghetti and meatballs!"
    "Voy a hacer un buen clásico esta noche: ¡espagueti y albóndigas!"

# game/script.rpy:378
translate Spanish stalked1_e8433c80:

    # "I wash my hands and get ready to cook."
    "Me lavo las manos y me preparo para cocinar."

# game/script.rpy:379
translate Spanish stalked1_e639833c:

    # "I add my favorite seasonings to the meat and roll them up into decently sized balls."
    "Agrego mis condimentos favoritos a la carne y formo bolas de buen tamaño."

# game/script.rpy:380
translate Spanish stalked1_cd0a097b:

    # "Hehe...balls..."
    "Jeje ... bolas ..."

# game/script.rpy:381
translate Spanish stalked1_83d70235:

    # "Now I just gotta wait until they're done baking in the oven."
    "Ahora solo me queda esperar a que se horneen."

# game/script.rpy:383
translate Spanish stalked1_17e2999b:

    # "After boiling the pasta, the meatballs are done and ready to be added to the sauce!"
    "¡Después de hervir la pasta, las albóndigas están hechas y están listas para agregarse a la salsa!"

# game/script.rpy:384
translate Spanish stalked1_a6966796:

    # "I make myself a plate and look outside my kitchen window."
    "Me sirvo un plato y miro por la ventana de la cocina."

# game/script.rpy:385
translate Spanish stalked1_02287e79:

    # "Wow, it's already dark out. This feels like a good time to put on a scary movie."
    "Vaya, ya oscureció. Es un buen momento para poner una película de miedo."

# game/script.rpy:387
translate Spanish stalked1_31fdf2a7:

    # "I sit myself down and turn on the TV."
    "Me siento y enciendo la televisión."

# game/script.rpy:388
translate Spanish stalked1_1940e960:

    # "Searching through my streaming service, I find a horror film that catches my eye."
    "Busco en mi servicio de streaming y encuentro una película de terror que me llama la atención."

# game/script.rpy:389
translate Spanish stalked1_ca7884cf:

    # "Hmm, let's see here...'Return Of The Rat People' sounds interesting, if not a little cheesy."
    "Mmm, a ver... 'Return Of The Rat People' suena interesante, aunque un poco cursi."

# game/script.rpy:390
translate Spanish stalked1_9834821e:

    # "I put on the film and start chowing down on my spaghetti."
    "Pongo la película y empiezo a zamparme el espagueti."

# game/script.rpy:391
translate Spanish stalked1_62739e2f:

    # "Looks like the plot is about a laboratory that secretly experimented on people."
    "Parece que la trama va de un laboratorio que experimentaba en secreto con personas."

# game/script.rpy:392
translate Spanish stalked1_c8662628:

    # "The test subjects are injected with rat DNA and are turned into angry rodent mutants."
    "A los sujetos de prueba les inyectan ADN de rata y se convierten en mutantes roedores enojados."

# game/script.rpy:393
translate Spanish stalked1_a6cccee0:

    # "The masks they used for the actors are actually pretty detailed."
    "Las máscaras que usaron para los actores son bastante detalladas."

# game/script.rpy:394
translate Spanish stalked1_2b12d76d:

    # "For a 1950s B-movie, it's actually not that bad."
    "Para ser una película de serie B de los años 50, en realidad no está tan mal."

# game/script.rpy:400
translate Spanish stalked1_a20cefa7:

    # "..."
    "..."

# game/script.rpy:401
translate Spanish stalked1_c9906473:

    # "...What was that?"
    "...¿Qué fue eso?"

# game/script.rpy:402
translate Spanish stalked1_a20cefa7_1:

    # "..."
    "..."

# game/script.rpy:403
translate Spanish stalked1_2ae7b413:

    # "I can't tell if it's just my imagination, or..."
    "No puedo decir si es solo mi imaginación, o ..."

# game/script.rpy:411
translate Spanish backyard_086abc35:

    # "I get up from my spot, bringing my phone with me as a flashlight."
    "Me levanto, llevando el teléfono como linterna."

# game/script.rpy:413
translate Spanish backyard_5b40ca1f:

    # "I shine my light outside where I stood."
    "Apunto la luz hacia fuera, hacia donde estaba."

# game/script.rpy:414
translate Spanish backyard_16c36287:

    # me "Hello?"
    me "¿Hola?"

# game/script.rpy:415
translate Spanish backyard_9850f53c:

    # "Nothing."
    "Nada."

# game/script.rpy:416
translate Spanish backyard_4cf98ee6:

    # "I look around a bit more to the yard next to me."
    "Miro un poco más hacia el patio de al lado."

# game/script.rpy:418
translate Spanish backyard_b094e86a:

    # "It's darker over here. My neighbor's porch light must be broken."
    "Es más oscuro por aquí. La luz del porche de mi vecino debe estar rota."

# game/script.rpy:419
translate Spanish backyard_71e806db:

    # "It's probably just the raccoons."
    "Probablemente sean solo los mapaches."

# game/script.rpy:420
translate Spanish backyard_ec546310:

    # "I really don't see anything else out here other than the trees and fences."
    "Realmente no veo nada más aquí que no sean los árboles y las cercas."

# game/script.rpy:424
translate Spanish staaay_06218d45:

    # "No...I think the horror film is just getting to me..."
    "No ... Creo que la película de terror me está afectando ..."

# game/script.rpy:425
translate Spanish staaay_a873af91:

    # "I'm sure it's just some raccoons or something."
    "Estoy segur[letra] de que son solo unos mapaches o algo así."

# game/script.rpy:426
translate Spanish staaay_2c9062ee:

    # "It's getting pretty late anyways. I'll just use the bathroom real quick and clean up."
    "De todos modos se está haciendo tarde. Voy un momento al baño y me aseo."

# game/script.rpy:436
translate Spanish stolenmeatball_6371078a:

    # "I grab my plate and make my way towards the kitchen."
    "Agarro mi plato y me dirijo hacia la cocina."

# game/script.rpy:438
translate Spanish stolenmeatball_388758e2:

    # "I put my dish into the sink and turn on the water."
    "Dejo el plato en el fregadero y abro el agua."

# game/script.rpy:439
translate Spanish stolenmeatball_441730b1:

    # "Rinsing the sauce off my plate makes it easier to wash later."
    "Enjuagar la salsa de mi plato hace que sea más fácil lavar más tarde."

# game/script.rpy:440
translate Spanish stolenmeatball_37219ba3:

    # "Then I make my way upstairs to my bedroom."
    "Luego me subo a mi habitación."

# game/script.rpy:442
translate Spanish stolenmeatball_72068a62:

    # "As I tuck myself in, it was hard to close my eyes."
    "Mientras me arropo, me cuesta cerrar los ojos."

# game/script.rpy:443
translate Spanish stolenmeatball_cafa87fc:

    # "Maybe I should take a break from horror movies for a while..."
    "Tal vez debería tomar un descanso de las películas de terror por un tiempo ..."

# game/script.rpy:452
translate Spanish jackalope_7d4fc3da:

    # "Next to my house was Jacob's bungalow."
    "Al lado de mi casa estaba el bungalow de Jacob."

# game/script.rpy:453
translate Spanish jackalope_f9645456:

    # "Once in a while I do see him sitting on his patio chair. Sometimes he'll even wave to me after I come home."
    "De vez en cuando lo veo sentado en su silla de patio. A veces incluso me saluda cuando llego a casa."

# game/script.rpy:455
translate Spanish jackalope_d9120580:

    # "I knock on his door."
    "Llamo a su puerta."

# game/script.rpy:456
translate Spanish jackalope_b55745b2:

    # "I hear some clicking and budging until..."
    "Oigo varios clics y algo que se mueve, hasta que ..."

# game/script.rpy:458
translate Spanish jackalope_3ce49841:

    # j "[playerName]? Please, come on in!"
    j "¿[playerName]? ¡Por favor, pasa!"

# game/script.rpy:461
translate Spanish jackalope_6592739d:

    # j "Make yourself at home, get cozy on the couch if you'd like."
    j "Siéntete como en casa, ponte cómod[letra] en el sofá si quieres."

# game/script.rpy:462
translate Spanish jackalope_173778f4:

    # "I scan around the small living room. His modern TV sticks out from the rustic appearance of everything else."
    "Recorro con la mirada la pequeña sala. Su televisor moderno desentona con el aspecto rústico del resto."

# game/script.rpy:463
translate Spanish jackalope_908fb3aa:

    # "Also, I see a fishtank!"
    "¡Además, veo una pecera!"

# game/script.rpy:464
translate Spanish jackalope_0ca9f723:

    # j "I know I said the salmon was gonna be done before you get here, but I ended up forgetting one of the ingredients, so I had to make an extra trip back to the store."
    j "Sé que dije que el salmón estaría listo antes de que llegaras, pero me olvidé de un ingrediente, así que tuve que hacer un viaje extra de regreso a la tienda."

# game/script.rpy:465
translate Spanish jackalope_c94ffa45:

    # me "Dang, that must of been pretty annoying."
    me "Vaya, eso debió de ser bastante molesto."

# game/script.rpy:466
translate Spanish jackalope_7282cca2:

    # j "Yeah, but it was worth it. I wanted to make sure everything was perfect..."
    j "Sí, pero valió la pena. Quería asegurarme de que todo fuera perfecto ..."

# game/script.rpy:469
translate Spanish jackalope_a531a188:

    # j "...for you."
    j "...para ti."

# game/script.rpy:470
translate Spanish jackalope_e506abc5:

    # "Suddenly, the kitchen timer went off."
    "De repente, sonó el temporizador de la cocina."

# game/script.rpy:472
translate Spanish jackalope_28fed1c4:

    # "The aroma of cooked fish filled the room."
    "El aroma de pescado cocido llenó la habitación."

# game/script.rpy:474
translate Spanish jackalope_80d38848:

    # j "It's just about done now! Let me set up our plates..."
    j "¡Ya casi está! Déjame servir los platos ..."

# game/script.rpy:477
translate Spanish jackalope_0420710a:

    # "He walked over to his small kitchen and took out the salmon from the oven."
    "Se acercó a su pequeña cocina y sacó el salmón del horno."

# game/script.rpy:478
translate Spanish jackalope_5feb77cd:

    # "The aroma is even stronger now, and my stomach growls in response."
    "El aroma es aún más fuerte ahora, y mi estómago gruñe en respuesta."

# game/script.rpy:479
translate Spanish jackalope_d0d2f260:

    # j "Heh heh, SOMEONE'S hungry! I can hear you all the way from here!"
    j "¡Je je, alguien tiene hambre! ¡Puedo escucharte desde aquí!"

# game/script.rpy:480
translate Spanish jackalope_5d02c9ab:

    # "Jacob comes over to the couch and sits next to me, handing over my plate."
    "Jacob se acerca al sofá y se sienta a mi lado, entregando mi plato."

# game/script.rpy:483
translate Spanish jackalope_9d81ab78:

    # me "Thanks!"
    me "¡Gracias!"

# game/script.rpy:484
translate Spanish jackalope_2a940da3:

    # "My food looks like it came straight out of one of those fancy cooking magazines."
    "Parece que mi comida salió directamente de una de esas elegantes revistas de cocina."

# game/script.rpy:485
translate Spanish jackalope_642599f5:

    # "It looks good, but the REAL question is does it TASTE good?"
    "Se ve bien, pero la verdadera pregunta es ¿sabe bien?"

# game/script.rpy:486
translate Spanish jackalope_2b1701f7:

    # "I cut a flaky piece off with the side of my fork and put it in my mouth."
    "Corto un trozo en lascas con el canto del tenedor y me lo llevo a la boca."

# game/script.rpy:487
translate Spanish jackalope_3b193c59:

    # "...!!!"
    "...!!!"

# game/script.rpy:488
translate Spanish jackalope_6c4ec8ba:

    # me "Jacob, this is delicious! This tastes even better than fish I've had at restaurants!"
    me "¡Jacob, esto está delicioso! ¡Sabe incluso mejor que el pescado que he probado en restaurantes!"

# game/script.rpy:489
translate Spanish jackalope_ff93a4db:

    # j "R-Really!? That's sweet of you to say, [playerName]. I knew making that extra store trip was worth it."
    j "¿¡E-en serio!? Qué amable de tu parte, [playerName]. Sabía que valía la pena ir otra vez a la tienda."

# game/script.rpy:491
translate Spanish jackalope_3536a978:

    # j "Now, let me go start up the movie."
    j "Ahora, déjame comenzar la película."

# game/script.rpy:494
translate Spanish jackalope_5f457252:

    # "We both focus on the screen as we eat our dinner together."
    "Ambos nos enfocamos en la pantalla mientras comemos juntos."

# game/script.rpy:495
translate Spanish jackalope_348a1de4:

    # "This 'Revenge Of The Jackalopes' movie did have cheesy acting and effects as I expected, but I found it more charming than outright bad."
    "Esta película, 'Revenge of the Jackalopes', tenía unas actuaciones y unos efectos cursis, como esperaba, pero me pareció más encantadora que mala."

# game/script.rpy:496
translate Spanish jackalope_1c643830:

    # "We both finish our dinner pretty early into the movie, but at least I can give my full focus on the plot now."
    "Los dos terminamos de cenar bastante pronto, pero al menos ahora puedo concentrarme por completo en la trama."

# game/script.rpy:497
translate Spanish jackalope_91c087d9:

    # "From what I'm understanding, the jackalopes are tired of being hunted and experimented on, and now they're rampaging the Midwest."
    "Por lo que entiendo, los jackalopes están cansados de que los cacen y experimenten con ellos, y ahora están arrasando el Medio Oeste."

# game/script.rpy:498
translate Spanish jackalope_ae043bd8:

    # "Oh wow, a guy got his eyes gouged out by a pair of antlers."
    "Uf, a un tipo le sacaron los ojos con unas astas."

# game/script.rpy:499
translate Spanish jackalope_1ce9a365:

    # "While I'm distracted, I feel weight shifting behind me."
    "Mientras estoy distraíd[letra], noto que el peso cambia detrás de mí."

# game/script.rpy:500
translate Spanish jackalope_55669277:

    # "Then, something grazing against the back of my head."
    "Entonces, algo me roza la nuca."

# game/script.rpy:504
translate Spanish jackalope_187c098a:

    # "Jacob's arm is wrapped around the top of the couch."
    "El brazo de Jacob descansa a lo largo del respaldo del sofá."

# game/script.rpy:505
translate Spanish jackalope_e837e842:

    # "His hand was resting on my shoulder..."
    "Su mano descansaba sobre mi hombro ..."

# game/script.rpy:506
translate Spanish jackalope_47d64936:

    # "Did he forget that I was here or is this deliberate?"
    "¿Olvidó que estaba aquí o es esto deliberado?"

# game/script.rpy:515
translate Spanish shoulder1_9d62993f:

    # "I stay perfectly still, calculating his movements."
    "Me quedo perfectamente quiet[letra], calculando sus movimientos."

# game/script.rpy:516
translate Spanish shoulder1_98608176:

    # "As if he read my mind, I feel his hand rubbing my shoulder in a circular motion."
    "Como si él leyera mi mente, siento su mano frotando mi hombro en un movimiento circular."

# game/script.rpy:517
translate Spanish shoulder1_7076b6cd:

    # "It was...relaxing."
    "Fue ... relajante."

# game/script.rpy:521
translate Spanish shoulder1_e20af2a0:

    # "I felt myself zoning out towards the end of the movie."
    "Siento que me voy quedando ausente hacia el final de la película."

# game/script.rpy:522
translate Spanish shoulder1_4522721f:

    # "My eyes were fluttering..."
    "Se me cerraban los ojos ..."

# game/script.rpy:523
translate Spanish shoulder1_50e1ab0f:

    # "That's weird, it doesn't seem close to my usual bedtime, and yet..."
    "Eso es raro, no parece cerca de mi hora habitual de dormir y, sin embargo, ..."

# game/script.rpy:524
translate Spanish shoulder1_34db4cf7:

    # j "Tired?"
    j "¿Tienes sueño?"

# game/script.rpy:525
translate Spanish shoulder1_7be4f404:

    # me "Yeah..."
    me "Sí..."

# game/script.rpy:526
translate Spanish shoulder1_879cda07:

    # "He gently wraps his arm completely around me."
    "Con delicadeza, me rodea por completo con el brazo."

# game/script.rpy:527
translate Spanish shoulder1_ca01abc2:

    # "My head rests against his shoulder."
    "Mi cabeza descansa contra su hombro."

# game/script.rpy:528
translate Spanish shoulder1_2f651a96:

    # "His body is warm..."
    "Su cuerpo es cálido ..."

# game/script.rpy:530
translate Spanish shoulder1_137f26e1:

    # j "Sleep well, sunshine."
    j "Duerme bien, sol."

# game/script.rpy:533
translate Spanish shoulder1_b0ceacbe:

    # "I feel myself tossing and turning in my sleep."
    "Noto que doy vueltas en sueños."

# game/script.rpy:534
translate Spanish shoulder1_69f25813:

    # "Rubbing my eyes, I stretch my limbs and-{w=0.2}{nw}"
    "Frotándome los ojos, estiro las extremidades y-{w=0.2}{nw}"

# game/script.rpy:535
translate Spanish shoulder1_a20cefa7:

    # "..."
    "..."

# game/script.rpy:536
translate Spanish shoulder1_c1e374dc:

    # "This is not my house."
    "Esta no es mi casa."

# game/script.rpy:537
translate Spanish shoulder1_9a8c28a4:

    # j "Mornin' [playerName]. Did you sleep ok?"
    j "Buenos días, [playerName]. ¿Dormiste bien?"

# game/script.rpy:541
translate Spanish shoulder1_786c2ce6:

    # me "Hey, what happened last night?"
    me "Oye, ¿qué pasó anoche?"

# game/script.rpy:542
translate Spanish shoulder1_c8dd7882:

    # j "Oh, you fell asleep during the end of the movie. I didn't want to disrupt you, so I let you sleep here."
    j "Oh, te quedaste dormid[letra] al final de la película. No quería molestarte, así que te dejé dormir aquí."

# game/script.rpy:543
translate Spanish shoulder1_9a3367a7:

    # "He stepped closer and grabbed something draped across my shoulders."
    "Se acercó y retiró algo que me cubría los hombros."

# game/script.rpy:544
translate Spanish shoulder1_25699eca:

    # "It was a blanket."
    "Era una manta."

# game/script.rpy:545
translate Spanish shoulder1_0ec54fbe:

    # j "I didn't want you feelin' cold in the middle of the night, so I sorta...tucked you in."
    j "No quería que pasaras frío en medio de la noche, así que, bueno... te arropé."

# game/script.rpy:546
translate Spanish shoulder1_05b0aee2:

    # j "I also made us some breakfast! It's nothin' special, just some eggs and toast."
    j "¡También nos preparé el desayuno! No es nada del otro mundo, solo unos huevos y unas tostadas."

# game/script.rpy:547
translate Spanish shoulder1_1fdaa3ba:

    # "You look out his window, it's still dark out."
    "Miro por su ventana, todavía está oscuro."

# game/script.rpy:548
translate Spanish shoulder1_4f39e555:

    # me "What time is it? How long was I asleep for?"
    me "¿Qué hora es? ¿Cuánto tiempo estuve dormid[letra]?"

# game/script.rpy:550
translate Spanish shoulder1_cde80d05:

    # j "Hm, let's see...well, we finished the movie around 8:00 PM, which is when you fell asleep. Right now it's 4:35 AM."
    j "Hm, veamos ... bueno, terminamos la película alrededor de las 8:00 p.m., que es cuando te quedaste dormid[letra]. Ahora mismo son las 4:35 am."

# game/script.rpy:551
translate Spanish shoulder1_8b76f7da:

    # me "I was asleep for 8 hours!?"
    me "¿¡Estuve dormid[letra] 8 horas!?"

# game/script.rpy:553
translate Spanish shoulder1_dccf8001:

    # j "Yup. You got a full night's rest!"
    j "Sí. ¡Has tenido una noche de descanso completa!"

# game/script.rpy:554
translate Spanish shoulder1_9b644566:

    # "That's really strange, I usually fall asleep much later than that."
    "Eso es realmente extraño, generalmente me duermo mucho más tarde que eso."

# game/script.rpy:555
translate Spanish shoulder1_b17fba9c:

    # me "How come you're awake so early?"
    me "¿Cómo es que estás despierto tan temprano?"

# game/script.rpy:557
translate Spanish shoulder1_7e2b9b6b:

    # j "My sleep schedule is kinda everywhere. I'm a night owl."
    j "Mi horario de sueño es un caos. Soy muy noctámbulo."

# game/script.rpy:559
translate Spanish shoulder1_1c6a45e0:

    # j "Plus, I wanted to watch the sun rise."
    j "Además, quería ver salir el sol."

# game/script.rpy:560
translate Spanish shoulder1_1c786d0b:

    # "Jacob walks over to his kitchen and comes back with two plates."
    "Jacob se acerca a su cocina y regresa con dos platos."

# game/script.rpy:561
translate Spanish shoulder1_55f2f263:

    # j "Here, you'll think better after you eat."
    j "Aquí, pensarás mejor después de comer."

# game/script.rpy:571
translate Spanish breakfast1_a6e28bec:

    # "I'd feel bad if I declined his generocity."
    "Me sentiría mal si rechazara su generosidad."

# game/script.rpy:572
translate Spanish breakfast1_4abf72f1:

    # "He was kind enough to let me sleep here, and even make me food twice in a row now..."
    "Tuvo la amabilidad de dejarme dormir aquí, e incluso hacerme comida dos veces seguidas ahora ..."

# game/script.rpy:573
translate Spanish breakfast1_e561190e:

    # "I grab the plate in front of me and sit back down on the couch."
    "Agarro el plato frente a mí y me siento en el sofá."

# game/script.rpy:574
translate Spanish breakfast1_fb0dac7f:

    # me "Thanks Jacob, it looks good."
    me "Gracias Jacob, se ve bien."

# game/script.rpy:575
translate Spanish breakfast1_0c60c2bb:

    # "He comes to sit next to me with his own plate."
    "Viene a sentarse a mi lado con su propio plato."

# game/script.rpy:578
translate Spanish breakfast1_bde96de6:

    # "I take a few bites of my toast. It's crispy and buttery."
    "Doy unos bocados a mi tostada. Está crujiente y con mantequilla."

# game/script.rpy:579
translate Spanish breakfast1_142391d2:

    # "Jacob cuts into his eggs and dips his toast into the yolk."
    "Jacob corta sus huevos y sumerge sus tostadas en la yema."

# game/script.rpy:580
translate Spanish breakfast1_38e92438:

    # "It felt a little awkward only hearing eachother's loud crunching in between bites..."
    "Era un poco incómodo oír solo el fuerte crujido de nuestras tostadas entre bocado y bocado ..."

# game/script.rpy:589
translate Spanish fishy_93639128:

    # me "So Jacob, you got any hobbies? I see a fishtank in the corner of your room over there."
    me "Oye, Jacob, ¿tienes algún pasatiempo? Veo una pecera en la esquina de tu sala."

# game/script.rpy:590
translate Spanish fishy_afdb8241:

    # "He nearly jolts up from his seat in response."
    "Casi da un brinco en su asiento al oírlo."

# game/script.rpy:591
translate Spanish fishy_773e7406:

    # j "Y-Yeah. I really like fishkeeping."
    j "S-sí. Me gusta mucho la acuariofilia."

# game/script.rpy:592
translate Spanish fishy_e8c7d345:

    # me "Cool! What got you into fishkeeping?"
    me "¡Qué genial! ¿Cómo te metiste en la acuariofilia?"

# game/script.rpy:593
translate Spanish fishy_f27c0c86:

    # j "Well, I used to go fishing a lot with my dad. I remember being upset about how I couldn't keep the fish I caught, then he introduced me to fishkeeping."
    j "Bueno, solía ir a pescar mucho con mi papá. Recuerdo que me molestaba no poder quedarme con los peces que pescaba, y entonces él me presentó la acuariofilia."

# game/script.rpy:594
translate Spanish fishy_53f58c58:

    # j "It's a nice little thing...decorating the tank and choosing what kinds of fish you want."
    j "Es algo muy bonito... decorar la pecera y elegir qué tipos de peces quieres."

# game/script.rpy:595
translate Spanish fishy_685cf6eb:

    # j "They like to follow your finger too, or when I talk to them they'll follow my voice. Sometimes I'll watch them swim around for hours."
    j "También les gusta seguir tu dedo, y cuando les hablo, siguen mi voz. A veces los veo nadar durante horas."

# game/script.rpy:597
translate Spanish fishy_6f2b2b58:

    # "He takes a large bite out of his toast."
    "Le da un gran mordisco a su tostada."

# game/script.rpy:598
translate Spanish fishy_752ae9b6:

    # me "Do you have a favorite fish?"
    me "¿Tienes un pez favorito?"

# game/script.rpy:599
translate Spanish fishy_6dcf67d9:

    # j "Salmon is my number one. Both in taste and in looks. Sockeye salmon even has my favorite colors together, red and green."
    j "El salmón es mi favorito. Tanto por el sabor como por el aspecto. El salmón rojo (sockeye) incluso reúne mis dos colores favoritos, el rojo y el verde."

# game/script.rpy:600
translate Spanish fishy_e2a47bd7:

    # me "Yeah, salmon is pretty cool. Mind if I look at your tank?"
    me "Sí, el salmón es genial. ¿Te importa si miro tu pecera?"

# game/script.rpy:601
translate Spanish fishy_3985d8f2:

    # j "Go ahead."
    j "Adelante."

# game/script.rpy:603
translate Spanish fishy_ab995ab4:

    # "I couldn't help but squint as my eyes adjusted to the bright red lighting of the tank."
    "No pude evitar entrecerrar los ojos mientras se acostumbraban a la intensa luz roja de la pecera."

# game/script.rpy:604
translate Spanish fishy_353060e6:

    # "The enclosure itself was neatly decorated with an array of aquatic plants and little caverns for fish to hide in."
    "El recinto en sí estaba perfectamente decorado con una variedad de plantas acuáticas y pequeñas cavernas para que los peces se escondieran."

# game/script.rpy:605
translate Spanish fishy_7d42dd03:

    # "There also appears to be a few pieces of decor that reference various TV shows and movies."
    "También parece haber algunas piezas de decoración que hacen referencia a varios programas de televisión y películas."

# game/script.rpy:606
translate Spanish fishy_25fd9684:

    # me "Do you have a favorite fish in this tank?"
    me "¿Tienes un pez favorito en esta pecera?"

# game/script.rpy:607
translate Spanish fishy_c5b014f6:

    # j "I usually try not to play favorites when it comes to my pets, but I like that plecostomus."
    j "Intento no tener favoritos entre mis mascotas, pero ese pleco me cae especialmente bien."

# game/script.rpy:608
translate Spanish fishy_03043be6:

    # me "Wait, which one?"
    me "Espera, ¿cuál?"

# game/script.rpy:609
translate Spanish fishy_db3da1a0:

    # j "The big black fish that sucks on the glass. They're also known as plecos."
    j "El pez grande y negro que se pega al cristal. También se les llama plecos."

# game/script.rpy:611
translate Spanish fishy_3204b538:

    # j "His name is Captain. He keeps the tank clean."
    j "Se llama Captain. Mantiene la pecera limpia."

# game/script.rpy:612
translate Spanish fishy_493df0ba:

    # me "Hello Captain."
    me "Hola, Captain."

# game/script.rpy:613
translate Spanish fishy_c0505624:

    # "The fish stares blankly at it's surroundings. He's in his own little world."
    "El pez mira a su alrededor con la mirada perdida. Está en su propio mundo."

# game/script.rpy:614
translate Spanish fishy_0a7570f6:

    # j "I like how the plecos look, and how helpful they are at keeping algae low."
    j "Me gusta cómo se ven los Plecos y cuán útiles son para mantener bajas las algas."

# game/script.rpy:615
translate Spanish fishy_c0b9eaa4:

    # j "You can also feed them pieces of cucumber, it's fun watching them eat."
    j "También puedes darles trocitos de pepino, es divertido verlos comer."

# game/script.rpy:616
translate Spanish fishy_98900be0:

    # j "They're also bottom feeders, which means they can actually eat more than just plants. Like dead fish."
    j "También se alimentan del fondo, lo que significa que pueden comer más que plantas. Por ejemplo, peces muertos."

# game/script.rpy:617
translate Spanish fishy_b3193167:

    # j "Plecos can kill if they want to, but I make sure Captain is well fed so he doesn't attack the other fish."
    j "Los plecos pueden matar si quieren, pero me aseguro de que Captain esté bien alimentado para que no ataque a los otros peces."

# game/script.rpy:619
translate Spanish fishy_8cf69189:

    # j "There's also the angelfish. Despite their name, they can actually be pretty aggressive. I only keep a few of them so they don't fight."
    j "También están los peces ángel. A pesar del nombre, pueden ser bastante agresivos. Solo tengo unos pocos para que no peleen."

# game/script.rpy:620
translate Spanish fishy_fd30b911:

    # j "They usually start fighting with eachother when they want a partner for themselves."
    j "Por lo general, comienzan a pelear entre ellos cuando quieren una pareja para ellos mismos."

# game/script.rpy:621
translate Spanish fishy_db022150:

    # j "Can't say I blame 'em."
    j "No puedo culparlos."

# game/script.rpy:623
translate Spanish fishy_4790ccb9:

    # "I sit back down and finish the remaining pieces of food on my plate."
    "Me siento de nuevo y termino las piezas de comida restantes en mi plato."

# game/script.rpy:624
translate Spanish fishy_1da95cf6:

    # j "Hope you enjoyed the lil' fish tour."
    j "Espero que te haya gustado el minirrecorrido por mis peces."

# game/script.rpy:625
translate Spanish fishy_bb34b9a8:

    # me "Yeah your fish are pretty neat!"
    me "¡Sí, tus peces son geniales!"

# game/script.rpy:626
translate Spanish fishy_7990a7d7:

    # j "Thanks. Sometimes I show off my fishtank on fishkeeping forums, but showin' someone my hobby in-person feels much more special."
    j "Gracias. A veces enseño mi pecera en foros de acuariofilia, pero mostrarle mi afición a alguien en persona es mucho más especial."

# game/script.rpy:628
translate Spanish fishy_5554ced7:

    # j "It means a lot to me, [playerName]."
    j "Significa mucho para mí, [playerName]."

# game/script.rpy:629
translate Spanish fishy_cca1b132:

    # "As he finishes his breakfast, he takes both our plates back to his kitchen."
    "Cuando termina su desayuno, lleva nuestros dos platos de regreso a su cocina."

# game/script.rpy:632
translate Spanish fishy_ec5028d5:

    # me "I should start heading back home now. Thanks again for the movie night and the breakfast, I still feel bad for sleeping here on accident..."
    me "Debería ir volviendo a casa. Gracias otra vez por la noche de cine y el desayuno; todavía me siento mal por haberme quedado dormid[letra] aquí sin querer ..."

# game/script.rpy:633
translate Spanish fishy_9e71a6b4:

    # j "Don't worry about it, [playerName]. You're always welcomed here whenever!"
    j "No te preocupes por eso, [playerName]. ¡Aquí siempre eres bienvenid[letra], cuando quieras!"

# game/script.rpy:634
translate Spanish fishy_3c532397:

    # "I make my way towards his front door to leave, but-"
    "Me dirijo hacia su puerta principal para irme, pero--"

# game/script.rpy:638
translate Spanish fishy_5da066c9:

    # "Why are there so many locks!?"
    "¡¿Por qué hay tantas cerraduras?!"

# game/script.rpy:640
translate Spanish fishy_5894be77:

    # j "Here, let me get those for you."
    j "Espera, deja que te abra."

# game/script.rpy:641
translate Spanish fishy_ff17d1f3:

    # "He unlocks each piece of security quite slowly, as if he's purposely taking his sweet time with it."
    "Va abriendo cada cerrojo con mucha lentitud, como si se tomara su tiempo a propósito."

# game/script.rpy:642
translate Spanish fishy_89799854:

    # "Finally, he takes out a ring of small keys from his pocket and unlocks the last piece."
    "Por fin, saca un llavero con llaves pequeñas del bolsillo y abre el último cerrojo."

# game/script.rpy:644
translate Spanish fishy_2dc23891:

    # j "Bye [playerName], have a good day."
    j "Adiós [playerName], que tengas un buen día."

# game/script.rpy:645
translate Spanish fishy_07ae9e2c:

    # me "Thanks, um, you too."
    me "Gracias, eh... igualmente."

# game/script.rpy:647
translate Spanish fishy_9a87d695:

    # "I walk back towards my house. It's still dark outside and I find myself yawning as I get to my front door."
    "Camino de regreso hacia mi casa. Todavía está oscuro afuera y me encuentro bostezando mientras llego a la puerta de mi casa."

# game/script.rpy:649
translate Spanish fishy_5efb8f2e:

    # "I make my way up to my room. Even though I slept a whole 8 hours, I still feel a little drowsy."
    "Me dirijo a mi habitación. Aunque dormí 8 horas enteras, todavía tengo un poco de sueño."

# game/script.rpy:651
translate Spanish fishy_1076685e:

    # "I got settled down in bed."
    "Me acomodo en la cama."

# game/script.rpy:652
translate Spanish fishy_c75e8b94:

    # "My mind begins to wander..."
    "Mi mente empieza a divagar..."

# game/script.rpy:653
translate Spanish fishy_27745d74:

    # "Something about my neighbor does feel off."
    "Hay algo en mi vecino que no me cuadra."

# game/script.rpy:654
translate Spanish fishy_385599ce:

    # "Who needs THAT many locks on a door!?"
    "¡¿Quién necesita TANTAS cerraduras en una puerta?!"

# game/script.rpy:655
translate Spanish fishy_49579072:

    # "But I guess I can't blame him. I've heard of some people going missing in this area."
    "Pero supongo que no puedo culparlo. He oído que ha desaparecido gente por esta zona."

# game/script.rpy:656
translate Spanish fishy_28a542d9:

    # "There hasn't been another missing person for a while though."
    "Sin embargo, no ha habido otra persona desaparecida por un tiempo."

# game/script.rpy:657
translate Spanish fishy_12ef37cd:

    # "I don't have the energy to overthink things right now."
    "No tengo la energía para pensar demasiado en las cosas en este momento."

# game/script.rpy:658
translate Spanish fishy_ca8a31ab:

    # "I shut my eyes and fall asleep."
    "Cierro los ojos y me duermo."

# game/script.rpy:663
translate Spanish jbreak_6ba78a64:

    # "I think I'll just focus on eating, I sorta feel like I've overstayed my welcome."
    "Creo que me concentraré en comer; siento que ya me he quedado más de la cuenta."

# game/script.rpy:664
translate Spanish jbreak_e08b25b8:

    # "I'll just eat as quickly as I can and go home."
    "Comeré lo más rápido que pueda y me iré a casa."

# game/script.rpy:665
translate Spanish jbreak_b599b300:

    # "Among our crunching, I hear Jacob mumble something to me."
    "Entre crujido y crujido, oigo a Jacob murmurarme algo."

# game/script.rpy:666
translate Spanish jbreak_13f67258:

    # j "So, uhh...watched anything good lately?"
    j "Entonces, eh... ¿has visto algo bueno últimamente?"

# game/script.rpy:667
translate Spanish jbreak_79f0c46f:

    # me "I mean, the movie last night was ok. There's another horror movie I've been thinking about watching."
    me "Bueno, la película de anoche estuvo bien. Hay otra película de terror que he estado pensando en ver."

# game/script.rpy:668
translate Spanish jbreak_13489fc3:

    # me "It's called 'Return Of The Rat People'. You might like it, it's another one of those 1950s movies."
    me "Se llama 'Return Of The Rat People'. Puede que te guste, es otra de esas películas de la década de 1950."

# game/script.rpy:669
translate Spanish jbreak_8540065a:

    # j "I've actually seen that one a while back, but that movie's been popular lately due to the memes people keep making 'bout it."
    j "De hecho, he visto esa hace un tiempo, pero esa película ha sido popular últimamente debido a los memes que la gente sigue haciendo."

# game/script.rpy:670
translate Spanish jbreak_d0dedfca:

    # j "It kinda irks me a bit to be honest. I hope people can just appreciate the movie and not mock it."
    j "Me molesta un poco para ser honesto. Espero que la gente pueda apreciar la película y no burlarse de ella."

# game/script.rpy:671
translate Spanish jbreak_27336b61:

    # "We end up sitting in silence between eachother as we finish our food in sync."
    "Acabamos sentados en silencio, uno junto al otro, terminando de comer casi a la vez."

# game/script.rpy:672
translate Spanish jbreak_f2756116:

    # "Jacob takes both our plates away and brings them to his kitchen."
    "Jacob se lleva ambos platos y los lleva a su cocina."

# game/script.rpy:675
translate Spanish jbreak_ec5028d5:

    # me "I should start heading back home now. Thanks again for the movie night and the breakfast, I still feel bad for sleeping here on accident..."
    me "Debería ir volviendo a casa. Gracias otra vez por la noche de cine y el desayuno; todavía me siento mal por haberme quedado dormid[letra] aquí sin querer ..."

# game/script.rpy:676
translate Spanish jbreak_9e71a6b4:

    # j "Don't worry about it, [playerName]. You're always welcomed here whenever!"
    j "No te preocupes por eso, [playerName]. ¡Aquí siempre eres bienvenid[letra], cuando quieras!"

# game/script.rpy:677
translate Spanish jbreak_3c532397:

    # "I make my way towards his front door to leave, but-"
    "Me dirijo hacia su puerta principal para irme, pero-"

# game/script.rpy:681
translate Spanish jbreak_5da066c9:

    # "Why are there so many locks!?"
    "¡¿Por qué hay tantas cerraduras?!"

# game/script.rpy:683
translate Spanish jbreak_5894be77:

    # j "Here, let me get those for you."
    j "Espera, deja que te abra."

# game/script.rpy:684
translate Spanish jbreak_ff17d1f3:

    # "He unlocks each piece of security quite slowly, as if he's purposely taking his sweet time with it."
    "Va abriendo cada cerrojo con mucha lentitud, como si se tomara su tiempo a propósito."

# game/script.rpy:685
translate Spanish jbreak_89799854:

    # "Finally, he takes out a ring of small keys from his pocket and unlocks the last piece."
    "Por fin, saca un llavero con llaves pequeñas del bolsillo y abre el último cerrojo."

# game/script.rpy:687
translate Spanish jbreak_2dc23891:

    # j "Bye [playerName], have a good day."
    j "Adiós [playerName], que tengas un buen día."

# game/script.rpy:688
translate Spanish jbreak_07ae9e2c:

    # me "Thanks, um, you too."
    me "Gracias, eh... igualmente."

# game/script.rpy:690
translate Spanish jbreak_9a87d695:

    # "I walk back towards my house. It's still dark outside and I find myself yawning as I get to my front door."
    "Camino de regreso hacia mi casa. Todavía está oscuro afuera y me encuentro bostezando mientras llego a la puerta de mi casa."

# game/script.rpy:692
translate Spanish jbreak_5efb8f2e:

    # "I make my way up to my room. Even though I slept a whole 8 hours, I still feel a little drowsy."
    "Me dirijo a mi habitación. Aunque dormí 8 horas enteras, todavía tengo un poco de sueño."

# game/script.rpy:694
translate Spanish jbreak_1076685e:

    # "I got settled down in bed."
    "Me acomodo en la cama."

# game/script.rpy:695
translate Spanish jbreak_c75e8b94:

    # "My mind begins to wander..."
    "Mi mente empieza a divagar..."

# game/script.rpy:696
translate Spanish jbreak_27745d74:

    # "Something about my neighbor does feel off."
    "Hay algo en mi vecino que no me cuadra."

# game/script.rpy:697
translate Spanish jbreak_385599ce:

    # "Who needs THAT many locks on a door!?"
    "¡¿Quién necesita TANTAS cerraduras en una puerta?!"

# game/script.rpy:698
translate Spanish jbreak_49579072:

    # "But I guess I can't blame him. I've heard of some people going missing in this area."
    "Pero supongo que no puedo culparlo. He oído que ha desaparecido gente por esta zona."

# game/script.rpy:699
translate Spanish jbreak_28a542d9:

    # "There hasn't been another missing person for a while though."
    "Sin embargo, no ha habido otra persona desaparecida por un tiempo."

# game/script.rpy:700
translate Spanish jbreak_12ef37cd:

    # "I don't have the energy to overthink things right now."
    "No tengo la energía para pensar demasiado en las cosas en este momento."

# game/script.rpy:701
translate Spanish jbreak_ca8a31ab:

    # "I shut my eyes and fall asleep."
    "Cierro los ojos y me duermo."

# game/script.rpy:709
translate Spanish nobreakfast1_b367d6c8:

    # me "Actually, I think I should start heading back home now. Thanks again for the movie night and the breakfast, I still feel bad for sleeping here on accident..."
    me "En realidad, creo que debería ir volviendo a casa. Gracias otra vez por la noche de cine y el desayuno; todavía me siento mal por haberme quedado dormid[letra] aquí sin querer..."

# game/script.rpy:710
translate Spanish nobreakfast1_60467445:

    # "I feel like I've overstayed my welcome. I feel so awkward sleeping over this man's house without consulting him first."
    "Siento que me he quedado más de la cuenta. Me da mucha vergüenza haberme quedado a dormir en casa de este hombre sin consultárselo antes."

# game/script.rpy:711
translate Spanish nobreakfast1_cc462cbb:

    # j "Don't worry about it, [playerName]. Just remember that you're always welcomed here."
    j "No te preocupes por eso, [playerName]. Solo recuerda que aquí siempre serás bienvenid[letra]."

# game/script.rpy:712
translate Spanish nobreakfast1_3c532397:

    # "I make my way towards his front door to leave, but-"
    "Me dirijo hacia su puerta principal para irme, pero-"

# game/script.rpy:716
translate Spanish nobreakfast1_5da066c9:

    # "Why are there so many locks!?"
    "¡¿Por qué hay tantas cerraduras?!"

# game/script.rpy:718
translate Spanish nobreakfast1_5894be77:

    # j "Here, let me get those for you."
    j "Espera, deja que te abra."

# game/script.rpy:719
translate Spanish nobreakfast1_ff17d1f3:

    # "He unlocks each piece of security quite slowly, as if he's purposely taking his sweet time with it."
    "Va abriendo cada cerrojo con mucha lentitud, como si se tomara su tiempo a propósito."

# game/script.rpy:720
translate Spanish nobreakfast1_89799854:

    # "Finally, he takes out a ring of small keys from his pocket and unlocks the last piece."
    "Por fin, saca un llavero con llaves pequeñas del bolsillo y abre el último cerrojo."

# game/script.rpy:722
translate Spanish nobreakfast1_2dc23891:

    # j "Bye [playerName], have a good day."
    j "Adiós [playerName], que tengas un buen día."

# game/script.rpy:723
translate Spanish nobreakfast1_07ae9e2c:

    # me "Thanks, um, you too."
    me "Gracias, eh... igualmente."

# game/script.rpy:725
translate Spanish nobreakfast1_9a87d695:

    # "I walk back towards my house. It's still dark outside and I find myself yawning as I get to my front door."
    "Camino de regreso hacia mi casa. Todavía está oscuro afuera y me encuentro bostezando mientras llego a la puerta de mi casa."

# game/script.rpy:727
translate Spanish nobreakfast1_5efb8f2e:

    # "I make my way up to my room. Even though I slept a whole 8 hours, I still feel a little drowsy."
    "Me dirijo a mi habitación. Aunque dormí 8 horas enteras, todavía tengo un poco de sueño."

# game/script.rpy:729
translate Spanish nobreakfast1_1076685e:

    # "I got settled down in bed."
    "Me acomodo en la cama."

# game/script.rpy:730
translate Spanish nobreakfast1_c75e8b94:

    # "My mind begins to wander..."
    "Mi mente empieza a divagar..."

# game/script.rpy:731
translate Spanish nobreakfast1_27745d74:

    # "Something about my neighbor does feel off."
    "Hay algo en mi vecino que no me cuadra."

# game/script.rpy:732
translate Spanish nobreakfast1_385599ce:

    # "Who needs THAT many locks on a door!?"
    "¡¿Quién necesita TANTAS cerraduras en una puerta?!"

# game/script.rpy:733
translate Spanish nobreakfast1_49579072:

    # "But I guess I can't blame him. I've heard of some people going missing in this area."
    "Pero supongo que no puedo culparlo. He oído que ha desaparecido gente por esta zona."

# game/script.rpy:734
translate Spanish nobreakfast1_28a542d9:

    # "There hasn't been another missing person for a while though."
    "Sin embargo, no ha habido otra persona desaparecida por un tiempo."

# game/script.rpy:735
translate Spanish nobreakfast1_12ef37cd:

    # "I don't have the energy to overthink things right now."
    "No tengo la energía para pensar demasiado en las cosas en este momento."

# game/script.rpy:736
translate Spanish nobreakfast1_ca8a31ab:

    # "I shut my eyes and fall asleep."
    "Cierro los ojos y me duermo."

# game/script.rpy:750
translate Spanish shoulder2_bda63daa:

    # "I think this is a little too close for comfort..."
    "Creo que esto es demasiada cercanía para mi gusto..."

# game/script.rpy:751
translate Spanish shoulder2_41f5e60a:

    # me "Hey, is it ok if you could pull your arm back?"
    me "Oye, ¿te importaría quitar el brazo?"

# game/script.rpy:752
translate Spanish shoulder2_227f3a09:

    # j "Hm?"
    j "¿Mm?"

# game/script.rpy:754
translate Spanish shoulder2_2cd2992c:

    # j "O-Oh...my fault. Sorry 'bout that. I zone out sometimes and just wanted to stretch my arms."
    j "O-oh... fue culpa mía. Perdona. A veces me quedo en las nubes y solo quería estirar los brazos."

# game/script.rpy:755
translate Spanish shoulder2_12013c72:

    # j "Didn't mean to make you uncomfortable."
    j "No quería incomodarte."

# game/script.rpy:756
translate Spanish shoulder2_f0a88f7a:

    # me "That's ok, no worries!"
    me "¡Está bien, no te preocupes!"

# game/script.rpy:757
translate Spanish shoulder2_19139956:

    # "I try smiling at him to ease the awkward situation, but he doesn't react."
    "Intento sonreírle para aliviar la situación incómoda, pero no reacciona."

# game/script.rpy:758
translate Spanish shoulder2_7a596afb:

    # "We sit next to eachother in silence as the movie reached it's end."
    "Nos sentamos uno al lado del otro en silencio cuando la película llegó a su final."

# game/script.rpy:759
translate Spanish shoulder2_1d4e182a:

    # "Right as the credits roll, I stand up and make my way towards his door."
    "En cuanto empiezan a salir los créditos, me levanto y me dirijo hacia su puerta."

# game/script.rpy:760
translate Spanish shoulder2_b9362601:

    # me "Uh, thanks for the dinner and movie. I should start heading back-"
    me "Eh, gracias por la cena y la película. Debería ir vol-"

# game/script.rpy:763
translate Spanish shoulder2_5da066c9:

    # "Why are there so many locks!?"
    "¡¿Por qué hay tantas cerraduras?!"

# game/script.rpy:765
translate Spanish shoulder2_5894be77:

    # j "Here, let me get those for you."
    j "Espera, deja que te abra."

# game/script.rpy:767
translate Spanish shoulder2_ff17d1f3:

    # "He unlocks each piece of security quite slowly, as if he's purposely taking his sweet time with it."
    "Va abriendo cada cerrojo con mucha lentitud, como si se tomara su tiempo a propósito."

# game/script.rpy:768
translate Spanish shoulder2_89799854:

    # "Finally, he takes out a ring of small keys from his pocket and unlocks the last piece."
    "Por fin, saca un llavero con llaves pequeñas del bolsillo y abre el último cerrojo."

# game/script.rpy:769
translate Spanish shoulder2_cc7671bf:

    # j "I had a nice time tonight."
    j "Pasé un buen rato esta noche."

# game/script.rpy:770
translate Spanish shoulder2_814d864f:

    # j "Goodnight [playerName]. Sleep well."
    j "Buenas noches, [playerName]. Que duermas bien."

# game/script.rpy:771
translate Spanish shoulder2_69dbaeac:

    # me "Thanks, you too."
    me "Gracias, tú también."

# game/script.rpy:774
translate Spanish shoulder2_797f7d15:

    # "I walk back towards my house. Despite the awkward moment, I did find myself enjoying the meal and movie."
    "Camino de regreso hacia mi casa. A pesar del momento incómodo, me encontré disfrutando de la comida y la película."

# game/script.rpy:776
translate Spanish shoulder2_fcbfe73c:

    # "I enter my house, dragging my tired body up the stairs."
    "Entro en mi casa, arrastrando mi cuerpo cansado por las escaleras."

# game/script.rpy:778
translate Spanish shoulder2_79a6796b:

    # "After brushing my teeth, I got settled down in bed."
    "Después de cepillarme los dientes, me acomodo en la cama."

# game/script.rpy:779
translate Spanish shoulder2_c75e8b94:

    # "My mind begins to wander..."
    "Mi mente empieza a divagar..."

# game/script.rpy:780
translate Spanish shoulder2_27745d74:

    # "Something about my neighbor does feel off."
    "Hay algo en mi vecino que no me cuadra."

# game/script.rpy:781
translate Spanish shoulder2_385599ce:

    # "Who needs THAT many locks on a door!?"
    "¡¿Quién necesita TANTAS cerraduras en una puerta?!"

# game/script.rpy:782
translate Spanish shoulder2_49579072:

    # "But I guess I can't blame him. I've heard of some people going missing in this area."
    "Pero supongo que no puedo culparlo. He oído que ha desaparecido gente por esta zona."

# game/script.rpy:783
translate Spanish shoulder2_28a542d9:

    # "There hasn't been another missing person for a while though."
    "Sin embargo, no ha habido otra persona desaparecida por un tiempo."

# game/script.rpy:784
translate Spanish shoulder2_12ef37cd:

    # "I don't have the energy to overthink things right now."
    "No tengo la energía para pensar demasiado en las cosas en este momento."

# game/script.rpy:785
translate Spanish shoulder2_ca8a31ab:

    # "I shut my eyes and fall asleep."
    "Cierro los ojos y me duermo."

# game/script.rpy:792
translate Spanish mchomemorningcreepy_501de206:

    # "The doorbell wakes me from my slumber."
    "El timbre me despierta de mi sueño."

# game/script.rpy:793
translate Spanish mchomemorningcreepy_1b614d54:

    # "I feel groggy as I rub my eyes."
    "Me siento atontad[letra] mientras me froto los ojos."

# game/script.rpy:795
translate Spanish mchomemorningcreepy_ebe473ba:

    # "After freshening up in the bathroom, I head towards the front door once again."
    "Después de refrescarme en el baño, me dirijo hacia la puerta principal una vez más."

# game/script.rpy:798
translate Spanish mchomemorningcreepy_849b55b4:

    # aa "Hi. I need you to sign this."
    aa "Hola. Necesito que firmes esto."

# game/script.rpy:799
translate Spanish mchomemorningcreepy_4cc4f5eb:

    # "I'm so used to seeing a different blonde guy show up at my door that for once, I was NOT expecting the mailman."
    "Estoy tan acostumbrad[letra] a ver aparecer a un rubio distinto en mi puerta que, por una vez, NO esperaba al cartero."

# game/script.rpy:800
translate Spanish mchomemorningcreepy_5e07a9b7:

    # "I don't think I've seen this one around before though."
    "Aunque no creo haber visto antes a este por aquí."

# game/script.rpy:801
translate Spanish mchomemorningcreepy_0d7777be:

    # me "Ok, right here?"
    me "Ok, ¿aquí?"

# game/script.rpy:802
translate Spanish mchomemorningcreepy_e3cc524e:

    # aa "Yeah."
    aa "Sí."

# game/script.rpy:803
translate Spanish mchomemorningcreepy_db11caea:

    # "I give him back the clipboard, but before handing over my package, he scans over the paper carefully."
    "Le devuelvo el portapapeles, pero antes de darme el paquete, examina el papel con detenimiento."

# game/script.rpy:807
translate Spanish mchomemorningcreepy_e29d091a:

    # aa "[playerName]. Cute name you got there."
    aa "[playerName]. Qué lindo nombre tienes."

# game/script.rpy:808
translate Spanish mchomemorningcreepy_0d57f09d:

    # me "Um, thanks...?"
    me "Um, gracias ...?"

# game/script.rpy:809
translate Spanish mchomemorningcreepy_1482ff3d:

    # a "Name's Austin. You're new in town, yeah?"
    a "Me llamo Austin. Eres nuev[letra] en el pueblo, ¿no?"

# game/script.rpy:810
translate Spanish mchomemorningcreepy_b5b04d03:

    # me "Well, I moved here just a few months ago."
    me "Bueno, me mudé aquí hace solo unos meses."

# game/script.rpy:812
translate Spanish mchomemorningcreepy_471bfceb:

    # a "Ah, that explains it. I shoulda known you ain't from 'round here, don't get too many people like you in this town."
    a "Ah, eso lo explica. Tendría que haberme dado cuenta de que no eres de por aquí; en este pueblo no vemos a mucha gente como tú."

# game/script.rpy:813
translate Spanish mchomemorningcreepy_0fac745f:

    # me "And what do you mean by that?"
    me "¿Y a qué te refieres con eso?"

# game/script.rpy:814
translate Spanish mchomemorningcreepy_3f8fce35:

    # a "Nothin'. Just not too many hotties livin' here, ya know?"
    a "Nada. Es que por aquí no vive mucho bombón, ¿sabes?"

# game/script.rpy:816
translate Spanish mchomemorningcreepy_434e376f:

    # me "Look, can I just have my package now? I don't have time for this."
    me "Mira, ¿me das ya mi paquete? No tengo tiempo para esto."

# game/script.rpy:817
translate Spanish mchomemorningcreepy_97ddd28d:

    # a "Geez, calm down [playerName], loosen up a bit. You should be thankful SOMEONE is talking to you."
    a "Caray, cálmate, [playerName], relájate un poco. Deberías agradecer que ALGUIEN te dirija la palabra."

# game/script.rpy:818
translate Spanish mchomemorningcreepy_bef265c3:

    # me "Oh yeah? How so?"
    me "¿Ah, sí? ¿Y eso por qué?"

# game/script.rpy:819
translate Spanish mchomemorningcreepy_9b013618:

    # a "Don't it get lonesome 'round here? Being new and all? I can be your first friend."
    a "¿No se pone solitario por aquí? Siendo nuev[letra] y todo... Puedo ser tu primer amig[letra]."

# game/script.rpy:820
translate Spanish mchomemorningcreepy_45af15f0:

    # "He leans an arm against my doorway, bringing his body closer to me."
    "Apoya un brazo en el marco de mi puerta y acerca su cuerpo al mío."

# game/script.rpy:822
translate Spanish mchomemorningcreepy_5c90b9b0:

    # a "And if you give me a chance, I can even be your boyfriend~"
    a "Y si me das una oportunidad, incluso puedo ser tu novio ~"

# game/script.rpy:823
translate Spanish mchomemorningcreepy_c7fa6cec:

    # "In the corner of my eye, I see Austin's free hand slither it's way around my waist."
    "Por el rabillo del ojo, veo que la mano libre de Austin se desliza hasta mi cintura."

# game/script.rpy:824
translate Spanish mchomemorningcreepy_8538b0a0:

    # "Before I could speak, another man grabs Austin's shoulder and tugs him away from me."
    "Antes de que pueda decir nada, otro hombre agarra a Austin del hombro y lo aparta de mí de un tirón."

# game/script.rpy:831
translate Spanish mchomemorningcreepy_84d09037:

    # j "Hey, are you gonna give [him] the package or not?"
    j "Oye, ¿le vas a dar el paquete o no?"

# game/script.rpy:832
translate Spanish mchomemorningcreepy_518abbba:

    # a "Who the hell are you?"
    a "¿Quién diablos eres tú?"

# game/script.rpy:833
translate Spanish mchomemorningcreepy_7d85ab19:

    # j "That doesn't matter. Give [him] the package."
    j "Eso no importa. Dale el paquete."

# game/script.rpy:834
translate Spanish mchomemorningcreepy_73e66cf4:

    # "Austin looks down at Jacob, not moving an inch."
    "Austin mira a Jacob desde arriba, sin moverse ni un centímetro."

# game/script.rpy:835
translate Spanish mchomemorningcreepy_e4faea03:

    # a "Well it just so happens that this is the last trip I need to make for today."
    a "Bueno, sucede que este es el último viaje que necesito hacer para hoy."

# game/script.rpy:837
translate Spanish mchomemorningcreepy_b9cadb74:

    # a "I don't mind doing a little overtime~"
    a "No me importa echar unas horitas extra~"

# game/script.rpy:841
translate Spanish mchomemorningcreepy_88a5a2e2:

    # j "{size=+10}Give [him] the damn package and get your creepy ass outta here, ya got that!?{/size}"
    j "{size=+10}¡Dale el maldito paquete y lárgate de aquí, pervertido de mierda, ¿¡entendiste!?{/size}"

# game/script.rpy:842
translate Spanish mchomemorningcreepy_c81c739b:

    # "Jacob's voice boomed in my chest."
    "La voz de Jacob retumbó en mi pecho."

# game/script.rpy:843
translate Spanish mchomemorningcreepy_818026e4:

    # "I've never heard him raise his voice like that before..."
    "Nunca lo he escuchado levantar la voz así antes ..."

# game/script.rpy:844
translate Spanish mchomemorningcreepy_3fec87ed:

    # a "Alright! Geez...no need to make a scene. Relax."
    a "¡Ya, ya! Caray... no hace falta hacer un escándalo. Relájate."

# game/script.rpy:846
translate Spanish mchomemorningcreepy_ec46246e:

    # "Austin carelessly tosses my package to me, despite the label saying 'fragile'."
    "Austin me tira descuidadamente mi paquete, a pesar de la etiqueta que dice 'frágil'."

# game/script.rpy:848
translate Spanish mchomemorningcreepy_21f24a75:

    # "He walks back to his mail truck. Before driving off, he gives a wink in my direction."
    "Vuelve a su camión de correo. Antes de arrancar, me guiña un ojo."

# game/script.rpy:851
translate Spanish mchomemorningcreepy_dcfc1116:

    # "It looks like Jacob saw that too, and raises a middle finger at him before he drives off."
    "Parece que Jacob también lo vio y le muestra el dedo medio antes de que se vaya."

# game/script.rpy:854
translate Spanish mchomemorningcreepy_1060efac:

    # me "Um, hey Jacob."
    me "Um, oye, Jacob."

# game/script.rpy:855
translate Spanish mchomemorningcreepy_ca0e185b:

    # j "That guy didn't touch you, right?"
    j "Ese tipo no te tocó, ¿verdad?"

# game/script.rpy:856
translate Spanish mchomemorningcreepy_da95bbf9:

    # me "Well, he had his hand around me, but I was ready to push him away."
    me "Bueno, me rodeó con la mano, pero estaba list[letra] para apartarlo."

# game/script.rpy:857
translate Spanish mchomemorningcreepy_10212615:

    # "I can see Jacob shaking a bit."
    "Puedo ver a Jacob temblando un poco."

# game/script.rpy:858
translate Spanish mchomemorningcreepy_8f008b91:

    # j "If that asshole ever bothers you again, you let ME know, ok?"
    j "Si ese idiota te vuelve a molestar, avísame a MÍ, ¿de acuerdo?"

# game/script.rpy:868
translate Spanish lmk1_4d861b34:

    # "It's probably a good idea to have someone close by as a helpful hand, or even a witness."
    "Probablemente sea una buena idea tener a alguien cerca como una mano útil, o incluso un testigo."

# game/script.rpy:869
translate Spanish lmk1_2d7221d8:

    # "If having another person around me works, then soon enough that creepy mailman will fuck off for good, or at least treat me with respect."
    "Si tener a alguien cerca funciona, ese cartero asqueroso se largará de una vez por todas, o al menos me tratará con respeto."

# game/script.rpy:870
translate Spanish lmk1_504c7bb2:

    # me "Thanks Jacob."
    me "Gracias Jacob."

# game/script.rpy:871
translate Spanish lmk1_9cd716a3:

    # "I look down at my box."
    "Miro mi caja."

# game/script.rpy:873
translate Spanish lmk1_c2dda607:

    # me "But hey, at least my mail arrived at MY door this time!"
    me "Pero bueno, ¡al menos mi correo llegó a MI puerta esta vez!"

# game/script.rpy:874
translate Spanish lmk1_bc66a967:

    # "He stays quiet."
    "Se queda en silencio."

# game/script.rpy:875
translate Spanish lmk1_984f6b91:

    # j "...Yeah."
    j "...Sí."

# game/script.rpy:880
translate Spanish lmk2_527b13e3:

    # "As much as I'm glad Jacob stepped in, I wasn't scared of Austin or anything. He was just an annoying weirdo."
    "Por mucho que me alegre de que Jacob interviniera, no tenía miedo de Austin ni nada. Era solo un bicho raro molesto."

# game/script.rpy:881
translate Spanish lmk2_2f4270e7:

    # "Plus, I'd feel bad if I got neighbors involved with my own problems."
    "Además, me sentiría mal si metiera a los vecinos en mis propios problemas."

# game/script.rpy:882
translate Spanish lmk2_9074e9d6:

    # me "That guy was just a fuckboy. I don't think he'll do anything too brash though."
    me "Ese tipo es solo un fuckboy. Aunque no creo que haga nada demasiado temerario."

# game/script.rpy:883
translate Spanish lmk2_0352f649:

    # j "But how can you be so sure? He was too close to you..."
    j "Pero, ¿cómo puedes estar tan segur[letra]? Estaba demasiado cerca de ti..."

# game/script.rpy:885
translate Spanish lmk2_b9255947:

    # j "What if he grabs you next time? Or tries to...t-to-"
    j "¿Qué pasa si te agarra la próxima vez? O intenta ... t-to-"

# game/script.rpy:886
translate Spanish lmk2_476cf931:

    # me "Jacob, I know you're concerned, but I can handle a lot that comes my way, ok?"
    me "Jacob, sé que estás preocupado, pero puedo manejar lo que sea que se me presente, ¿ok?"

# game/script.rpy:888
translate Spanish lmk2_bc66a967:

    # "He stays quiet."
    "Se queda en silencio."

# game/script.rpy:889
translate Spanish lmk2_618c5fea:

    # j "...Alright."
    j "...Está bien."

# game/script.rpy:895
translate Spanish walky_b3e01615:

    # me "Ok Jacob, I'll see you later."
    me "Ok Jacob, te veré más tarde."

# game/script.rpy:896
translate Spanish walky_aeec7a9e:

    # j "Goodbye [playerName]."
    j "Adiós [playerName]."

# game/script.rpy:898
translate Spanish walky_53795052:

    # "I close my front door and begin opening my package."
    "Cierro mi puerta de entrada y empiezo a abrir mi paquete."

# game/script.rpy:901
translate Spanish walky_02eda831:

    # "Cutting open the tape, I look into the contents inside and find..."
    "Corto la cinta, miro dentro y encuentro..."

# game/script.rpy:904
translate Spanish walky_7dcc624d:

    # "My new Mewsheen Kitty mug and matching bowl!"
    "¡Mi nueva taza Mewsheen Kitty y el tazón a juego!"

# game/script.rpy:905
translate Spanish walky_3838a37e:

    # "I'm glad these didn't get damaged during shipping, or with Austin's poor handling."
    "Me alegra que no se hayan dañado en el envío ni por el mal trato de Austin."

# game/script.rpy:906
translate Spanish walky_14d150ce:

    # "I set my new mug and bowl in my kitchen to use later."
    "Dejo mi nueva taza y el tazón en la cocina para usarlos más tarde."

# game/script.rpy:908
translate Spanish walky_c36579d6:

    # "Since today is my day off, I think it would be a good time to explore the town."
    "Dado que hoy es mi día libre, creo que sería un buen momento para explorar el pueblo."

# game/script.rpy:909
translate Spanish walky_79767198:

    # "The Texas heat has kept me indoors for a while, but since it's autumn, the weather has gotten cooler."
    "El calor de Texas me ha mantenido encerrad[letra] un tiempo, pero como ya es otoño, el clima se ha vuelto más fresco."

# game/script.rpy:910
translate Spanish walky_23e88e38:

    # "I make my way upstairs to get properly dressed and walk to the park."
    "Subo las escaleras para vestirme bien y caminar hasta el parque."

# game/script.rpy:917
translate Spanish parky_70d42bb0:

    # "This park in the neighborhood has a few trails, some benches and a playground."
    "Este parque en el vecindario tiene algunos senderos, algunos bancos y un parque infantil."

# game/script.rpy:918
translate Spanish parky_046ab403:

    # "A lot of orange trees and colorful flowers spread along the path I'm walking on."
    "Muchos naranjos y flores de colores se extienden a lo largo del camino por el que paseo."

# game/script.rpy:919
translate Spanish parky_a35bfb80:

    # "It really is nice to get out of the house for a little while."
    "Realmente es bueno salir de la casa por un tiempo."

# game/script.rpy:920
translate Spanish parky_54a13cc0:

    # "I take in a deep breathe of fresh air and the surrounding noise of the wind, the birds, and..."
    "Respiro hondo el aire fresco y escucho los sonidos a mi alrededor: el viento, los pájaros y..."

# game/script.rpy:927
translate Spanish parky_799ff1f7:

    # "...a camera shutter?"
    "...¿el clic de una cámara?"

# game/script.rpy:930
translate Spanish parky_bfa858b8:

    # "Looks like my neighbor is here at the park too."
    "Parece que mi vecino también está aquí en el parque."

# game/script.rpy:931
translate Spanish parky_8564ceea:

    # "I didn't know he's into photography. His camera is aiming in my direction."
    "No sabía que le gustaba la fotografía. Su cámara apunta en mi dirección."

# game/script.rpy:932
translate Spanish parky_6a6c96c5:

    # "He stops taking pictures when our gaze meet eachother."
    "Deja de tomar fotos cuando nuestras miradas se cruzan."

# game/script.rpy:935
translate Spanish parky_649b2f5e:

    # j "[playerName]! Nice seeing you so soon."
    j "¡[playerName]! Qué gusto verte tan pronto."

# game/script.rpy:944
translate Spanish parkpic1_d50120a0:

    # j "No, I'm taking pictures of the fountain."
    j "No, estoy tomando fotos de la fuente."

# game/script.rpy:945
translate Spanish parkpic1_7a693cd3:

    # me "Alright...but, is it ok if you point the camera in another direction?"
    me "Muy bien ... pero, ¿está bien si apuntas la cámara en otra dirección?"

# game/script.rpy:946
translate Spanish parkpic1_f528b097:

    # "He takes in a deep breathe and looks down at his camera."
    "Respira hondo y mira su cámara."

# game/script.rpy:948
translate Spanish parkpic1_743f497d:

    # j "Sure. Sorry 'bout that."
    j "Claro. Perdona por eso."

# game/script.rpy:953
translate Spanish parkpic2_71ca20fe:

    # j "Oh, just the fountain here. Also some of the surrounding scenery."
    j "Oh, solo la fuente aquí. También algunos de los paisajes circundantes."

# game/script.rpy:956
translate Spanish parkpic2_b28580f5:

    # "He looks down at his camera."
    "Mira su cámara."

# game/script.rpy:957
translate Spanish parkpic2_a279220e:

    # me "So Jacob, are you some kind of photographer?"
    me "Entonces Jacob, ¿eres una especie de fotógrafo?"

# game/script.rpy:958
translate Spanish parkpic2_0ec067e8:

    # j "Yup. It started out as a hobby during high school, and eventually it became a nice side job for me."
    j "Sí. Comenzó como un pasatiempo durante la escuela secundaria, y finalmente se convirtió en un buen trabajo secundario para mí."

# game/script.rpy:960
translate Spanish parkpic2_f8cf2d3b:

    # j "I love what I do."
    j "Amo lo que hago."

# game/script.rpy:961
translate Spanish parkpic2_7d181f4f:

    # me "That's good to hear! Do you have any favorite pictures you've taken lately?"
    me "¡Me alegra oírlo! ¿Tienes alguna foto favorita de las que has hecho últimamente?"

# game/script.rpy:963
translate Spanish parkpic2_57548038:

    # j "Y-Yeah…but since I'm using a film camera, the pictures have to be physically developed to view them."
    j "S-sí... pero como uso una cámara analógica, hay que revelar las fotos en físico para verlas."

# game/script.rpy:965
translate Spanish parkpic2_73813afd:

    # j "It does take some work, but the process is worth it. The results look phenomenal."
    j "Se necesita algo de trabajo, pero el proceso vale la pena. Los resultados se ven fenomenales."

# game/script.rpy:966
translate Spanish parkpic2_91d50ee2:

    # "Jacob fiddles with his camera strap for a bit and keeps one hand on his lens. His other hand looks ready to press a button."
    "Jacob juguetea un poco con la correa de la cámara y mantiene una mano sobre el lente. Su otra mano parece lista para presionar un botón."

# game/script.rpy:968
translate Spanish parkpic2_4780359f:

    # j "Hey [playerName], would you like to…be a model for me? All you have to do is strike a couple of poses. I need some new material for my portfolio."
    j "Oye, [playerName], ¿te gustaría... ser mi modelo? Solo tendrías que adoptar un par de poses. Necesito material nuevo para mi portafolio."

# game/script.rpy:978
translate Spanish yaspics_ff03acfd:

    # me "Sounds like fun! Do you have any particular poses you want me to try?"
    me "¡Suena divertido! ¿Tienes alguna postura en particular que quieras que pruebe?"

# game/script.rpy:980
translate Spanish yaspics_a5d85f48:

    # j "Anything that makes you comfortable."
    j "Lo que te haga sentir a gusto."

# game/script.rpy:981
translate Spanish yaspics_f273535b:

    # "I try pulling off some simple poses, like peace-signs with my hands and sitting at the fountain."
    "Pruebo algunas poses sencillas, como hacer el símbolo de la paz con las manos y sentarme junto a la fuente."

# game/script.rpy:985
translate Spanish yaspics_adae494b:

    # "I give some smiles and a few stoic looks. The constant shuttering from Jacob's camera tells me he's really into this."
    "Sonrío un poco y pongo alguna que otra cara seria. El constante clic del obturador de Jacob me dice que está muy metido en esto."

# game/script.rpy:990
translate Spanish yaspics_0e3f67a1:

    # j "Yes, just like that…"
    j "Sí, justo así..."

# game/script.rpy:992
translate Spanish yaspics_09648ca3:

    # "I try out some other poses, a few of which were from anime shows I've watched."
    "Pruebo otras poses, algunas sacadas de series de anime que he visto."

# game/script.rpy:996
translate Spanish yaspics_8b27174a:

    # "I see his expression change to a smirk. I wonder if he got my references."
    "Veo que su expresión cambia a una sonrisilla. Me pregunto si habrá captado mis referencias."

# game/script.rpy:997
translate Spanish yaspics_0a0c103f:

    # j "You know [playerName], I don't know if anyone's told you this before, but..."
    j "Sabes [playerName], no sé si alguien te ha dicho esto antes, pero ..."

# game/script.rpy:999
translate Spanish yaspics_631d5bf1:

    # j "...you're REALLY photogenic."
    j "...eres MUY fotogénic[letra]."

# game/script.rpy:1000
translate Spanish yaspics_79e00e15:

    # me "'Photogenic'?"
    me "¿'Fotogénic[letra]'?"

# game/script.rpy:1002
translate Spanish yaspics_3e19a4c9:

    # j "It means you naturally look great in photographs."
    j "Significa que naturalmente te ves genial en las fotografías."

# game/script.rpy:1003
translate Spanish yaspics_3d31aafd:

    # "I can feel my face blushing."
    "Puedo sentir mi cara sonrojándose."

# game/script.rpy:1004
translate Spanish yaspics_f9684635:

    # me "Aww, that's really sweet of you to say!"
    me "¡Aww, qué lindo de tu parte decirlo!"

# game/script.rpy:1005
translate Spanish yaspics_b903f5d8:

    # "Jacob flips his camera to it's side and holds down a button on the bottom. His other hand flicks up a tab from the top of the camera and begins turning a knob."
    "Jacob gira la cámara de lado y mantiene pulsado un botón de la parte inferior. Con la otra mano levanta una pestaña de la parte superior y empieza a girar una rueda."

# game/script.rpy:1006
translate Spanish yaspics_85d3f5e0:

    # j "Looks like I've used up my roll of film. I look forward to developing these later."
    j "Parece que terminé el rollo. Tengo ganas de revelar las fotos más tarde."

# game/script.rpy:1007
translate Spanish yaspics_440eed53:

    # j "Thank you for being my model, [playerName]."
    j "Gracias por ser mi modelo, [playerName]."

# game/script.rpy:1008
translate Spanish yaspics_e209cae2:

    # me "It's no problem Jacob, I'm happy I could help!"
    me "No hay problema, Jacob, ¡me alegra haber podido ayudar!"

# game/script.rpy:1010
translate Spanish yaspics_ec6b33ce:

    # me "I can't wait to see how your photos turn out! Do you have a website I can view them on? Or maybe make some physical copies? I'd love to own a few!"
    me "¡Qué ganas de ver cómo quedan tus fotos! ¿Tienes alguna página web donde pueda verlas? ¿O podrías hacer copias en papel? ¡Me encantaría tener alguna!"

# game/script.rpy:1011
translate Spanish yaspics_dd8f558c:

    # j "Actually these are, uhh......"
    j "En realidad estos son, uhh ......"

# game/script.rpy:1013
translate Spanish yaspics_20d73707:

    # j "They're for a private portfolio..."
    j "Son para un portafolio privado..."

# game/script.rpy:1014
translate Spanish yaspics_57de028b:

    # "I feel taken aback."
    "Me siento desconcertad[letra]."

# game/script.rpy:1015
translate Spanish yaspics_3730ba64:

    # me "'Private'?"
    me "¿'Privado'?"

# game/script.rpy:1017
translate Spanish yaspics_335e3ce8:

    # j "Yeah, my private portfolio is meant for like, showing it to professional companies and stuff. If I post my best work publically, people might steal my work, you know?"
    j "Sí, mi portafolio privado es para enseñárselo a empresas del sector y cosas así. Si publico mi mejor trabajo públicamente, la gente podría robar mi trabajo, ¿sabes?"

# game/script.rpy:1018
translate Spanish yaspics_4241848d:

    # "I suppose that makes sense."
    "Supongo que eso tiene sentido."

# game/script.rpy:1019
translate Spanish yaspics_d903e518:

    # me "Aw, ok then. Well, good luck with your portfolio, I'll see you around!"
    me "Ah, ok. Bueno, mucha suerte con tu portafolio, ¡nos vemos por ahí!"

# game/script.rpy:1021
translate Spanish yaspics_f0b2477d:

    # j "Bye [playerName], thanks again~."
    j "Adiós [playerName], gracias de nuevo ~."

# game/script.rpy:1027
translate Spanish nopicsforyou_8e980723:

    # "I'm not really comfortable with getting my picture taken on a whim."
    "No me siento muy cómod[letra] con que me tomen una foto así, de repente."

# game/script.rpy:1028
translate Spanish nopicsforyou_ee743d90:

    # "Hopefully he'll understand."
    "Ojalá lo entienda."

# game/script.rpy:1030
translate Spanish nopicsforyou_392972f4:

    # me "I don't think I look my best right now, maybe next time?"
    me "No creo que esté en mi mejor momento ahora mismo, ¿quizá la próxima vez?"

# game/script.rpy:1031
translate Spanish nopicsforyou_98c8b135:

    # j "I think you look just fine. Are you sure you can't do just a few photos?"
    j "Creo que te ves bien. ¿Seguro que no puedes posar para unas pocas fotos?"

# game/script.rpy:1032
translate Spanish nopicsforyou_829b5a1d:

    # me "Well, I'm just here for a short walk, I still have other things to do today, sorry."
    me "Bueno, solo estoy aquí para una corta caminata, todavía tengo otras cosas que hacer hoy, lo siento."

# game/script.rpy:1033
translate Spanish nopicsforyou_7f63ed4c:

    # "The man's grip on his camera got tighter."
    "El hombre apretó con más fuerza su cámara."

# game/script.rpy:1034
translate Spanish nopicsforyou_e7c39d59:

    # j "Alright, see you later then, [playerName]."
    j "Muy bien, nos vemos más tarde entonces, [playerName]."

# game/script.rpy:1038
translate Spanish parkhome_181049e1:

    # "I walk away from the fountain and follow a different path."
    "Me alejo de la fuente y sigo un camino diferente."

# game/script.rpy:1040
translate Spanish parkhome_3a174796:

    # "The fallen leaves give a nice crunch underneath each of my steps."
    "Las hojas caídas dan un buen crujido debajo de cada uno de mis pasos."

# game/script.rpy:1041
translate Spanish parkhome_43a66161:

    # "I sit myself down at a nearby bench. This park is nice, but I'm curious what else the town has to offer."
    "Me siento en un banco cercano. Este parque es agradable, pero tengo curiosidad por saber qué más ofrece el pueblo."

# game/script.rpy:1042
translate Spanish parkhome_a1a6abb6:

    # "I get out my phone and searched for what stores are nearby. Other than the grocery store and a small retail outlet, looks like there's a mall!"
    "Saco mi teléfono y busco qué tiendas están cerca. Además de la tienda de comestibles y una pequeña tienda minorista, ¡parece que hay un centro comercial!"

# game/script.rpy:1043
translate Spanish parkhome_3c41b85a:

    # "The day is still young, time to head back."
    "Todavía es temprano, es hora de regresar."

# game/script.rpy:1046
translate Spanish parkhome_4953a290:

    # "As I make my way back home, I grab my car keys and drive my way to the local mall."
    "Cuando regreso a casa, tomo las llaves de mi auto y conduzco hacia el centro comercial local."

# game/script.rpy:1049
translate Spanish parkhome_04268c5a:

    # "I'm surprised to find a Pop Topic shop inside the mall, I haven't been inside one of these since I was a teenager."
    "Me sorprende encontrar una tienda Pop Topic en el centro comercial; hace años que no entro en una, desde la adolescencia."

# game/script.rpy:1050
translate Spanish parkhome_266bf520:

    # "The walls were covered in shirt designs for sale, ranging from bands, cartoons, and anime."
    "Las paredes estaban cubiertas de diseños de camisas para la venta, que van desde bandas, dibujos animados y anime."

# game/script.rpy:1051
translate Spanish parkhome_fe2c632d:

    # "I turn to my left to spot a whole section dedicated to plushies."
    "Me giro a la izquierda y veo una sección entera dedicada a los peluches."

# game/script.rpy:1052
translate Spanish parkhome_0cdc5486:

    # "Wait, is that-"
    "Espera, ¿eso es-"

# game/script.rpy:1055
translate Spanish parkhome_57712f5f:

    # "A JUMBO SIZED MEWSHEEN PLUSH!?"
    "¿¡UN PELUCHE MEWSHEEN TAMAÑO JUMBO!?"

# game/script.rpy:1056
translate Spanish parkhome_f81377c5:

    # "I squeeze the plush, then give it a big hug."
    "Aprieto el peluche y luego le doy un gran abrazo."

# game/script.rpy:1057
translate Spanish parkhome_b9e6497b:

    # "OH...MY...GOD..."
    "AY... DIOS... MÍO..."

# game/script.rpy:1058
translate Spanish parkhome_75922325:

    # "IT'S SO SQUISHY!!!"
    "¡¡¡ES TAN BLANDITO!!!"

# game/script.rpy:1059
translate Spanish parkhome_e16585fe:

    # "I slam my money down on the counter and pay for my new plush."
    "Planto el dinero en el mostrador y pago mi nuevo peluche."

# game/script.rpy:1060
translate Spanish parkhome_390ccafd:

    # "No way was I going to leave without him."
    "De ninguna manera iba a irme sin él."

# game/script.rpy:1063
translate Spanish parkhome_27d81f5b:

    # "After some further browsing of the other shops, I didn't see anything else that interested me."
    "Tras curiosear un rato por las otras tiendas, no veo nada más que me interese."

# game/script.rpy:1064
translate Spanish parkhome_f8e21583:

    # "Although, the food court looks pretty good."
    "Aunque, el patio de comidas se ve bastante bien."

# game/script.rpy:1065
translate Spanish parkhome_2cb08e3c:

    # "I was so busy shopping I completely forgot to have lunch...It's already dinner time!"
    "Estaba tan metid[letra] en las compras que me olvidé por completo de almorzar... ¡Ya es hora de cenar!"

# game/script.rpy:1066
translate Spanish parkhome_9bcf46fe:

    # "I scan over the different options available, and a red glowing sign catches my eye."
    "Repaso las opciones disponibles y un letrero rojo luminoso me llama la atención."

# game/script.rpy:1067
translate Spanish parkhome_acaed484:

    # "Behind the glass, there's an array of noodles, rice, and all sorts of different veggies and meats."
    "Detrás del cristal hay fideos, arroz y todo tipo de verduras y carnes."

# game/script.rpy:1068
translate Spanish parkhome_2aee1180:

    # "Pad kra pao, pho, pork larb, tom yum soup..."
    "Pad kra pao, pho, larb de cerdo, sopa tom yum..."

# game/script.rpy:1069
translate Spanish parkhome_b8b788b5:

    # "Thai food sounds great right now!"
    "¡La comida tailandesa suena genial ahora mismo!"

# game/script.rpy:1070
translate Spanish parkhome_734f6eec:

    # "I step into the line and wait among the other customers."
    "Me pongo en la fila y espero con los demás clientes."

# game/script.rpy:1071
translate Spanish parkhome_899cb01f:

    # aa "So, what are you gettin'?"
    aa "Entonces, ¿qué vas a pedir?"

# game/script.rpy:1072
translate Spanish parkhome_3ab3935c:

    # me "Hm?"
    me "¿Mm?"

# game/script.rpy:1073
translate Spanish parkhome_638362c4:

    # "I turn to the voice behind me."
    "Me vuelvo hacia la voz detrás de mí."

# game/script.rpy:1076
translate Spanish parkhome_62341b4d:

    # "Man, not this guy..."
    "Ay, no, este tipo..."

# game/script.rpy:1078
translate Spanish parkhome_b40b667f:

    # a "I said what are you gettin'? Chinese food?"
    a "Dije que qué vas a pedir. ¿Comida china?"

# game/script.rpy:1079
translate Spanish parkhome_85d1648a:

    # me "No, this is the line for Thai food."
    me "No, esta es la fila de la comida tailandesa."

# game/script.rpy:1081
translate Spanish parkhome_84d5fb94:

    # a "Same thing."
    a "Lo mismo."

# game/script.rpy:1083
translate Spanish parkhome_f858c582:

    # a "So what's good here?"
    a "Entonces, ¿qué tienen de bueno aquí?"

# game/script.rpy:1084
translate Spanish parkhome_cbccf519:

    # me "I was just gonna get some take out from here, maybe some pork larb, it looks good."
    me "Solo iba a pedir algo para llevar de aquí, tal vez un poco de larb de cerdo, se ve bien."

# game/script.rpy:1085
translate Spanish parkhome_1a6bdc6f:

    # a "What's that?"
    a "¿Qué es eso?"

# game/script.rpy:1086
translate Spanish parkhome_7640e7d5:

    # me "It's a dish with seasoned pork mixed with some chili and vegetables."
    me "Es un plato con cerdo sazonado mezclado con un poco de chile y verduras."

# game/script.rpy:1087
translate Spanish parkhome_215d3ce6:

    # me "You can wrap it in some lettuce and eat it like that, or you can eat it with a side of rice."
    me "Puedes envolverlo en un poco de lechuga y comerlo así, o con arroz de acompañamiento."

# game/script.rpy:1088
translate Spanish parkhome_624eafab:

    # me "It's really good!"
    me "¡Es realmente bueno!"

# game/script.rpy:1089
translate Spanish parkhome_47760acf:

    # a "Hm. What else is there?"
    a "Hm. ¿Qué más hay?"

# game/script.rpy:1090
translate Spanish parkhome_b65bcfec:

    # "I point at the large TV screens behind the workers."
    "Apunto a las grandes pantallas de televisión detrás de los trabajadores."

# game/script.rpy:1091
translate Spanish parkhome_f360af36:

    # me "Well, they do have a GIANT menu you can read from, Austin."
    me "Bueno, tienen un menú GIGANTE que puedes leer, Austin."

# game/script.rpy:1093
translate Spanish parkhome_3d57d1c5:

    # a "Oh? You remembered my name~?"
    a "¿Oh? ¿Recuerdas mi nombre ~?"

# game/script.rpy:1094
translate Spanish parkhome_26382fb2:

    # "...Seriously?"
    "...¿En serio?"

# game/script.rpy:1095
translate Spanish parkhome_bc8ff37c:

    # "I rolled my eyes and turn away from him."
    "Pongo los ojos en blanco y me giro para darle la espalda."

# game/script.rpy:1096
translate Spanish parkhome_4bfba3ee:

    # "Can't this line move any faster!?"
    "¡¿Es que esta fila no puede avanzar más rápido?!"

# game/script.rpy:1097
translate Spanish parkhome_d4ccc15a:

    # a "Aww, c'mon now, I think it's really sweet you remembered!"
    a "¡Ay, vamos, creo que es muy lindo que lo hayas recordado!"

# game/script.rpy:1098
translate Spanish parkhome_3847eb39:

    # a "We only just met and now you're already thinkin' about me? I'm flattered [playerName]~"
    a "¿Apenas nos conocimos y ya estás pensando en mí? Estoy halagado, [playerName]~"

# game/script.rpy:1107
translate Spanish foff_97949518:

    # me "Look, Austin...I just wanna get my dinner and go home, I'm not in the mood to talk right now."
    me "Mira, Austin... solo quiero pedir mi cena e irme a casa, no estoy de humor para hablar ahora."

# game/script.rpy:1108
translate Spanish foff_f5a0f141:

    # a "Wow, that's cold."
    a "Vaya, qué frí[letra]."

# game/script.rpy:1110
translate Spanish foff_70c373af:

    # a "But hey, I get it. You're just moody 'cause you're hungry."
    a "Pero bueno, lo entiendo. Estás de mal humor porque tienes hambre."

# game/script.rpy:1111
translate Spanish foff_37db53b6:

    # a "You said you're gettin' pork, right? Heh."
    a "Dijiste que ibas a pedir cerdo, ¿verdad? Je."

# game/script.rpy:1112
translate Spanish foff_58aa1b1a:

    # a "Do ya like pork sausage too?"
    a "¿También te gusta la salchicha de cerdo?"

# game/script.rpy:1113
translate Spanish foff_11996936:

    # a "If you ever wanna come over to MY place for dinner, I can show you a REAL good pork sausage."
    a "Si alguna vez quieres venir a cenar a MI casa, puedo mostrarte una salchicha de cerdo MUY buena."

# game/script.rpy:1114
translate Spanish foff_b43d0d1b:

    # "This fucking pervert."
    "Este maldito pervertido."

# game/script.rpy:1115
translate Spanish foff_e04f28f5:

    # "I'm not gonna answer any of his dumb questions anymore."
    "Ya no voy a responder ninguna de sus preguntas tontas."

# game/script.rpy:1119
translate Spanish igno_3820771a:

    # me "..."
    me "..."

# game/script.rpy:1120
translate Spanish igno_83ad0531:

    # a "Hey, it's rude to ignore someone when they're talkin' to ya."
    a "Oye, es grosero ignorar a alguien cuando te hablan."

# game/script.rpy:1121
translate Spanish igno_3820771a_1:

    # me "..."
    me "..."

# game/script.rpy:1122
translate Spanish igno_286577e3:

    # a "...[playerName]."
    a "... [playerName]."

# game/script.rpy:1123
translate Spanish igno_3820771a_2:

    # me "..."
    me "..."

# game/script.rpy:1124
translate Spanish igno_da830915:

    # a "You're being a stick in the mud, c'mon now."
    a "Qué aguafiestas eres, ya, vamos."

# game/script.rpy:1126
translate Spanish igno_7e2c6719:

    # a "Tell ya what, how 'bout I give you my number? I already remember your address, I can pick you up anytime you want, just gimme a call~"
    a "Te digo qué: ¿y si te doy mi número? Ya me sé tu dirección, puedo pasar por ti cuando quieras, solo llámame~"

# game/script.rpy:1127
translate Spanish igno_fb5b8ba8:

    # "Ugh, does this creep ever shut up!?"
    "Ugh, ¿es que este tipo asqueroso nunca se calla?"

# game/script.rpy:1128
translate Spanish igno_947de3d3:

    # "Who even says shit like this?"
    "¿Quién diablos dice cosas así?"

# game/script.rpy:1129
translate Spanish igno_316cf797:

    # "Austin takes out a crusty napkin and pen from his pocket. He scribbles down his number and hands it to me."
    "Austin saca una servilleta arrugada y sucia y un bolígrafo del bolsillo. Garabatea su número y me lo entrega."

# game/script.rpy:1131
translate Spanish igno_b470503b:

    # me "I don't want it."
    me "No lo quiero."

# game/script.rpy:1132
translate Spanish igno_13339554:

    # a "Oh, I get it now."
    a "Oh, lo entiendo ahora."

# game/script.rpy:1134
translate Spanish igno_59303b43:

    # a "You ain't much of a phone caller, huh? It's fine, I understand."
    a "No eres de hablar por teléfono, ¿eh? Está bien, lo entiendo."

# game/script.rpy:1135
translate Spanish igno_be85f668:

    # a "How 'bout we just text? Or would you rather have me come over instead?"
    a "¿Qué tal si solo nos mandamos mensajes? ¿O prefieres que mejor vaya yo a tu casa?"

# game/script.rpy:1143
translate Spanish cantigno_3820771a:

    # me "..."
    me "..."

# game/script.rpy:1144
translate Spanish cantigno_b651d6a5:

    # a "Take my number."
    a "Toma mi número."

# game/script.rpy:1152
translate Spanish giveaustin_40690d18:

    # "It's clear this guy isn't going to leave me alone."
    "Está claro que este tipo no me va a dejar en paz."

# game/script.rpy:1153
translate Spanish giveaustin_e53c4ae0:

    # "Looks like I'll play along, even if it means feeding his already big ego..."
    "Parece que le seguiré el juego, aunque eso signifique alimentar su ya enorme ego..."

# game/script.rpy:1154
translate Spanish giveaustin_610a50b8:

    # "I swipe the napkin out of his hand and crumple it into my pocket."
    "Le arrebato la servilleta de la mano y me la meto arrugada en el bolsillo."

# game/script.rpy:1155
translate Spanish giveaustin_54a258fa:

    # "Hopefully that'll shut him up."
    "Con suerte, eso lo calla."

# game/script.rpy:1156
translate Spanish giveaustin_6130ca25:

    # a "Ha! I knew you wanted me. I'll see you 'round [playerName]. I'm not really in the mood for Chinese food."
    a "¡Ja! Sabía que me querías. Nos vemos por ahí, [playerName]. La verdad, ya no se me antoja la comida china."

# game/script.rpy:1158
translate Spanish giveaustin_e4adea70:

    # "Finally that creep left."
    "Por fin se fue ese asqueroso."

# game/script.rpy:1159
translate Spanish giveaustin_9c245c83:

    # "I let out a sigh and inch my way forward in line."
    "Suelto un suspiro y avanzo poco a poco en la fila."

# game/script.rpy:1160
translate Spanish giveaustin_60647ad9:

    # "Eventually I order my pork larb and some eggrolls to go."
    "Al final pido mi larb de cerdo y unos rollitos fritos para llevar."

# game/script.rpy:1161
translate Spanish giveaustin_07374125:

    # "I think I'd rather eat my dinner in peace at home than here..."
    "Creo que prefiero comer mi cena en paz en casa que aquí ..."

# game/script.rpy:1164
translate Spanish giveaustin_e1b0ef96:

    # "I drive back home and I can feel my stomach rumble."
    "Conduzco de regreso a casa mientras me ruge el estómago."

# game/script.rpy:1167
translate Spanish giveaustin_0235221f:

    # "The moon is already out by the time I walk through my door."
    "La luna ya brilla en el cielo cuando cruzo la puerta de mi casa."

# game/script.rpy:1168
translate Spanish giveaustin_aa403d74:

    # "I set my Mewsheen plush on the couch and search through the plastic bag full of food."
    "Dejo mi peluche de Mewsheen en el sofá y busco en la bolsa de plástico llena de comida."

# game/script.rpy:1169
translate Spanish giveaustin_5bb6088e:

    # "Yikes...the sauce for the eggrolls leaked everywhere. The styrofoam box is drenched."
    "Uy... La salsa de los rollitos se derramó por todos lados. La caja de unicel está empapada."

# game/script.rpy:1170
translate Spanish giveaustin_d88d063b:

    # "Hmm, I do have that Mewsheen dinnerware set. I'll just scoop my food into that!"
    "Mmm, es cierto que tengo esa vajilla de Mewsheen. ¡Pasaré mi comida ahí y listo!"

# game/script.rpy:1171
translate Spanish giveaustin_0033b7d7:

    # "I open my cupboards and grab the matching bowl and mug."
    "Abro mis armarios y agarro el tazón y la taza a juego."

# game/script.rpy:1174
translate Spanish giveaustin_d2fa56e5:

    # "I slide my dinner into the clean bowl and pour myself a glass of refreshing water."
    "Paso mi cena al tazón limpio y me sirvo un vaso de agua fresca."

# game/script.rpy:1175
translate Spanish giveaustin_3d17fbe6:

    # "...!?"
    "...!?"

# game/script.rpy:1176
translate Spanish giveaustin_64c5396f:

    # "Water droplets spilt right onto my shirt."
    "Unas gotas de agua se derramaron justo sobre mi camiseta."

# game/script.rpy:1177
translate Spanish giveaustin_63a0b319:

    # "My mug is chipped! Was that there before?"
    "¡A mi taza se le saltó un pedacito del borde! ¿Ya estaba así antes?"

# game/script.rpy:1178
translate Spanish giveaustin_e2f57f28:

    # "Hm, Austin {i}did{/i} toss me my package instead of just handing it over."
    "Mm, Austin {i}sí{/i} me tiró el paquete en lugar de simplemente entregármelo."

# game/script.rpy:1179
translate Spanish giveaustin_ff294e67:

    # "Unless, maybe he dropped the box before ringing my doorbell?"
    "A menos que, tal vez, se le haya caído la caja antes de tocar el timbre..."

# game/script.rpy:1180
translate Spanish giveaustin_eca68782:

    # "I guess I'll just turn this into a pencil holder later."
    "Supongo que luego la convertiré en un portalápices."

# game/script.rpy:1182
translate Spanish giveaustin_2209abf2:

    # "I bring my dinner to my office and turn on my PC."
    "Llevo mi cena a mi oficina y enciendo mi PC."

# game/script.rpy:1184
translate Spanish giveaustin_6c6e94ac:

    # "I set my dinner down at my desk and eat while browsing the web."
    "Dejo mi cena en el escritorio y como mientras navego por internet."

# game/script.rpy:1185
translate Spanish giveaustin_623a09d0:

    # "It's been a while since I've checked my FriendSpace account, let's see what's new..."
    "Ha pasado un tiempo desde que revisé mi cuenta de FriendSpace, veamos qué hay de nuevo ..."

# game/script.rpy:1187
translate Spanish giveaustin_b2015316:

    # "Everything looks about the same until I opened my notification box."
    "Todo se ve casi igual hasta que abro mi bandeja de notificaciones."

# game/script.rpy:1188
translate Spanish giveaustin_54e6a8db:

    # "Wow, this person liked a lot of posts I made."
    "Vaya, a esta persona le gustaron muchas publicaciones que hice."

# game/script.rpy:1189
translate Spanish giveaustin_2b750865:

    # "Looks like I received a friend request from a user named 'salmonvhs'."
    "Parece que recibí una solicitud de amistad de un usuario llamado 'salmonvhs'."

# game/script.rpy:1190
translate Spanish giveaustin_bf565d5a:

    # "I click on his profile."
    "Hago clic en su perfil."

# game/script.rpy:1193
translate Spanish giveaustin_7e6b1ed6:

    # "Oh, it's my neighbor's profile!"
    "¡Oh, es el perfil de mi vecino!"

# game/script.rpy:1194
translate Spanish giveaustin_536d6ab5:

    # "Most of his posts are him advertising his photography business."
    "La mayoría de sus publicaciones son anuncios de su negocio de fotografía."

# game/script.rpy:1195
translate Spanish giveaustin_d07135cc:

    # "Apparently he also fixes computers. He does come off as someone who's tech savvy."
    "Al parecer también arregla computadoras. Sí da la impresión de ser alguien que sabe de tecnología."

# game/script.rpy:1196
translate Spanish giveaustin_cf011c50:

    # "I scroll down and notice that his friend's list only had two people."
    "Bajo un poco y noto que su lista de amigos solo tiene dos personas."

# game/script.rpy:1197
translate Spanish giveaustin_603c0574:

    # "One account is named 'John Alden'. It's probably one of Jacob's family members."
    "Una cuenta se llama 'John Alden'. Probablemente sea uno de los miembros de la familia de Jacob."

# game/script.rpy:1198
translate Spanish giveaustin_90827440:

    # "The second profile seems to be a meme account."
    "El segundo perfil parece ser una cuenta de meme."

# game/script.rpy:1199
translate Spanish giveaustin_eaf052bb:

    # "He's gotten the most comments under a post about a lost TV show he's been archiving."
    "Ha recibido la mayoría de los comentarios en una publicación sobre un programa de televisión perdido que ha estado archivando."

# game/script.rpy:1200
translate Spanish giveaustin_3d5d8966:

    # "Something called...'Bappy the Horse'. Never heard of it."
    "Algo llamado ... 'Bappy the Horse'. Nunca he oído hablar de eso."

# game/script.rpy:1201
translate Spanish giveaustin_39704f86:

    # "But it looks like a lot of people were thankful he posted lost footage of this 1960s cartoon."
    "Pero parece que mucha gente le agradeció que publicara imágenes perdidas de esta caricatura de los años 60."

# game/script.rpy:1202
translate Spanish giveaustin_230f3860:

    # "Other than that and the occassional reblog by John Alden, he doesn't seem to get any other interactions."
    "Aparte de eso y algún reblog ocasional de John Alden, no parece tener más interacciones."

# game/script.rpy:1203
translate Spanish giveaustin_0389142d:

    # "I hover my mouse over the request notification."
    "Paso el mouse por encima de la notificación de la solicitud."

# game/script.rpy:1212
translate Spanish yasfren_4a905e0b:

    # "He seems like a lonely guy...I'm sure it wouldn't hurt to add him."
    "Parece un tipo solitario... Estoy segur[letra] de que no estaría de más agregarlo."

# game/script.rpy:1213
translate Spanish yasfren_d3a3ae1c:

    # "I do wanna make more friends around here too, so this is a win-win!"
    "Quiero hacer más amigos por aquí también, ¡así que esto es un beneficio mutuo!"

# game/script.rpy:1214
translate Spanish yasfren_bd255c96:

    # "I click the 'Accept Friend Request' button and refreshed my page."
    "Hago clic en el botón 'Aceptar solicitud de amistad' y actualizo mi página."

# game/script.rpy:1216
translate Spanish yasfren_52c1354f:

    # "Maybe he can tell me more about this 'Bappy the Horse' cartoon he found. It'll be a refreshing read during my work break."
    "Tal vez pueda contarme más sobre esta caricatura de 'Bappy the Horse' que encontró. Será una lectura refrescante durante mi descanso de trabajo."

# game/script.rpy:1217
translate Spanish yasfren_c2d2feaf:

    # "Speaking of work..."
    "Hablando de trabajo ..."

# game/script.rpy:1223
translate Spanish nahfren_1eca5168:

    # "I know it'll be a little awkward to ignore my next door neighbor's friend request..."
    "Sé que será un poco incómodo ignorar la solicitud de amistad de mi vecino de al lado ..."

# game/script.rpy:1224
translate Spanish nahfren_e23d3a08:

    # "But I only want to accept people I'm actually close to."
    "Pero solo quiero aceptar a gente con la que realmente tengo confianza."

# game/script.rpy:1225
translate Spanish nahfren_baa2bd87:

    # "I'm already a little weirded out by him going through so many of my posts."
    "Ya me incomoda un poco que haya revisado tantas de mis publicaciones."

# game/script.rpy:1226
translate Spanish nahfren_17625414:

    # "I press the 'Ignore Friend Request' button."
    "Presiono el botón 'Ignorar la solicitud de amistad'."

# game/script.rpy:1227
translate Spanish nahfren_18df4460:

    # "I go through my inbox and delete over 50 'Jacob Alden liked your post!' notifications."
    "Reviso mi bandeja de entrada y elimino más de 50 notificaciones de '¡A Jacob Alden le gustó tu publicación!'."

# game/script.rpy:1228
translate Spanish nahfren_adb47f52:

    # "This guy needs to chill a bit..."
    "Este tipo necesita relajarse un poco ..."

# game/script.rpy:1229
translate Spanish nahfren_3519e45a:

    # "Before I log off for the night, I still gotta print something for my job."
    "Antes de cerrar sesión por hoy, todavía tengo que imprimir algo para mi trabajo."

# game/script.rpy:1234
translate Spanish workyy_d1ac6fe1:

    # "I open up my work document. I have to make sure I get this printed and shipped out soon."
    "Abro mi documento de trabajo. Tengo que asegurarme de que me imprima y envíe pronto."

# game/script.rpy:1235
translate Spanish workyy_ac283238:

    # "I click the 'Print Out' button and await my papers-"
    "Hago clic en el botón 'Imprimir' y espero mis papeles-"

# game/script.rpy:1238
translate Spanish workyy_4cbe89e4:

    # "Huh?"
    "¿Eh?"

# game/script.rpy:1239
translate Spanish workyy_054dcded:

    # "A notification pops up on my screen."
    "Una notificación aparece en mi pantalla."

# game/script.rpy:1240
translate Spanish workyy_bb0ca1ee:

    # "'Out of ink'."
    "'Sin tinta'."

# game/script.rpy:1241
translate Spanish workyy_77be15ae:

    # "Welp, looks like I'll just have to buy some tomorrow morning."
    "Bueno, parece que tendré que comprar tinta mañana por la mañana."

# game/script.rpy:1242
translate Spanish workyy_62bcc503:

    # "I finish the remainder of my Thai food and leave the office with my bowl."
    "Termino el resto de mi comida tailandesa y salgo de la oficina con mi tazón."

# game/script.rpy:1244
translate Spanish workyy_64fc8ad6:

    # "I place my dinnerware in the sink. Walking across the room, my foot steps on something."
    "Dejo mi vajilla en el fregadero. Al cruzar la habitación, mi pie pisa algo."

# game/script.rpy:1247
translate Spanish workyy_99d3747b:

    # "I pick up the envelope. A love letter? For me?"
    "Recojo el sobre. ¿Una carta de amor? ¿Para mí?"

# game/script.rpy:1248
translate Spanish workyy_abf597ec:

    # "The outside is adorned with drawings of red hearts, how nice."
    "El exterior está adornado con dibujos de corazones rojos, qué bonito."

# game/script.rpy:1249
translate Spanish workyy_1e0da725:

    # "The back of the envelope has a heart sticker on the flap. I peel it away and open it."
    "En la parte de atrás del sobre hay un sticker de corazón en la solapa. Lo despego y lo abro."

# game/script.rpy:1259
translate Spanish read1_1c4b8bbb:

    # "Aw, that's sweet!"
    "¡Aww, qué lindo!"

# game/script.rpy:1260
translate Spanish read1_fa2cf266:

    # "The little doodles are cute too, looks like they've been drawn with glitter pens."
    "Los dibujitos también son lindos, parece que los hicieron con bolígrafos de brillantina."

# game/script.rpy:1261
translate Spanish read1_ddf8f1bf:

    # "To be honest, I didn't expect to gain someone's attention so quickly."
    "Para ser sincer[letra], no esperaba llamar la atención de alguien tan rápido."

# game/script.rpy:1262
translate Spanish read1_cb7cadaa:

    # "But whoever this person is, they've definitely got MY attention too."
    "Pero sea quien sea esta persona, definitivamente también ha captado MI atención."

# game/script.rpy:1263
translate Spanish read1_d2c9bd92:

    # "I smile to myself and head upstairs."
    "Sonrío para mis adentros y subo las escaleras."

# game/script.rpy:1265
translate Spanish read1_4bdf9182:

    # "I fold the letter back into the envelope and place it on my nightstand."
    "Meto la carta de nuevo en el sobre y la dejo en mi mesita de noche."

# game/script.rpy:1266
translate Spanish read1_f144ca65:

    # "I tuck myself into bed and slowly doze off."
    "Me meto en la cama y me voy quedando dormid[letra]."

# game/script.rpy:1273
translate Spanish mornband_d0ffd317:

    # "The sunshine pierces through my curtains and covers my face."
    "El sol atraviesa mis cortinas y me cubre la cara."

# game/script.rpy:1274
translate Spanish mornband_16b3ac65:

    # "I stretch out my limbs and shift myself off my bed."
    "Estiro las extremidades y me levanto de la cama."

# game/script.rpy:1275
translate Spanish mornband_52602a33:

    # "It's around the afternoon, sleeping in feels so nice!"
    "Ya es casi la tarde, ¡qué rico es dormir hasta tarde!"

# game/script.rpy:1276
translate Spanish mornband_30c146b2:

    # "But I still need to go out today, I have to get the printer ink."
    "Pero todavía tengo que salir hoy, necesito comprar la tinta de la impresora."

# game/script.rpy:1277
translate Spanish mornband_efbd7f72:

    # "Hm...before I do that, I smell a little ripe. I'll take a shower before I leave."
    "Mm... antes de eso, huelo un poco fuerte. Me daré una ducha antes de salir."

# game/script.rpy:1278
translate Spanish mornband_faf82ae8:

    # "I gather up some clean clothes and came across my Bewitched Blood T-shirt."
    "Reúno algo de ropa limpia y me encuentro con mi camiseta de Bewitched Blood."

# game/script.rpy:1281
translate Spanish mornband_e35591d5:

    # "Oh yeah, I should wear this today!"
    "¡Ah, cierto, hoy debería ponérmela!"

# game/script.rpy:1282
translate Spanish mornband_0c3e15ba:

    # "I fold my shirt and bring it with me to the bathroom."
    "Doblo la camiseta y me la llevo al baño."

# game/script.rpy:1285
translate Spanish mornband_15753f49:

    # "I place my clothes by the sink, and made sure to use the bathroom and brush my teeth."
    "Dejo mi ropa junto al lavabo y me aseguro de ir al baño y cepillarme los dientes."

# game/script.rpy:1286
translate Spanish mornband_7605e220:

    # "Turning the knob, warm water sprays out of the shower head. I undress and step right in."
    "Giro la llave y sale agua tibia de la regadera. Me desvisto y me meto de una vez."

# game/script.rpy:1288
translate Spanish mornband_f09f9ca2:

    # "Ahh...this is nice. I needed this."
    "Ahh... qué rico. Necesitaba esto."

# game/script.rpy:1289
translate Spanish mornband_41f10d95:

    # "I lather up my body in soap to wash off the grime."
    "Me enjabono el cuerpo para quitarme la mugre."

# game/script.rpy:1290
translate Spanish mornband_4ce5517a:

    # "I reach for my new bottle of shampoo, but something looks off."
    "Estiro la mano hacia mi botella nueva de champú, pero algo se ve raro."

# game/script.rpy:1293
translate Spanish mornband_5c3ab7a3:

    # "Why is some of it already gone? Did it leak out?"
    "¿Por qué ya falta un poco? ¿Se habrá derramado?"

# game/script.rpy:1294
translate Spanish mornband_2d427233:

    # "Well that's annoying. I guess the bottle is faulty or something."
    "Bueno, eso es molesto. Supongo que la botella está defectuosa o algo así."

# game/script.rpy:1295
translate Spanish mornband_66284faf:

    # "I squeeze out a bit into my palm and start washing my hair."
    "Me echo un poco en la palma de la mano y empiezo a lavarme el cabello."

# game/script.rpy:1297
translate Spanish mornband_764fcc49:

    # "Woo, all clean!"
    "¡Yuju, todo limpio!"

# game/script.rpy:1298
translate Spanish mornband_5705ed12:

    # "I dry myself off with my towel and start putting on my set of clothes."
    "Me seco con la toalla y empiezo a ponerme la ropa."

# game/script.rpy:1299
translate Spanish mornband_a8284ecc:

    # "I look in the mirror and my new shirt fits great!"
    "Me miro en el espejo y ¡mi camiseta nueva me queda genial!"

# game/script.rpy:1301
translate Spanish mornband_aee3174c:

    # "I grab my keys and head out the door to the retail store."
    "Agarro mis llaves y salgo rumbo a la tienda."

# game/script.rpy:1303
translate Spanish mornband_1da22e88:

    # "I comb through the various isles to reach the electronics section."
    "Recorro los pasillos para llegar a la sección de electrónica."

# game/script.rpy:1304
translate Spanish mornband_8489c4a9:

    # me "Hm, lets see here…"
    me "Hm, veamos aquí ..."

# game/script.rpy:1310
translate Spanish mornband_2e7dc896:

    # j "Need help with anything, [playerName]?"
    j "¿Necesitas ayuda con algo, [playerName]?"

# game/script.rpy:1311
translate Spanish mornband_a344c422:

    # "I jumped from my spot.."
    "Salté de mi lugar."

# game/script.rpy:1312
translate Spanish mornband_5caf38e4:

    # me "Oh gosh, hey Jacob!"
    me "¡Ay, caray, hola, Jacob!"

# game/script.rpy:1313
translate Spanish mornband_415f68c6:

    # "He seemed to notice my startled expression."
    "Parece que notó mi cara de susto."

# game/script.rpy:1314
translate Spanish mornband_16e99e85:

    # j "Aw, I didn't mean to scare you!"
    j "¡Aw, no quise asustarte!"

# game/script.rpy:1316
translate Spanish mornband_f3494621:

    # j "I kinda have that effect on people sometimes, heh."
    j "A veces tengo ese efecto en la gente, je."

# game/script.rpy:1318
translate Spanish mornband_c9012414:

    # j "So [playerName], what're you lookin' for?"
    j "Entonces, [playerName], ¿qué andas buscando?"

# game/script.rpy:1327
translate Spanish yasink_7651eafc:

    # me "I ran out of black ink for my printer, if you have the-"
    me "Me quedé sin tinta negra para mi impresora, si tienes el-"

# game/script.rpy:1328
translate Spanish yasink_370e1a29:

    # j "Yeah we have those in stock! Lemme go grab one for ya."
    j "¡Sí, los tenemos en existencia! Deja que te traiga uno."

# game/script.rpy:1334
translate Spanish yasink_9d851e5a:

    # "Woah. I mean, it's good to know this place has good customer service."
    "Guau. O sea, es bueno saber que este lugar tiene buen servicio al cliente."

# game/script.rpy:1335
translate Spanish yasink_ef879090:

    # "In a flash, he comes back with a big smile on his face."
    "En un instante, regresa con una gran sonrisa en su rostro."

# game/script.rpy:1340
translate Spanish yasink_ca00874c:

    # j "I got it! Here you go [playerName]."
    j "¡Lo tengo! Aquí tienes, [playerName]."

# game/script.rpy:1341
translate Spanish yasink_208891aa:

    # "He hands me the cartridge box. I look over the number model."
    "Me entrega la caja del cartucho. Reviso el número de modelo."

# game/script.rpy:1342
translate Spanish yasink_a20cefa7:

    # "..."
    "..."

# game/script.rpy:1343
translate Spanish yasink_671686d6:

    # me "This is the exact one I needed for my printer."
    me "Este es justo el que necesitaba para mi impresora."

# game/script.rpy:1345
translate Spanish yasink_bbec4f9b:

    # j "Yup, just like you wanted!"
    j "¡Sí, como querías!"

# game/script.rpy:1346
translate Spanish yasink_07384fbb:

    # me "But, how did you know what brand I use? And the number type?"
    me "Pero, ¿cómo sabías qué marca uso? ¿Y el número de modelo?"

# game/script.rpy:1347
translate Spanish yasink_e31c155d:

    # j "This type of ink is bought really often, so I took a lucky guess, heh!"
    j "Este tipo de tinta se compra muchísimo, así que adiviné de pura suerte, ¡je!"

# game/script.rpy:1353
translate Spanish stinkyink_74531335:

    # me "I know what I need already, but thanks Jacob."
    me "Ya sé lo que necesito, pero gracias, Jacob."

# game/script.rpy:1357
translate Spanish stinkyink_2cb43aa9:

    # j "...Let me help you."
    j "... déjame ayudarte."

# game/script.rpy:1358
translate Spanish stinkyink_04eae308:

    # j "It's my job afterall."
    j "Es mi trabajo después de todo."

# game/script.rpy:1364
translate Spanish stinkyink_9d851e5a:

    # "Woah. I mean, it's good to know this place has good customer service."
    "Guau. O sea, es bueno saber que este lugar tiene buen servicio al cliente."

# game/script.rpy:1365
translate Spanish stinkyink_68b6a72b:

    # "In a flash, he comes back."
    "En un instante, regresa."

# game/script.rpy:1370
translate Spanish stinkyink_63f237db:

    # j "I got the ink you wanted. Here you go [playerName]."
    j "Conseguí la tinta que querías. Aquí tienes, [playerName]."

# game/script.rpy:1371
translate Spanish stinkyink_208891aa:

    # "He hands me the cartridge box. I look over the number model."
    "Me entrega la caja del cartucho. Reviso el número de modelo."

# game/script.rpy:1372
translate Spanish stinkyink_a20cefa7:

    # "..."
    "..."

# game/script.rpy:1373
translate Spanish stinkyink_671686d6:

    # me "This is the exact one I needed for my printer."
    me "Este es justo el que necesitaba para mi impresora."

# game/script.rpy:1374
translate Spanish stinkyink_1d1e2e8b:

    # j "Yup, just like you wanted."
    j "Sí, como querías."

# game/script.rpy:1375
translate Spanish stinkyink_07384fbb:

    # me "But, how did you know what brand I use? And the number type?"
    me "Pero, ¿cómo sabías qué marca uso? ¿Y el número de modelo?"

# game/script.rpy:1377
translate Spanish stinkyink_e31c155d:

    # j "This type of ink is bought really often, so I took a lucky guess, heh!"
    j "Este tipo de tinta se compra muchísimo, así que adiviné de pura suerte, ¡je!"

# game/script.rpy:1381
translate Spanish poopyheadatstore_359541dd:

    # me "Well, thank you for finding the ink I need!"
    me "Bueno, ¡gracias por encontrar la tinta que necesito!"

# game/script.rpy:1383
translate Spanish poopyheadatstore_d51e7107:

    # j "It's no problem at all [playerName], I'm really happy to help."
    j "No hay problema, [playerName], me alegra poder ayudarte."

# game/script.rpy:1384
translate Spanish poopyheadatstore_e8876e60:

    # j "And this might sound weird but, did you shower today?"
    j "Y esto puede sonar extraño, pero ¿te duchaste hoy?"

# game/script.rpy:1385
translate Spanish poopyheadatstore_1ad12abf:

    # me "Yeah, I did...why?"
    me "Sí, lo hice ... ¿por qué?"

# game/script.rpy:1387
translate Spanish poopyheadatstore_7b3f70b2:

    # j "When you stand by me, I can smell you."
    j "Cuando estás a mi lado, puedo olerte."

# game/script.rpy:1388
translate Spanish poopyheadatstore_dad827ae:

    # me "Wait, I thought I washed myself thoroughly, do I stink that bad!?"
    me "Espera, pensé que me había lavado bien, ¡¿tanto apesto?!"

# game/script.rpy:1390
translate Spanish poopyheadatstore_ab2235ff:

    # j "No, no! Not like that! I meant that you smell nice."
    j "¡No, no! ¡No así! Quise decir que hueles bien."

# game/script.rpy:1392
translate Spanish poopyheadatstore_39a1b20d:

    # j "You smell fresh and clean. Like a soft ocean breeze on a summer's night..."
    j "Hueles fresco y limpio. Como una suave brisa del océano en una noche de verano ..."

# game/script.rpy:1393
translate Spanish poopyheadatstore_2ed7989b:

    # j "It's really nice."
    j "Es realmente agradable."

# game/script.rpy:1394
translate Spanish poopyheadatstore_b1c07337:

    # me "Thank...you?"
    me "¿Gracias?"

# game/script.rpy:1396
translate Spanish poopyheadatstore_a914f02a:

    # aa "Tch, weirdo."
    aa "Tch, bicho raro."

# game/script.rpy:1398
translate Spanish poopyheadatstore_1de19518:

    # "Both of us turned our heads next to us."
    "Los dos giramos la cabeza hacia quien estaba a nuestro lado."

# game/script.rpy:1404
translate Spanish poopyheadatstore_ac9cb1d4:

    # "Oh no..."
    "Oh, no..."

# game/script.rpy:1405
translate Spanish poopyheadatstore_c2dc942e:

    # a "Do you talk to EVERYONE you meet like that?"
    a "¿Hablas así con TODOS los que conoces?"

# game/script.rpy:1406
translate Spanish poopyheadatstore_c6944d20:

    # j "It's called a compliment, not that you would know what that is."
    j "Se llama cumplido, aunque dudo que tú sepas lo que es."

# game/script.rpy:1407
translate Spanish poopyheadatstore_a9e20209:

    # a "Nah, you're fuckin' weird man."
    a "Nah, de verdad eres un maldito raro, amigo."

# game/script.rpy:1409
translate Spanish poopyheadatstore_3ac22b72:

    # j "Look who's talkin', Mister 'I like wrapping my arms around strangers'."
    j "Mira quién habla, señor 'Me gusta rodear con los brazos a desconocidos'."

# game/script.rpy:1410
translate Spanish poopyheadatstore_c11ed213:

    # a "Oh yeah? That's real funny comin' from someone who keeps taking [playerName]'s mail."
    a "¿Ah, sí? Qué gracioso viniendo de alguien que sigue llevándose el correo de [playerName]."

# game/script.rpy:1412
translate Spanish poopyheadatstore_4a78266e:

    # j "You fu-{w=0.3}{nw}"
    j "Tú, mald-{w=0.3}{nw}"

# game/script.rpy:1414
translate Spanish poopyheadatstore_8da521c7:

    # a "Nuh uh, you better watch that mouth of yours to a customer."
    a "Ah, ah, más te vale cuidar esa boca con un cliente."

# game/script.rpy:1415
translate Spanish poopyheadatstore_0ed6c345:

    # me "Wait, what?"
    me "Espera, ¿qué?"

# game/script.rpy:1417
translate Spanish poopyheadatstore_612e7f68:

    # me "Jacob, were you deliberately taking my mail!?"
    me "Jacob, ¡¿te estabas llevando mi correo a propósito?!"

# game/script.rpy:1418
translate Spanish poopyheadatstore_10350c33:

    # a "Yeah Jacob, tell [playerName] why you keep taking [his] mail!"
    a "¡Sí, Jacob, dile a [playerName] por qué sigues llevándote su correo!"

# game/script.rpy:1422
translate Spanish poopyheadatstore_89e730e0:

    # j "I only took your mail to keep it away from this moron."
    j "Solo tomé tu correo para mantenerlo alejado de este imbécil."

# game/script.rpy:1424
translate Spanish poopyheadatstore_5f8b9d1a:

    # j "I saw this guy open people's packages before! I didn't want that happening to you, so I made sure to keep your mail safe with me!"
    j "¡Vi a este tipo abrir los paquetes de la gente antes! No quería que eso te sucediera, ¡así que me aseguré de mantener tu correo a salvo conmigo!"

# game/script.rpy:1425
translate Spanish poopyheadatstore_e00095d0:

    # "I'm completely shocked."
    "Estoy completamente sorprendid[letra]."

# game/script.rpy:1426
translate Spanish poopyheadatstore_c131d8d1:

    # me "Austin, is this true?"
    me "Austin, ¿es esto cierto?"

# game/script.rpy:1428
translate Spanish poopyheadatstore_5afefad2:

    # "The taller man rolled his eyes."
    "El hombre más alto puso los ojos en blanco."

# game/script.rpy:1429
translate Spanish poopyheadatstore_970e75ba:

    # a "Pfft, no. This guy's a creep AND a liar."
    a "Pfft, no. Este tipo es un asqueroso y un mentiroso."

# game/script.rpy:1431
translate Spanish poopyheadatstore_4b66c126:

    # a "I wouldn't be surprised if he was taking your mail just to get closer to you!"
    a "¡No me sorprendería que se llevara tu correo solo para acercarse a ti!"

# game/script.rpy:1433
translate Spanish poopyheadatstore_ffcb27db:

    # j "Then how do you explain this?"
    j "Entonces, ¿cómo explicas esto?"

# game/script.rpy:1434
translate Spanish poopyheadatstore_55e92f24:

    # "Jacob took out his phone and pulled up a video he recorded."
    "Jacob sacó su teléfono y abrió un video que grabó."

# game/script.rpy:1436
translate Spanish poopyheadatstore_b775506b:

    # "The footage shows Austin tearing into multiple envelopes, opening what looks like birthday cards and taking the money out of it."
    "Las imágenes muestran a Austin rasgando varios sobres, abriendo lo que parecen tarjetas de cumpleaños y sacando el dinero."

# game/script.rpy:1437
translate Spanish poopyheadatstore_69c2561f:

    # a "...I didn't know he knew 'bout that..."
    a "...No sabía que él sabía de eso..."

# game/script.rpy:1439
translate Spanish poopyheadatstore_7f6b7d10:

    # a "Look, that was only one time."
    a "Mira, eso fue solo una vez."

# game/script.rpy:1440
translate Spanish poopyheadatstore_8be04b34:

    # j "No, you did this multiple times."
    j "No, lo hiciste varias veces."

# game/script.rpy:1442
translate Spanish poopyheadatstore_b8e9a763:

    # "Jacob then opens up a folder with multiple videos of Austin's behavior."
    "Jacob luego abre una carpeta con múltiples videos del comportamiento de Austin."

# game/script.rpy:1444
translate Spanish poopyheadatstore_453025f2:

    # j "Yeah, not so tough now huh?"
    j "Sí, no tan duro ahora, ¿eh?"

# game/script.rpy:1445
translate Spanish poopyheadatstore_47b76548:

    # a "That's...really fuckin' creepy man."
    a "Eso es... malditamente espeluznante, amigo."

# game/script.rpy:1447
translate Spanish poopyheadatstore_631c8180:

    # j "No, not when you're committing a crime."
    j "No, no cuando estás cometiendo un delito."

# game/script.rpy:1449
translate Spanish poopyheadatstore_904a4daa:

    # a "Ugh, whatever man. Look, I won't be doin' that ever again, I gotta keep this job."
    a "Ugh, como sea, amigo. Mira, no voy a volver a hacer eso nunca más, tengo que conservar este trabajo."

# game/script.rpy:1451
translate Spanish poopyheadatstore_5a0bb6d1:

    # a "So you better delete those videos, or else."
    a "Así que más te vale borrar esos videos, o si no."

# game/script.rpy:1452
translate Spanish poopyheadatstore_7e1d30cc:

    # j "Or else what? Are you threatening me?"
    j "¿O si no, qué? ¿Me estás amenazando?"

# game/script.rpy:1453
translate Spanish poopyheadatstore_294dffd0:

    # a "Or else I'll make your life a livin' Hell. How 'bout that?"
    a "O de lo contrario haré que tu vida sea un infierno. ¿Qué tal eso?"

# game/script.rpy:1454
translate Spanish poopyheadatstore_b4fa3fc0:

    # j "..."
    j "..."

# game/script.rpy:1456
translate Spanish poopyheadatstore_268fc18e:

    # j "Would you like me to call security?"
    j "¿Quieres que llame a seguridad?"

# game/script.rpy:1458
translate Spanish poopyheadatstore_32f8a9ad:

    # a "Nah, I'm good."
    a "No, estoy bien."

# game/script.rpy:1461
translate Spanish poopyheadatstore_38f4a0dc:

    # "As Austin leaves, he purposely bumps his hip against a table of items on display, knocking the boxes on to the ground."
    "Al irse, Austin choca a propósito la cadera contra una mesa con artículos en exhibición y tira las cajas al suelo."

# game/script.rpy:1463
translate Spanish poopyheadatstore_c8a2ba92:

    # a "Oops~ Heh heh..."
    a "Oops ~ je je ..."

# game/script.rpy:1464
translate Spanish poopyheadatstore_279169e2:

    # "Jacob grits his teeth and clenches his hands into shaky fists."
    "Jacob aprieta los dientes y aprieta las manos en puños temblorosos."

# game/script.rpy:1465
translate Spanish poopyheadatstore_3f9ad9d2:

    # j "Fucking asshole..."
    j "Maldito imbécil ..."

# game/script.rpy:1467
translate Spanish poopyheadatstore_827779f0:

    # "He starts stacking everything back up again. I give him a hand and pick up the remaining boxes."
    "Comienza a apilar todo de nuevo. Le doy una mano y recojo las cajas restantes."

# game/script.rpy:1468
translate Spanish poopyheadatstore_08183d7b:

    # j "Thanks [playerName]. Didn't think we had to go through that today."
    j "Gracias [playerName]. No pensé que tuviéramos que pasar por eso hoy."

# game/script.rpy:1472
translate Spanish poopyheadatstore_c739c7ab:

    # j "But uh, enjoy your printer ink. If you need help looking for anything else, just let me know."
    j "Pero, eh, que disfrutes tu tinta. Si necesitas ayuda para buscar algo más, solo avísame."

# game/script.rpy:1473
translate Spanish poopyheadatstore_331552d7:

    # me "Actually, I do have a question. Why haven't you reported Austin about him stealing?"
    me "En realidad, tengo una pregunta. ¿Por qué no has denunciado a Austin por robar?"

# game/script.rpy:1474
translate Spanish poopyheadatstore_d8817faa:

    # j "I've tried to, but the post office doesn't believe me, even with the videos I took."
    j "He tratado de hacerlo, pero la oficina de correos no me cree, incluso con los videos que tomé."

# game/script.rpy:1475
translate Spanish poopyheadatstore_9774bbc2:

    # j "They said the footage was captured from too far away, so they can't completely confirm whether it's him or not in the video."
    j "Dijeron que las imágenes fueron capturadas desde demasiado lejos, por lo que no pueden confirmar por completo si es él o no en el video."

# game/script.rpy:1476
translate Spanish poopyheadatstore_c659eec7:

    # "Jacob pulls out his phone again, showing me some of the other videos he took."
    "Jacob saca su teléfono nuevamente, mostrándome algunos de los otros videos que tomó."

# game/script.rpy:1478
translate Spanish poopyheadatstore_6072f2b7:

    # j "It's bullshit...it's so obviously him. Same douchey man-bun, same hair color, it's HIM."
    j "Es una estupidez... es obvio que es él. El mismo moño de patán, el mismo color de cabello, es ÉL."

# game/script.rpy:1479
translate Spanish poopyheadatstore_dc5b824c:

    # "Admittedly, the footage does look a bit grainy, but it's definitely Austin. "
    "Es cierto que el metraje se ve un poco granulado, pero definitivamente es Austin. "

# game/script.rpy:1480
translate Spanish poopyheadatstore_436e9628:

    # me "It's dumb the post office doesn't believe you."
    me "Es tonto que la oficina de correos no te crea."

# game/script.rpy:1482
translate Spanish poopyheadatstore_30d9018f:

    # j "I know right?"
    j "¡Dímelo a mí!"

# game/script.rpy:1483
translate Spanish poopyheadatstore_8e565f02:

    # j "I would of used my better cameras to record this, but they're being used for..."
    j "Habría usado mis mejores cámaras para grabar esto, pero se están utilizando para ..."

# game/script.rpy:1485
translate Spanish poopyheadatstore_86614673:

    # j "...something else."
    j "...otra cosa."

# game/script.rpy:1488
translate Spanish poopyheadatstore_00188821:

    # j "Anyways, I should probably get back to work, see you 'round [playerName]."
    j "En fin, mejor vuelvo al trabajo, nos vemos por ahí, [playerName]."

# game/script.rpy:1489
translate Spanish poopyheadatstore_3e2804d2:

    # "He puts his phone back into his pocket and awkwardly smiles at me."
    "Vuelve a colocar su teléfono en su bolsillo y me sonríe torpemente."

# game/script.rpy:1490
translate Spanish poopyheadatstore_3af4712b:

    # "I wave goodbye to him as I walk towards the check out area."
    "Me despido con la mano mientras camino hacia las cajas."

# game/script.rpy:1491
translate Spanish poopyheadatstore_796fc60b:

    # "After paying for my ink, I make my way back home, still taken aback by what happened."
    "Después de pagar mi tinta, regreso a casa, todavía me sorprende lo que sucedió."

# game/script.rpy:1495
translate Spanish poopyheadatstore_08361686:

    # "Feels nice to be back home so quick."
    "Se siente bien estar de vuelta en casa tan rápido."

# game/script.rpy:1496
translate Spanish poopyheadatstore_5e967369:

    # "I place my ink cartridge in my office to replace later. Right now I'm starving."
    "Dejo el cartucho de tinta en mi oficina para cambiarlo más tarde. Ahora mismo me muero de hambre."

# game/script.rpy:1497
translate Spanish poopyheadatstore_3e1233e1:

    # "I make myself a quick bowl of cereal and sit down on my couch."
    "Me hago un tazón rápido de cereal y me siento en mi sofá."

# game/script.rpy:1498
translate Spanish poopyheadatstore_410ee834:

    # "I turn on my TV and flip through the various channels."
    "Enciendo la tele y voy cambiando de canal."

# game/script.rpy:1501
translate Spanish poopyheadatstore_5378fd83:

    # news "In other news, police have finished their investigation at Crimson Lake. All remains of the body have been uncovered."
    news "En otras noticias, la policía concluyó su investigación en Crimson Lake. Todos los restos del cuerpo han sido recuperados."

# game/script.rpy:1502
translate Spanish poopyheadatstore_7b7c371c:

    # news "The identity was of a man in his late 20s named Jesse Hewitt."
    news "La víctima fue identificada como un hombre de casi 30 años llamado Jesse Hewitt."

# game/script.rpy:1503
translate Spanish poopyheadatstore_ec86cc29:

    # news "He was found with over 60 stab wounds to the chest, rope burns around his wrists, and missing eyes."
    news "Fue encontrado con más de 60 puñaladas en el pecho, quemaduras de cuerda en las muñecas y sin ojos."

# game/script.rpy:1504
translate Spanish poopyheadatstore_88fe1dad:

    # news "Autopsy reports say his heart is missing from his chest. Another case from a year ago had similar results."
    news "Los informes de la autopsia indican que le falta el corazón. Otro caso de hace un año tuvo resultados similares."

# game/script.rpy:1505
translate Spanish poopyheadatstore_b9ce9a83:

    # news "Amy Fernandez was another victim who suffered a similar fate, her body also being absent of a heart."
    news "Amy Fernandez fue otra víctima que sufrió un destino similar; a su cuerpo también le faltaba el corazón."

# game/script.rpy:1506
translate Spanish poopyheadatstore_941a117e:

    # news "Whoever has been doing these killings has always left the chest cavity of the victims empty."
    news "Quien sea que esté cometiendo estos asesinatos siempre ha dejado vacía la cavidad torácica de las víctimas."

# game/script.rpy:1507
translate Spanish poopyheadatstore_0d752380:

    # news "Police are still on the look out for this unknown killer, but the crime scene has been thoroughly searched."
    news "La policía sigue buscando a este asesino desconocido, pero la escena del crimen fue registrada a fondo."

# game/script.rpy:1508
translate Spanish poopyheadatstore_15eb664b:

    # news "Crimson Lake is now open again to the public!"
    news "¡Crimson Lake ahora está abierto nuevamente al público!"

# game/script.rpy:1509
translate Spanish poopyheadatstore_3a0c48b7:

    # "Wow...that's gruesome."
    "Wow ... eso es horrible."

# game/script.rpy:1510
translate Spanish poopyheadatstore_acdcb235:

    # "That name 'Jesse Hewitt' is familiar. I do recall reading about this in an article online. "
    "Ese nombre 'Jesse Hewitt' es familiar. Recuerdo haber leído sobre esto en un artículo en línea."

# game/script.rpy:1511
translate Spanish poopyheadatstore_986530ff:

    # "He went missing about 3 months ago before I moved here."
    "Desapareció hace unos 3 meses, antes de que me mudara aquí."

# game/script.rpy:1512
translate Spanish poopyheadatstore_2768816f:

    # "It's a shame he had to die in such a brutal way."
    "Es una pena que haya tenido que morir de una manera tan brutal."

# game/script.rpy:1513
translate Spanish poopyheadatstore_625fa7ce:

    # "Open or not, I don't think I'll be visiting that lake anytime soon."
    "Abierto o no, no creo que visite ese lago en el corto plazo."

# game/script.rpy:1514
translate Spanish poopyheadatstore_e2cade32:

    # "I picked up my remote and changed the channel to something more happy."
    "Agarro el control remoto y cambio a algo más alegre."

# game/script.rpy:1523
translate Spanish poopyheadatstore_dd660ad4:

    # "Yay, cartoons!"
    "¡Sí, dibujos animados!"

# game/script.rpy:1524
translate Spanish poopyheadatstore_d93e373c:

    # "The network is even playing one of my favorites: Sammy the Scaredy Cat!"
    "El canal hasta está pasando uno de mis favoritos: ¡Sammy the Scaredy Cat!"

# game/script.rpy:1525
translate Spanish poopyheadatstore_659940cc:

    # "In this episode, he has to save his owners from a shadow demon."
    "En este episodio, tiene que salvar a sus dueños de un demonio de las sombras."

# game/script.rpy:1526
translate Spanish poopyheadatstore_172027a3:

    # "Even though he kidnapped Sammy's owners, the demon never meant any harm, he was just lonely."
    "Aunque secuestró a los dueños de Sammy, el demonio nunca quiso hacerles daño; solo se sentía solo."

# game/script.rpy:1532
translate Spanish poopyheadatstore_fd772e42:

    # "I open my eyes to the sound of loud ringing."
    "Abro los ojos al oír un fuerte timbre."

# game/script.rpy:1533
translate Spanish poopyheadatstore_aa0c2e47:

    # "Woah, I must of dozed off."
    "Vaya, debí quedarme dormid[letra]."

# game/script.rpy:1536
translate Spanish poopyheadatstore_05139031:

    # "I take out my phone from my pocket."
    "Saco mi teléfono de mi bolsillo."

# game/script.rpy:1537
translate Spanish poopyheadatstore_fc9ff6b2:

    # "The number calling me doesn't look like anyone I know."
    "No reconozco el número que me llama."

# game/script.rpy:1545
translate Spanish answercallyes_d6a5857f:

    # "I press the green button."
    "Presiono el botón verde."

# game/script.rpy:1553
translate Spanish normally_16c36287:

    # me "Hello?"
    me "¿Hola?"

# game/script.rpy:1554
translate Spanish normally_a20cefa7:

    # "..."
    "..."

# game/script.rpy:1555
translate Spanish normally_77d65967:

    # "No response."
    "Sin respuesta."

# game/script.rpy:1556
translate Spanish normally_1c7aae74:

    # me "...Hello?"
    me "...¿Hola?"

# game/script.rpy:1557
translate Spanish normally_a20cefa7_1:

    # "..."
    "..."

# game/script.rpy:1558
translate Spanish normally_3e59f679:

    # "Still no response, but it sounds like someone is breathing on the other end."
    "Todavía no hay respuesta, pero parece que alguien está respirando en el otro extremo."

# game/script.rpy:1559
translate Spanish normally_1e064e01:

    # "This is weird."
    "Esto es raro."

# game/script.rpy:1560
translate Spanish normally_b5f9bc5f:

    # me "I think you've got the wrong number, bye now."
    me "Creo que te equivocaste de número, adiós."

# game/script.rpy:1565
translate Spanish jokey_4e05b146:

    # me "Is this the Krusty Krab?"
    me "¿Es este el Krusty Krab?"

# game/script.rpy:1566
translate Spanish jokey_97cce331:

    # "I could of sworn I heard someone chuckling softly on the other end."
    "Juraría que oí a alguien reírse bajito al otro lado de la línea."

# game/script.rpy:1567
translate Spanish jokey_4de72e20:

    # uu "No, this is Patrick. Heh."
    uu "No, este es Patrick. Je."

# game/script.rpy:1568
translate Spanish jokey_511b7f3d:

    # "The caller's voice was masculine, but it was in a low whisper."
    "La voz de la persona que llamó era masculina, pero estaba en un susurro bajo."

# game/script.rpy:1569
translate Spanish jokey_cba29e1c:

    # uu "Nice of you to pick up, sweetheart."
    uu "Qué amable de tu parte contestar, cariño."

# game/script.rpy:1570
translate Spanish jokey_c11e27af:

    # me "'Sweetheart'? Who is this?"
    me "¿'Cariño'? ¿Quién habla?"

# game/script.rpy:1571
translate Spanish jokey_03d5c6a8:

    # uu "..."
    uu "..."

# game/script.rpy:1572
translate Spanish jokey_94385d87:

    # me "Hey buddy, you better speak up before I find you and kick your ass."
    me "Oye, amigo, más te vale hablar antes de que te encuentre y te patee el trasero."

# game/script.rpy:1573
translate Spanish jokey_2b4ee163:

    # uu "I'd like to see you try, darlin'~."
    uu "Me gustaría verte intentarlo, cariño ~."

# game/script.rpy:1574
translate Spanish jokey_73688b06:

    # "Before I could speak, they hang up."
    "Antes de que pueda decir algo, cuelgan."

# game/script.rpy:1575
translate Spanish jokey_3d612fed:

    # "Perhaps it's better to just NOT answer random phone calls."
    "Quizás sea mejor no responder llamadas telefónicas al azar."

# game/script.rpy:1576
translate Spanish jokey_8fd2ae2e:

    # "What a weirdo."
    "Qué bicho raro."

# game/script.rpy:1580
translate Spanish answercallno_76ae2f32:

    # "It's probably just spam."
    "Probablemente sea solo spam."

# game/script.rpy:1581
translate Spanish answercallno_bd55d490:

    # "I press the red button."
    "Presiono el botón rojo."

# game/script.rpy:1587
translate Spanish secondletter_ebfc6367:

    # "It's pretty dark out. I check my wall clock. 8:05 PM."
    "Es bastante oscuro. Reviso mi reloj de pared. 8:05 pm."

# game/script.rpy:1589
translate Spanish secondletter_4736968f:

    # "I guess I can make myself a late dinner..."
    "Supongo que puedo prepararme una cena tardía..."

# game/script.rpy:1591
translate Spanish secondletter_b0fe0177:

    # "I go ahead and make myself a quick sandwich."
    "Me preparo un sándwich rápido."

# game/script.rpy:1592
translate Spanish secondletter_b31179c6:

    # "Ah, that hits the spot..."
    "Ah, justo lo que necesitaba..."

# game/script.rpy:1593
translate Spanish secondletter_12164fe9:

    # "..!?"
    "..¡¿?!"

# game/script.rpy:1594
translate Spanish secondletter_2de2aec4:

    # "My mail slot-"
    "La ranura del correo-"

# game/script.rpy:1596
translate Spanish secondletter_f6988a05:

    # "An envelope falls on to the floor."
    "Un sobre cae en el piso."

# game/script.rpy:1597
translate Spanish secondletter_e8cca024:

    # "Wait, are they still out there?"
    "Espera, ¿todavía están ahí fuera?"

# game/script.rpy:1600
translate Spanish secondletter_5182988d:

    # "Dang, whoever left this has fast legs!"
    "¡Caray, quien haya dejado esto sí que corre rápido!"

# game/script.rpy:1602
translate Spanish secondletter_058f1324:

    # "I pick up the envelope."
    "Recojo el sobre."

# game/script.rpy:1605
translate Spanish secondletter_87547e0f:

    # "Another love letter! I peel the sticker and fold out the paper."
    "¡Otra carta de amor! Despego el sticker y desdoblo el papel."

# game/script.rpy:1615
translate Spanish read2_e5e9f373:

    # "Oh wow, so they also enjoy Bewitched Blood? Awesome! How did they know I like that band?"
    "Vaya, ¿entonces a esta persona también le gusta Bewitched Blood? ¡Genial! ¿Cómo supo que me gusta esa banda?"

# game/script.rpy:1616
translate Spanish read2_eea811e8:

    # "Wait, my shirt..."
    "Espera, mi camiseta..."

# game/script.rpy:1617
translate Spanish read2_4e33c0a5:

    # "The only place I went to today was that retail store, could my secret admirer be an employee?"
    "El único lugar al que fui hoy fue esa tienda, ¿será que quien me admira en secreto trabaja ahí?"

# game/script.rpy:1618
translate Spanish read2_a1d9d200:

    # "Or maybe it was another customer..."
    "O tal vez fue otro cliente ..."

# game/script.rpy:1619
translate Spanish read2_6fdf64bc:

    # "Whoever they are, they've got good taste in music."
    "Quienquiera que sean, tienen buen gusto en la música."

# game/script.rpy:1621
translate Spanish read2_c141968b:

    # "I finish the rest of my sandwich and head upstairs."
    "Termino mi sándwich y subo las escaleras."

# game/script.rpy:1625
translate Spanish read2_c534ee2f:

    # "I can hear the soft pitter-patter of rain against my windows."
    "Oigo el suave golpeteo de la lluvia contra mis ventanas."

# game/script.rpy:1626
translate Spanish read2_dc37505b:

    # "This is perfect sleeping weather."
    "Es el clima perfecto para dormir."

# game/script.rpy:1627
translate Spanish read2_5034bd22:

    # "I put the new love letter next to the previous one and tuck myself into bed."
    "Dejo la nueva carta de amor junto a la anterior y me meto en la cama."

# game/script.rpy:1628
translate Spanish read2_ab72a5e0:

    # "It does feel nice to be loved..."
    "Sí se siente bien ser querid[letra]..."

# game/script.rpy:1637
translate Spanish stormymorn_82c70e71:

    # "My heart is racing as I jolt out of my bed."
    "El corazón me late a mil mientras me levanto de un salto."

# game/script.rpy:1638
translate Spanish stormymorn_becd2200:

    # "Looks like that rainy weather became a storm."
    "Parece que ese clima lluvioso se convirtió en una tormenta."

# game/script.rpy:1639
translate Spanish stormymorn_00acaa20:

    # "I check the time on my phone. 9:45 AM."
    "Reviso la hora en mi teléfono. 9:45 am."

# game/script.rpy:1640
translate Spanish stormymorn_8671a9ce:

    # "I still have to print out that work document, I guess I'll go get freshened up..."
    "Todavía tengo que imprimir ese documento de trabajo, supongo que iré a refrescarme ..."

# game/script.rpy:1643
translate Spanish stormymorn_a1b10d59:

    # "As I make my way downstairs, I immediately head to my office to replace the old cartridge."
    "Mientras bajo las escaleras, inmediatamente me dirijo a mi oficina para reemplazar el viejo cartucho."

# game/script.rpy:1645
translate Spanish stormymorn_c30c14e5:

    # "I flip the hood up on my printer and take out the old cartridge."
    "Levanto la tapa de la impresora y saco el cartucho viejo."

# game/script.rpy:1648
translate Spanish stormymorn_74c73e48:

    # "I reach into the plastic bag to take out the new cartridge but..."
    "Meto la mano en la bolsa de plástico para sacar el cartucho nuevo, pero..."

# game/script.rpy:1649
translate Spanish stormymorn_703783c5:

    # "...The box is already open?"
    "... ¿La caja ya está abierta?"

# game/script.rpy:1650
translate Spanish stormymorn_ade2f4e9:

    # "It's empty. Hold on..."
    "Está vacía. Un momento..."

# game/script.rpy:1651
translate Spanish stormymorn_e6a61ae8:

    # "I look at the date of the cartridge in my hand."
    "Miro la fecha del cartucho en mi mano."

# game/script.rpy:1652
translate Spanish stormymorn_42894813:

    # "Yeah, this one is the new one."
    "Sí, este es el nuevo."

# game/script.rpy:1653
translate Spanish stormymorn_0962093b:

    # "I guess I must of replaced my cartridge last night and forgot, heh."
    "Supongo que ya cambié el cartucho anoche y se me olvidó, je."

# game/script.rpy:1654
translate Spanish stormymorn_bdb8366f:

    # "I put the new cartridge back inside the printer."
    "Vuelvo a meter el cartucho nuevo en la impresora."

# game/script.rpy:1656
translate Spanish stormymorn_9c758295:

    # "I print out my work document, fold it into an envelope and add a stamp."
    "Imprimo mi documento de trabajo, lo doblo, lo meto en un sobre y le pongo una estampilla."

# game/script.rpy:1657
translate Spanish stormymorn_54a1ff67:

    # "I'll bring this to the post office later."
    "Más tarde lo llevaré a la oficina de correos."

# game/script.rpy:1659
translate Spanish stormymorn_5a2cb9b1:

    # "Speaking of mail, I should check my front porch for any new packages."
    "Hablando de correo, debería revisar mi porche delantero para cualquier paquete nuevo."

# game/script.rpy:1662
translate Spanish stormymorn_5d1e9105:

    # "I took in the refreshing smell of rain."
    "Respiro el refrescante olor de la lluvia."

# game/script.rpy:1663
translate Spanish stormymorn_05e1a715:

    # "Small puddles formed along the sidewalk to my house."
    "Se han formado pequeños charcos a lo largo de la acera que lleva a mi casa."

# game/script.rpy:1664
translate Spanish stormymorn_a5bdfc12:

    # "I don't see any mail for myself, but I do see Austin nearby."
    "No veo ningún correo para mí, pero sí veo a Austin cerca."

# game/script.rpy:1665
translate Spanish stormymorn_7e2e37cc:

    # "Heh, sucks to be him right now."
    "Je, qué mal día para él."

# game/script.rpy:1666
translate Spanish stormymorn_b4d88c10:

    # "Wait, what's he doing?"
    "Espera, ¿qué está haciendo?"

# game/script.rpy:1685
translate Spanish stormymorn_e862779e:

    # "What the hell!? He's KICKING the packages to people's doors!"
    "¡¿Qué demonios?! ¡Está PATEANDO los paquetes hasta las puertas de la gente!"

# game/script.rpy:1686
translate Spanish stormymorn_95388d61:

    # "I put on my coat and shoes and run outside into the pouring rain."
    "Me pongo el abrigo y los zapatos y salgo corriendo bajo la lluvia torrencial."

# game/script.rpy:1687
translate Spanish stormymorn_1f0ba7f7:

    # me "Hey asshole, what makes you think that's ok!?"
    me "¡Oye, imbécil! ¿¡Qué te hace pensar que esto está bien!?"

# game/script.rpy:1692
translate Spanish stormymorn_eeab5ae9:

    # a "Huh? [playerName]? The hell do you mean?"
    a "¿Eh? ¿[playerName]? ¿Qué demonios quieres decir?"

# game/script.rpy:1693
translate Spanish stormymorn_22c26295:

    # me "You're kicking people's packages. You're gonna break whatever is inside!"
    me "Estás pateando los paquetes de la gente. ¡Vas a romper lo que hay adentro!"

# game/script.rpy:1694
translate Spanish stormymorn_83af2b63:

    # a "And? Not my problem. I'll just let them believe the seller didn't package it properly."
    a "¿Y? No es mi problema. Solo les dejaré creer que el vendedor no lo empaquetó correctamente."

# game/script.rpy:1695
translate Spanish stormymorn_05ab63f6:

    # me "The boxes are all soaked in water and mud, how could you think ANY of this is ok?"
    me "Las cajas están empapadas en agua y barro, ¿cómo podrías pensar que algo de esto está bien?"

# game/script.rpy:1696
translate Spanish stormymorn_adaed0c3:

    # a "Look, my hands are already dirty, I don't need them wet too."
    a "Mira, mis manos ya están sucias, no las necesito mojar también."

# game/script.rpy:1697
translate Spanish stormymorn_81181950:

    # a "And I dropped the box by accident, it was heavy. It's just easier to kick it to Jacob's door."
    a "Y se me cayó la caja sin querer, era pesada. Es más fácil patearla hasta la puerta de Jacob."

# game/script.rpy:1698
translate Spanish stormymorn_d59ea38e:

    # "He continues kicking the box forward. There's a sticker on the side of the box that reads 'Fragile'."
    "Continúa pateando la caja hacia adelante. Hay una pegatina en el costado de la caja que dice 'frágil'."

# game/script.rpy:1699
translate Spanish stormymorn_b85ee38d:

    # "It sounds like there's shattered glass inside..."
    "Suena como si hubiera vidrio roto adentro..."

# game/script.rpy:1700
translate Spanish stormymorn_e7fd22fb:

    # "Even if Austin hates Jacob, this is not professional at all."
    "Incluso si Austin odia a Jacob, esto no es profesional en absoluto."

# game/script.rpy:1701
translate Spanish stormymorn_5cdc4b9f:

    # "If Austin is willing to do this to my neighbor's package, I'm sure he's willing to do this to anyone."
    "Si Austin es capaz de hacerle esto al paquete de mi vecino, estoy segur[letra] de que es capaz de hacérselo a cualquiera."

# game/script.rpy:1703
translate Spanish stormymorn_3d04b5fe:

    # a "Hey, what're you doin'!?"
    a "Oye, ¿qué estás haciendo?"

# game/script.rpy:1704
translate Spanish stormymorn_dbe66a6f:

    # "I ring my neighbor's doorbell."
    "Toco el timbre de mi vecino."

# game/script.rpy:1705
translate Spanish stormymorn_eae29f58:

    # "Jacob pokes his head out the door with a grin."
    "Jacob asoma la cabeza por la puerta con una sonrisa."

# game/script.rpy:1717
translate Spanish stormymorn_1213486d:

    # j "Good morning [playerName], what's up?"
    j "Buenos días [playerName], ¿qué pasa?"

# game/script.rpy:1719
translate Spanish stormymorn_e35819a6:

    # me "I caught Austin kicking your package around."
    me "Atrapé a Austin pateando tu paquete."

# game/script.rpy:1720
translate Spanish stormymorn_960ec680:

    # j "He's..."
    j "Él está..."

# game/script.rpy:1723
translate Spanish stormymorn_600407c3:

    # j "{size=+10}HE DID WHAT!?{/size}"
    j "{size=+10}¡¿ÉL HIZO QUÉ?!{/size}"

# game/script.rpy:1740
translate Spanish stormymorn_da3538eb:

    # j "WHAT THE FUCK MAN!?"
    j "¡¿PERO QUÉ MIERDA TE PASA?!"

# game/script.rpy:1741
translate Spanish stormymorn_fa0015bf:

    # a "Hey, back off! I'm tryin' to do my job!"
    a "¡Eh, atrás! ¡Estoy intentando hacer mi trabajo!"

# game/script.rpy:1742
translate Spanish stormymorn_324684d1:

    # j "You ain't doin' SHIT! Look how banged up my package is! YOU DID THIS ON PURPOSE!"
    j "¡No estás haciendo NADA! ¡Mira cómo quedó de golpeado mi paquete! ¡LO HICISTE A PROPÓSITO!"

# game/script.rpy:1743
translate Spanish stormymorn_da15c209:

    # a "Since you're here, I'll just leave the box where it is. I don't got time for this."
    a "Ya que estás aquí, dejo la caja donde está. No tengo tiempo para esto."

# game/script.rpy:1751
translate Spanish stormymorn_eba7fc39:

    # "Austin scurries back into his mail truck. As he turns his keys, he gives me a hard stare."
    "Austin corre de vuelta a su camión de correo. Mientras da vuelta a la llave, me lanza una mirada fulminante."

# game/script.rpy:1752
translate Spanish stormymorn_478f0361:

    # a "Are you happy now, [playerName]?"
    a "¿Estás feliz ahora, [playerName]?"

# game/script.rpy:1753
translate Spanish stormymorn_def8e238:

    # "Austin steps on the gas pedal and tries to get as far away from us as possible."
    "Austin pisa el acelerador e intenta alejarse lo más posible de nosotros."

# game/script.rpy:1759
translate Spanish stormymorn_f3dfd9e4:

    # j "I'M GONNA GET YOU FIRED, ASSHOLE!"
    j "¡HARÉ QUE TE DESPIDAN, IMBÉCIL!"

# game/script.rpy:1760
translate Spanish stormymorn_37b72e93:

    # "The rain continues to pour down on us. Jacob doesn't seem bothered, probably too angry to care."
    "La lluvia sigue cayendo a cántaros sobre nosotros. A Jacob no parece importarle, seguramente está demasiado furioso para fijarse."

# game/script.rpy:1761
translate Spanish stormymorn_64985c0e:

    # "He lifts his soaked box from the muddy ground and walks back to his porch."
    "Levanta su caja empapada del suelo fangoso y camina de regreso a su porche."

# game/script.rpy:1772
translate Spanish stormymorn_c58abcdc:

    # me "I wish Austin wasn't such a jerk, I'm real sorry this happened to you Jacob."
    me "Desearía que Austin no fuera un idiota, lamento mucho que esto te haya pasado Jacob."

# game/script.rpy:1773
translate Spanish stormymorn_a5f98d67:

    # "He seemed to calm down a bit from my voice."
    "Parece que mi voz lo calmó un poco."

# game/script.rpy:1774
translate Spanish stormymorn_7738b42d:

    # j "I'm glad you told me what happened. Didn't expect him to be any lower of a scumbag than he already is."
    j "Me alegra que me lo hayas contado. No creía que pudiera caer todavía más bajo."

# game/script.rpy:1775
translate Spanish stormymorn_8212db12:

    # "My neighbor opens his front door and places his wet box on the floor mat."
    "Mi vecino abre su puerta de entrada y deja su caja mojada sobre el tapete."

# game/script.rpy:1787
translate Spanish stormymorn_1760a8df:

    # j "Woah! [playerName], over here!"
    j "¡Guau! ¡[playerName], por aquí!"

# game/script.rpy:1789
translate Spanish stormymorn_a2617c64:

    # "We huddle under his porch roof. Lightning strikes were completely visible over our heads."
    "Nos resguardamos bajo el techo de su porche. Los rayos se ven por completo sobre nuestras cabezas."

# game/script.rpy:1790
translate Spanish stormymorn_d57aa6b0:

    # j "That was a close one! I'm glad you're safe."
    j "¡Por poco! Me alegro de que estés a salvo."

# game/script.rpy:1791
translate Spanish stormymorn_36e90ca4:

    # j "C'mon [playerName], you should come inside until the storm passes."
    j "Ven, [playerName], deberías entrar hasta que pase la tormenta."

# game/script.rpy:1799
translate Spanish insidefromrain_92cdcb4c:

    # "I step inside of my neighbor's house, making sure to wipe my shoes on the floor mat."
    "Entro en la casa de mi vecino, asegurándome de limpiarme los zapatos en la alfombra del piso."

# game/script.rpy:1804
translate Spanish insidefromrain_71c4349c:

    # "Another lightning strike flashes from the window, it nearly touched the ground!"
    "Otro rayo ilumina la ventana, ¡casi toca el suelo!"

# game/script.rpy:1805
translate Spanish insidefromrain_f659271f:

    # j "Geez, haven't had brutal weather like this in quite a while."
    j "Caray, hacía mucho que no teníamos un tiempo tan brutal."

# game/script.rpy:1808
translate Spanish insidefromrain_6d52fc68:

    # j "But whenever we get storms, I like to cook up something that tastes extra good on a cold wet day like this one."
    j "Pero cuando hay tormenta, me gusta cocinar algo que sabe muy bien en un día frío y húmedo como este."

# game/script.rpy:1809
translate Spanish insidefromrain_410f3bb5:

    # "Something does smell good...something sweet."
    "Algo huele bien ... algo dulce."

# game/script.rpy:1811
translate Spanish insidefromrain_b5fb738b:

    # j "I was preparing some homemade chocolate chip cookies!"
    j "¡Estaba preparando algunas galletas caseras con chispas de chocolate!"

# game/script.rpy:1813
translate Spanish insidefromrain_64b4cd00:

    # j "If you want, you can come help me in the kitchen."
    j "Si quieres, puedes venir a ayudarme en la cocina."

# game/script.rpy:1814
translate Spanish insidefromrain_173a128c:

    # me "Sounds WAY better than doing nothing."
    me "Suena mucho mejor que no hacer nada."

# game/script.rpy:1816
translate Spanish insidefromrain_243ec173:

    # j "Great! Then let's get cookin'!"
    j "¡Excelente! ¡Entonces vamos a cocinar!"

# game/script.rpy:1820
translate Spanish insidefromrain_6b373ce7:

    # j "Here's where the magic happens."
    j "Aquí es donde sucede la magia."

# game/script.rpy:1822
translate Spanish insidefromrain_eac8c705:

    # j "Well, some of it."
    j "Bueno, algo de eso."

# game/script.rpy:1825
translate Spanish insidefromrain_99f603a7:

    # j "So I uh, I actually have everything I need out already."
    j "Así que, eh, en realidad ya saqué todo lo que necesito."

# game/script.rpy:1827
translate Spanish insidefromrain_3729b706:

    # j "The oven is still preheating. Before we start, let's wash our hands."
    j "El horno todavía está precalentando. Antes de empezar, lavémonos las manos."

# game/script.rpy:1828
translate Spanish insidefromrain_0ffd140b:

    # "After washing our hands, I stand next to the counter with the ingredients spread out."
    "Después de lavarnos las manos, me paro junto al mesón con los ingredientes ya dispuestos."

# game/script.rpy:1829
translate Spanish insidefromrain_64ff27ff:

    # j "Ok [playerName], you can start mixing the ingredients together, I'm gonna chop up the chocolate."
    j "Ok [playerName], puedes comenzar a mezclar los ingredientes, voy a cortar el chocolate."

# game/script.rpy:1830
translate Spanish insidefromrain_e85082cf:

    # me "You're chopping chocolate?"
    me "¿Estás cortando el chocolate?"

# game/script.rpy:1831
translate Spanish insidefromrain_4f280b09:

    # j "Yeah, I'm not using regular chocolate chips from the store. I like to get a big chocolate bar and cut it into small cubes."
    j "Sí, no uso las chispas de chocolate normales de la tienda. Me gusta comprar una barra grande de chocolate y cortarla en cubitos."

# game/script.rpy:1833
translate Spanish insidefromrain_f4a65276:

    # j "I guess these are chocolate CHUNK cookies!"
    j "¡Supongo que son galletas con TROZOS de chocolate!"

# game/script.rpy:1836
translate Spanish insidefromrain_7159b622:

    # "Jacob hands me a bowl and spoon. I pour the flour, baking powder and baking soda together."
    "Jacob me entrega un tazón y una cuchara. Vierto la harina, el polvo de hornear y el bicarbonato de sodio juntos."

# game/script.rpy:1838
translate Spanish insidefromrain_d91c2492:

    # "The blonde man opens a drawer and pulls out a kitchen knife."
    "El hombre rubio abre un cajón y saca un cuchillo de cocina."

# game/script.rpy:1839
translate Spanish insidefromrain_c1a98b0e:

    # "He starts chopping away at the large candy bar. Little chunks of chocolate piled up on his cutting board."
    "Empieza a picar la enorme barra de chocolate. Pequeños trozos de chocolate se apilaron en su tabla de cortar."

# game/script.rpy:1840
translate Spanish insidefromrain_97bf88b6:

    # "The sugary fragrance of the chocolate was already tempting me."
    "La fragancia azucarada del chocolate ya me estaba tentando."

# game/script.rpy:1841
translate Spanish insidefromrain_d416c294:

    # "Hm, I guess cookies will be my breakfast for today."
    "Hm, supongo que las galletas serán mi desayuno para hoy."

# game/script.rpy:1842
translate Spanish insidefromrain_fcb3b2f7:

    # j "So on the topic of cookies, do you have a favorite dessert [playerName]?"
    j "Entonces, hablando de galletas, ¿tienes un postre favorito, [playerName]?"

# game/script.rpy:1843
translate Spanish insidefromrain_0fa42414:

    # me "A dessert? Hm, well I do like..."
    me "¿Un postre? Hm, bueno, me gusta ..."

# game/script.rpy:1854
translate Spanish cakefave_7d49741c:

    # me "I love the creamy sweetness of a vanilla cake!"
    me "¡Me encanta la dulzura cremosa de un pastel de vainilla!"

# game/script.rpy:1856
translate Spanish cakefave_b3cf3166:

    # j "Oh yeah, that sounds really good!"
    j "¡Oh sí, eso suena muy bien!"

# game/script.rpy:1857
translate Spanish cakefave_3713ce3c:

    # j "Maybe I can bake you a cake someday."
    j "Tal vez pueda hornearte un pastel algún día."

# game/script.rpy:1861
translate Spanish cookiesfave_d8097af0:

    # me "I actually love chocolate chip cookies! I'm really looking forward to how these taste!"
    me "¡De hecho, me encantan las galletas con chispas de chocolate! ¡Tengo muchísimas ganas de probar estas!"

# game/script.rpy:1863
translate Spanish cookiesfave_339b370e:

    # j "That's great to hear [playerName]! I hope you like my recipe then!"
    j "¡Qué bueno oírlo, [playerName]! ¡Entonces espero que te guste mi receta!"

# game/script.rpy:1868
translate Spanish icecreamfave_e1beae27:

    # me "I love the sweet and refreshing taste of a cold strawberry ice cream!"
    me "¡Me encanta el sabor dulce y refrescante de un helado frío de fresa!"

# game/script.rpy:1870
translate Spanish icecreamfave_cf3e74fd:

    # j "Oh, that does sound good!"
    j "¡Oh, eso suena bien!"

# game/script.rpy:1871
translate Spanish icecreamfave_6928e864:

    # j "I've never made homemade ice cream before, maybe I could try making some for us to try someday."
    j "Nunca he hecho helado casero, tal vez podría intentar hacer uno para que lo probemos algún día."

# game/script.rpy:1876
translate Spanish cookcont_05b18c17:

    # "I stir the remaining ingredients into the bowl: butter, vanilla extract, brown sugar and regular sugar, salt, and some eggs."
    "Revuelvo el resto de los ingredientes en el tazón: mantequilla, extracto de vainilla, azúcar morena y azúcar blanca, sal y unos huevos."

# game/script.rpy:1879
translate Spanish cookcont_db318d6c:

    # "Everything is beginning to form into a light brown dough."
    "Todo empieza a convertirse en una masa de color café claro."

# game/script.rpy:1880
translate Spanish cookcont_784096a9:

    # j "Now all we have left is to add the chocolate!"
    j "¡Ahora todo lo que nos queda es agregar el chocolate!"

# game/script.rpy:1881
translate Spanish cookcont_869b89b9:

    # "Jacob takes his knife and sweeps the chunks into the bowl."
    "Jacob toma su cuchillo y barre los trozos en el tazón."

# game/script.rpy:1882
translate Spanish cookcont_e4f498a6:

    # "I stir it briskly, making sure the bits mix evenly within the dough."
    "Lo remuevo con energía, asegurándome de que los trocitos se repartan bien por la masa."

# game/script.rpy:1884
translate Spanish cookcont_ce300d17:

    # j "Good job [playerName]! Looks like the oven is ready too, I'll start setting up the baking tray."
    j "¡Buen trabajo, [playerName]! Parece que el horno también está listo, voy a preparar la bandeja."

# game/script.rpy:1886
translate Spanish cookcont_282c9c04:

    # "I set the bowl back on the counter and noticed something."
    "Puse el tazón en el mostrador y noté algo."

# game/script.rpy:1887
translate Spanish cookcont_7866d199:

    # "Somehow...Jacob got a bit of chocolate on his face."
    "De algún modo... Jacob se manchó la cara con un poco de chocolate."

# game/script.rpy:1888
translate Spanish cookcont_418505ee:

    # "It's small, but it's there."
    "Es pequeño, pero está ahí."

# game/script.rpy:1896
translate Spanish tellchoc_41d065b9:

    # me "Hey, you got a bit of chocolate on your cheek."
    me "Oye, tienes un poco de chocolate en tu mejilla."

# game/script.rpy:1898
translate Spanish tellchoc_ff893bc4:

    # j "Oh, do I?"
    j "Ah, ¿sí?"

# game/script.rpy:1899
translate Spanish tellchoc_c100540d:

    # "He wipes the right side of his cheek with a nearby napkin."
    "Limpia el lado derecho de su mejilla con una servilleta cercana."

# game/script.rpy:1900
translate Spanish tellchoc_210d9e35:

    # me "No, other side."
    me "No, otro lado."

# game/script.rpy:1902
translate Spanish tellchoc_c46cb713:

    # "He wipes again but on the left."
    "Se limpia de nuevo pero a la izquierda."

# game/script.rpy:1903
translate Spanish tellchoc_d15dd445:

    # me "Yup, you got it."
    me "Sí, ya está."

# game/script.rpy:1904
translate Spanish tellchoc_bb8a7a1f:

    # j "Dang, am I that messy? How did chocolate even get on my face?"
    j "Caray, ¿tan sucio soy? ¿Cómo rayos terminó el chocolate en mi cara?"

# game/script.rpy:1909
translate Spanish wipechoc_fdc7b7f7:

    # me "Hey Jacob, stay still for a sec."
    me "Oye, Jacob, quédate quieto un segundito."

# game/script.rpy:1910
translate Spanish wipechoc_6d983330:

    # j "Huh-"
    j "Eh-"

# game/script.rpy:1912
translate Spanish wipechoc_94300e2c:

    # "I wipe off the bit of chocolate from his face with my thumb."
    "Le limpio con el pulgar el poquito de chocolate de la cara."

# game/script.rpy:1913
translate Spanish wipechoc_59e95c80:

    # "I bring my thumb to my mouth."
    "Llevo mi pulgar a mi boca."

# game/script.rpy:1914
translate Spanish wipechoc_9bd81f2c:

    # me "Mm, that's some good chocolate!"
    me "¡Mmm, qué buen chocolate!"

# game/script.rpy:1916
translate Spanish wipechoc_b8e7c61f:

    # j "O-Oh uh...um...{size=-10}Thank you [playerName]...{/size}"
    j "O-oh, eh... este... {size=-10}Gracias, [playerName]...{/size}"

# game/script.rpy:1921
translate Spanish bakedone_91dd76e5:

    # "Jacob rolls pieces of dough into little balls to fit onto the tray. He then places it into the oven."
    "Jacob forma bolitas con trozos de masa para acomodarlas en la bandeja. Luego la mete al horno."

# game/script.rpy:1922
translate Spanish bakedone_fab51e94:

    # j "Okie dokie, now we just gotta wait a few minutes!"
    j "¡Muy bien, ahora solo toca esperar unos minutos!"

# game/script.rpy:1924
translate Spanish bakedone_74da151b:

    # j "Thanks for being my sous-chef, [playerName]. I know these cookies are gonna taste even better with your help."
    j "Gracias por ser mi sous-chef, [playerName]. Sé que estas galletas sabrán aún mejor con tu ayuda."

# game/script.rpy:1925
translate Spanish bakedone_d510b4fb:

    # me "No problem, I can't wait to try out the cookies!"
    me "No hay problema, ¡no puedo esperar para probar las galletas!"

# game/script.rpy:1926
translate Spanish bakedone_eacf0ddf:

    # "The steady pattern of rain on the rooftops is not stopping."
    "El constante golpeteo de la lluvia sobre los tejados no se detiene."

# game/script.rpy:1927
translate Spanish bakedone_d9485b7b:

    # "Thunder is still rumbling above us."
    "El trueno todavía retumba sobre nosotros."

# game/script.rpy:1928
translate Spanish bakedone_cfca95e6:

    # me "So uh, what should we do while we wait?"
    me "Entonces, ¿qué debemos hacer mientras esperamos?"

# game/script.rpy:1930
translate Spanish bakedone_fa6505c3:

    # j "Well, before you got here, I was actually doin' a bit of scrapbookin'."
    j "Bueno, antes de que llegaras, en realidad estaba armando un poco mi álbum de recortes."

# game/script.rpy:1932
translate Spanish bakedone_02695014:

    # j "Just reorganizing a few things 'round."
    j "Solo reorganizando unas cosillas por aquí."

# game/script.rpy:1933
translate Spanish bakedone_4ba4bd35:

    # "His eyes start to look behind me."
    "Sus ojos comienzan a mirar detrás de mí."

# game/script.rpy:1935
translate Spanish bakedone_2e2726b9:

    # j "I ordered some new camera lenses, but I know they're completely ruined by Austin."
    j "Pedí unos lentes nuevos para mis cámaras, pero seguro Austin los destrozó por completo."

# game/script.rpy:1936
translate Spanish bakedone_4d4963fa:

    # j "Thankfully the place I ordered them from accept damaged returns from poor handling, so at least I'm not at a loss."
    j "Por suerte, la tienda donde los pedí acepta devoluciones de productos dañados por mal manejo, así que al menos no pierdo dinero."

# game/script.rpy:1938
translate Spanish bakedone_8b8480fd:

    # j "I'll just have to wait a little longer before I can test out these lenses. It's for my cameras."
    j "Solo tendré que esperar un poco más antes de poder probar estas lentes. Es para mis cámaras."

# game/script.rpy:1939
translate Spanish bakedone_8705c328:

    # me "What makes these lenses so special?"
    me "¿Qué hace que estas lentes sean tan especiales?"

# game/script.rpy:1941
translate Spanish bakedone_ecd31c5e:

    # j "The lenses I ordered are called 'zoom lenses'."
    j "Los lentes que pedí se llaman 'lentes zoom'."

# game/script.rpy:1942
translate Spanish bakedone_e2b943c6:

    # j "A zoom lens let's me see something REALLY far away. It's perfect for long distant sightseeing."
    j "Un lente con zoom me deja ver algo MUY lejos. Es perfecto para observar a larga distancia."

# game/script.rpy:1943
translate Spanish bakedone_ee7f41f0:

    # me "Oh neat! Is there something specific you wanna use your zoom lens for?"
    me "¡Qué genial! ¿Hay algo específico para lo que quieras usar tu lente con zoom?"

# game/script.rpy:1944
translate Spanish bakedone_70cc1c84:

    # j "Maybe for taking pictures of birds, some large wild animals, and smaller fellas too. With a zoom lens, I can pretty much take pictures of anythin'."
    j "Quizá para fotografiar pájaros, algún animal salvaje grande y animalitos más pequeños también. Con un lente de zoom, puedo tomarle fotos a casi cualquier cosa."

# game/script.rpy:1947
translate Spanish bakedone_fe790020:

    # j "Nothin' can get out of my sight."
    j "Nada puede salir de mi vista."

# game/script.rpy:1951
translate Spanish bakedone_296acc1d:

    # j "Wow, this storm really ain't calming down."
    j "Vaya, esta tormenta realmente no se calma."

# game/script.rpy:1954
translate Spanish bakedone_bd940165:

    # j "Anyways, I also wanna take some photographs of a few landscapes and other nature scenery."
    j "En fin, también quiero tomar fotos de algunos paisajes y otras escenas de la naturaleza."

# game/script.rpy:1956
translate Spanish bakedone_b932891a:

    # j "If you ever wanna get into photography, just let me know, I'll even let you borrow some of my cameras."
    j "Si alguna vez quieres meterte en la fotografía, avísame, hasta te prestaré alguna de mis cámaras."

# game/script.rpy:1957
translate Spanish bakedone_d8c0d357:

    # me "Thanks Jacob, that's nice of you to offer!"
    me "Gracias, Jacob, ¡qué detalle por tu parte!"

# game/script.rpy:1958
translate Spanish bakedone_814c974e:

    # j "I'm gonna go check on the cookies, feel free to take a seat on the couch."
    j "Voy a ver cómo van las galletas; siéntate en el sofá si quieres."

# game/script.rpy:1960
translate Spanish bakedone_101c032d:

    # "I sit myself on his comfy couch and noticed an open book on the table."
    "Me siento en su cómodo sofá y noté un libro abierto sobre la mesa."

# game/script.rpy:1961
translate Spanish bakedone_63186f23:

    # "There were a few polaroid photographs strewn about."
    "Había algunas fotografías de Polaroid esparcidas."

# game/script.rpy:1962
translate Spanish bakedone_2465eabc:

    # "A lot of these show a much younger Jacob."
    "Muchas de ellas muestran a un Jacob mucho más joven."

# game/script.rpy:1963
translate Spanish bakedone_e788257d:

    # j "Good news: The cookies are done!"
    j "Buenas noticias: ¡las galletas están listas!"

# game/script.rpy:1964
translate Spanish bakedone_174b5056:

    # "He sits next to me with a hot plate of fresh cookies."
    "Se sienta a mi lado con un plato caliente de galletas frescas."

# game/script.rpy:1967
translate Spanish bakedone_2a76b3d3:

    # me "Oh man, this looks SO good!"
    me "¡Ay, esto se ve SUPER rico!"

# game/script.rpy:1968
translate Spanish bakedone_f484607a:

    # j "Go ahead [playerName], take the first piece!"
    j "¡Adelante, [playerName], toma la primera!"

# game/script.rpy:1969
translate Spanish bakedone_b1b12833:

    # "I take a big cookie from the top of the stack and bite into it."
    "Tomo una galleta grande de arriba de la pila y le doy un mordisco."

# game/script.rpy:1970
translate Spanish bakedone_147d4feb:

    # "The cookie was soft and moist, the warm chocolate practically melted into my mouth."
    "La galleta era suave y húmeda, el chocolate cálido prácticamente se derritió en mi boca."

# game/script.rpy:1971
translate Spanish bakedone_45ac45b5:

    # me "Jacob...these are the best damn cookies I've ever had."
    me "Jacob... estas son las mejores malditas galletas que he probado."

# game/script.rpy:1972
translate Spanish bakedone_5e65f720:

    # j "I'm glad you li-{w=0.5}{nw}"
    j "Me alegra que te gus-{w=0.5}{nw}"

# game/script.rpy:1973
translate Spanish bakedone_858946ab:

    # me "Jacob...I NEED this recipe. P l e a s e."
    me "Jacob... NECESITO esta receta. P o r  f a v o r."

# game/script.rpy:1974
translate Spanish bakedone_573e3b4c:

    # "My neighbor seems flattered and chuckles at my overexaggerated desperation."
    "Mi vecino parece halagado y se ríe por mi desesperación exagerada."

# game/script.rpy:1975
translate Spanish bakedone_002a0467:

    # j "Ok, ok! Here, I'll write it down real quick for you."
    j "¡Ok, ok! Ahora mismo te la escribo, rapidito."

# game/script.rpy:1976
translate Spanish bakedone_625972da:

    # "After handing me his 'Best Goddamn Cookies In The World' recipe, my attention goes back to the table."
    "Después de entregarme su receta de 'Las Mejores Malditas Galletas del Mundo', mi atención vuelve a la mesa."

# game/script.rpy:1978
translate Spanish bakedone_6b06f55c:

    # "Jacob grabs a cookie and flips through some of the pages of the scrapbook."
    "Jacob toma una galleta y voltea algunas de las páginas del álbum de recortes."

# game/script.rpy:1979
translate Spanish bakedone_46b4859b:

    # me "I noticed some of these pictures have you as a teenager."
    me "Me he fijado en que en algunas de estas fotos sales de adolescente."

# game/script.rpy:1980
translate Spanish bakedone_bf94d92f:

    # j "Yup. This scrapbook is specifically dedicated to my high school years. I found a few old pictures in one of boxes while I was cleaning last week."
    j "Sí. Este álbum de recortes está específicamente dedicado a mis años de secundaria. Encontré algunas fotos antiguas en una de las cajas mientras estaba limpiando la semana pasada."

# game/script.rpy:1981
translate Spanish bakedone_cd40738c:

    # j "Decided today was a good time to organize things."
    j "Decidí que hoy era un buen momento para organizar."

# game/script.rpy:1982
translate Spanish bakedone_d39cc6e4:

    # "Jacob takes a big bite out of his cookie. I pick up one of the polaroids off the table."
    "Jacob le da un buen mordisco a su galleta. Agarro una de las fotos Polaroid de la mesa."

# game/script.rpy:1986
translate Spanish bakedone_d1f23458:

    # j "That's a picture of when my dad took us to Louisiana one summer."
    j "Esa es una foto de cuando mi papá nos llevó a Luisiana un verano."

# game/script.rpy:1987
translate Spanish bakedone_8680531d:

    # j "Some of the best crawfish and gumbo you'll ever have is in Louisiana. Heh, I found that eating the crawfish with your bare hands makes you feel like a raccoon!"
    j "En Luisiana se come el mejor cangrejo de río y el mejor gumbo que probarás en tu vida. ¡Je, descubrí que comer el cangrejo de río con las manos te hace sentir como un mapache!"

# game/script.rpy:1988
translate Spanish bakedone_fc168595:

    # j "Well, to me at least."
    j "Bueno, al menos para mí."

# game/script.rpy:1989
translate Spanish bakedone_d139d3f9:

    # "The dog in the photo looks really cute."
    "El perro en la foto se ve muy lindo."

# game/script.rpy:1990
translate Spanish bakedone_eb2f86f6:

    # me "Was this your dog?"
    me "¿Era este tu perro?"

# game/script.rpy:1991
translate Spanish bakedone_7ff326c7:

    # j "Yeah, her name is Lucy. My dad got me her as a birthday gift when I was a kid."
    j "Sí, su nombre es Lucy. Mi papá me la regaló por mi cumpleaños cuando era niño."

# game/script.rpy:1992
translate Spanish bakedone_23b72a43:

    # me "Lucy is a very cute dog, she looks like a Labrador!"
    me "Lucy es una perrita muy linda, ¡parece una labrador!"

# game/script.rpy:1993
translate Spanish bakedone_0dfdd464:

    # j "Yup. She's a Labrador Retriever. Very friendly dog."
    j "Sí. Es una labrador retriever. Muy cariñosa."

# game/script.rpy:1994
translate Spanish bakedone_a933220f:

    # j "I miss her a lot."
    j "La extraño mucho."

# game/script.rpy:1995
translate Spanish bakedone_a5db4d3a:

    # "He took another bite out of his cookie."
    "Dio otro bocado de su galleta."

# game/script.rpy:2005
translate Spanish dad_f358213a:

    # me "So about your dad, you seem pretty close to him."
    me "Hablando de tu papá, pareces estar muy unido a él."

# game/script.rpy:2006
translate Spanish dad_0cd8c3e1:

    # me "He even looks a lot like you!"
    me "¡Incluso se parece mucho a ti!"

# game/script.rpy:2007
translate Spanish dad_2e9e8562:

    # j "My dad taught me a lot of things growing up, and even got me interested in various hobbies."
    j "Mi papá me enseñó muchas cosas al crecer, e incluso me interesó en varios pasatiempos."

# game/script.rpy:2008
translate Spanish dad_f6c52c3f:

    # j "From repairing computers to teaching me history. He really liked a lot of vintage stuff, like from the 1950s, 1960s, and 1970s."
    j "Desde la reparación de computadoras hasta enseñarme historia. Realmente le gustaban muchas cosas antiguas, como de los años cincuenta, sesenta y setenta."

# game/script.rpy:2009
translate Spanish dad_b1a6dad5:

    # j "I try to visit him at least twice a year. We like to go fishing together."
    j "Intento visitarlo al menos dos veces al año. Nos gusta ir a pescar juntos."

# game/script.rpy:2013
translate Spanish lucy_8a62d8c3:

    # j "She..."
    j "Ella..."

# game/script.rpy:2014
translate Spanish lucy_67612739:

    # "Jacob stopped chewing to focus on his words."
    "Jacob dejó de masticar para concentrarse en sus palabras."

# game/script.rpy:2015
translate Spanish lucy_b4fa3fc0:

    # j "..."
    j "..."

# game/script.rpy:2016
translate Spanish lucy_ad20dc4e:

    # j "She was taken from me."
    j "Me la quitaron."

# game/script.rpy:2017
translate Spanish lucy_23e730db:

    # "I hear sniffling coming from Jacob..."
    "Oigo a Jacob sorber por la nariz..."

# game/script.rpy:2018
translate Spanish lucy_4a01c54a:

    # "I should probably switch the subject to something else."
    "Probablemente debería cambiar de tema."

# game/script.rpy:2019
translate Spanish lucy_bacee43f:

    # me "I'm really sorry to hear that Jacob...but you know, it's good you have photos of good memories here."
    me "Lo siento mucho, Jacob... pero oye, está bien que tengas aquí fotos de buenos recuerdos."

# game/script.rpy:2020
translate Spanish lucy_aa16c3c6:

    # me "What got you into scrapbooking?"
    me "¿Cómo te metiste en el scrapbooking?"

# game/script.rpy:2021
translate Spanish lucy_de5f58e5:

    # "The man wipes the side of his face with his flannel sleeve."
    "El hombre se limpia el costado de su cara con su manga de franela."

# game/script.rpy:2022
translate Spanish lucy_d824a1c0:

    # j "*Sniff* Uh, well..."
    j "*Snif* Eh, bueno..."

# game/script.rpy:2023
translate Spanish lucy_bf18ac98:

    # j "When I got into photography, I had most of my photos tucked away inside of envelopes and boxes."
    j "Cuando me metí en la fotografía, tenía la mayoría de mis fotos guardadas en sobres y cajas."

# game/script.rpy:2024
translate Spanish lucy_8f6dd261:

    # j "I wanted to start properly archiving them, so I started scrapbooking."
    j "Quería empezar a archivarlas bien, así que empecé a hacer scrapbooking."

# game/script.rpy:2025
translate Spanish lucy_26eee256:

    # j "It's relaxing."
    j "Es relajante."

# game/script.rpy:2030
translate Spanish mom_19f76013:

    # j "My mom took the photograph using my polaroid camera."
    j "Mi madre tomó la fotografía usando mi cámara Polaroid."

# game/script.rpy:2031
translate Spanish mom_2b6af33b:

    # j "I don't have that many photos of her, she never really wanted to be in any of them."
    j "No tengo tantas fotos de ella, ella nunca quiso estar en ninguna de ellas."

# game/script.rpy:2032
translate Spanish mom_f309d214:

    # me "Has your mom been ok?"
    me "¿Tu mamá ha estado bien?"

# game/script.rpy:2033
translate Spanish mom_fb4fd878:

    # j "Erm...we didn't really see eye-to-eye on a lot of things."
    j "Eh... en muchas cosas no nos poníamos de acuerdo."

# game/script.rpy:2034
translate Spanish mom_007790ad:

    # j "About a month after I graduated high school, I packed my things and left her house."
    j "Aproximadamente un mes después de graduarme de la escuela secundaria, empaqué mis cosas y salí de su casa."

# game/script.rpy:2035
translate Spanish mom_0c4dc7c7:

    # j "Haven't talked to her since."
    j "No he hablado con ella desde entonces."

# game/script.rpy:2040
translate Spanish nextpolar_9f6fd66a:

    # "I picked out another photograph from the table."
    "Elegí otra fotografía de la mesa."

# game/script.rpy:2044
translate Spanish nextpolar_e1cc651b:

    # me "Aww, this one is cute! What's the story here?"
    me "¡Aww, qué linda esta! ¿Qué historia hay detrás?"

# game/script.rpy:2045
translate Spanish nextpolar_fe494870:

    # "Jacob takes a quick glance at the photo."
    "Jacob mira rápidamente la foto."

# game/script.rpy:2046
translate Spanish nextpolar_411f5e33:

    # j "Ah, that's me and Sarah at the county fair. We were both sophomores in high school."
    j "Ah, ahí estamos Sarah y yo en la feria del condado. Los dos estábamos en segundo año de preparatoria."

# game/script.rpy:2047
translate Spanish nextpolar_32f20010:

    # me "Was she one of your friends?"
    me "¿Era una de tus amigas?"

# game/script.rpy:2048
translate Spanish nextpolar_242a26dc:

    # j "Yeah. We were friends since we were in Kindergarten."
    j "Sí. Éramos amigos desde el kínder."

# game/script.rpy:2049
translate Spanish nextpolar_487ff6d8:

    # "There was a long, drawn out pause during the conversation. Jacob just continued nibbling away at the rest of his cookie."
    "Hubo una pausa larga y prolongada durante la conversación. Jacob siguió mordisqueando lo que le quedaba de la galleta."

# game/script.rpy:2050
translate Spanish nextpolar_6a6c41d4:

    # me "Sooooo...what happened?"
    me "Entoooonces... ¿qué pasó?"

# game/script.rpy:2051
translate Spanish nextpolar_227f3a09:

    # j "Hm?"
    j "¿Mm?"

# game/script.rpy:2052
translate Spanish nextpolar_9d1ce3a2:

    # me "What happened to Sar-{w=0.2}{nw}"
    me "¿Qué le pasó a Sar-{w=0.2}{nw}"

# game/script.rpy:2053
translate Spanish nextpolar_06a5b9e9:

    # j "We stopped being friends in Senior year of high school."
    j "Dejamos de ser amigos en el último año de secundaria."

# game/script.rpy:2054
translate Spanish nextpolar_b885d0c7:

    # j "That's all."
    j "Eso es todo."

# game/script.rpy:2055
translate Spanish nextpolar_f3f17a58:

    # "The tone in his voice became harsh."
    "El tono en su voz se volvió duro."

# game/script.rpy:2056
translate Spanish nextpolar_d0c5c6b7:

    # "He grabs another cookie, this time nearly shoving the whole thing into his mouth."
    "Agarra otra galleta, y esta vez casi se la mete entera en la boca."

# game/script.rpy:2057
translate Spanish nextpolar_2ea74959:

    # "I'll take that as a hint to move on."
    "Lo tomaré como una señal para dejar el tema."

# game/script.rpy:2058
translate Spanish nextpolar_c1a7df63:

    # "The endless drops of rain and occassional rumble of thunder was the only sound between us."
    "Las interminables gotas de lluvia y el retumbar ocasional del trueno fueron el único sonido entre nosotros."

# game/script.rpy:2059
translate Spanish nextpolar_b1c9e33b:

    # "I keep my eyes on the photo for a little longer. They looked so happy together."
    "Sigo mirando la foto un rato más. Se veían tan felices juntos."

# game/script.rpy:2060
translate Spanish nextpolar_dee7a1a9:

    # "Imagining childhood friends separating on the last year of high school sounds painful."
    "Imaginar amigos de la infancia que se separan en el último año de la escuela secundaria suena doloroso."

# game/script.rpy:2062
translate Spanish nextpolar_4488032b:

    # "There's a polaroid sticking out loosely from one of the scrapbook pages."
    "Hay una Polaroid medio suelta que sobresale de una de las páginas del álbum."

# game/script.rpy:2067
translate Spanish nextpolar_7fe735d4:

    # "The photograph was dark and somewhat grainy. All I can make out is a street with someone's back facing the camera."
    "La foto era oscura y algo granulada. Solo distingo una calle y a alguien de espaldas a la cámara."

# game/script.rpy:2068
translate Spanish nextpolar_335053aa:

    # me "Jacob, what's this one?"
    me "Jacob, ¿qué es esta?"

# game/script.rpy:2069
translate Spanish nextpolar_d26fc45c:

    # "He looks at the picture I was holding, then takes it out of my hand."
    "Él mira la imagen que estaba sosteniendo, luego me la saca de la mano."

# game/script.rpy:2075
translate Spanish nextpolar_b4fa3fc0:

    # j "..."
    j "..."

# game/script.rpy:2076
translate Spanish nextpolar_a2841e47:

    # j "It's nothing special."
    j "No es nada especial."

# game/script.rpy:2077
translate Spanish nextpolar_3cf39b70:

    # j "This picture was just for an old class assignment. My photography class let us take pictures of different categories. This one was for Street Photography."
    j "Esta foto era solo para un trabajo de clase de hace tiempo. En mi clase de fotografía nos dejaban tomar fotos de distintas categorías. Esta era para fotografía callejera."

# game/script.rpy:2078
translate Spanish nextpolar_5c231ae8:

    # j "Street Photography is capturing everyday life events, usually within a city or town. I liked taking pictures of people walkin'. Just going 'round the town, minding their own business."
    j "La fotografía callejera consiste en capturar escenas de la vida cotidiana, normalmente dentro de una ciudad o un pueblo. Me gustaba tomar fotos de gente caminando. Simplemente recorriendo el pueblo, ocupándose de sus asuntos."

# game/script.rpy:2079
translate Spanish nextpolar_7bc3fdac:

    # "I sneak a view of the photograph again."
    "Vuelvo a echar un vistazo a escondidas a la fotografía."

# game/script.rpy:2087
translate Spanish whodatwhodat_c79e2e85:

    # j "Hm, not sure."
    j "Hm, no estoy seguro."

# game/script.rpy:2088
translate Spanish whodatwhodat_98406a03:

    # j "It's been a while since I've looked through my old portfolio stuff from high school."
    j "Hace tiempo que no reviso mis cosas del portafolio de la secundaria."

# game/script.rpy:2089
translate Spanish whodatwhodat_6998d219:

    # j "This one actually needs to be put into a different scrapbook."
    j "Esta en realidad tiene que ir en otro álbum."

# game/script.rpy:2090
translate Spanish whodatwhodat_52290d3f:

    # "He slides the polaroid into his pants pocket."
    "Él desliza la Polaroid en el bolsillo de sus pantalones."

# game/script.rpy:2096
translate Spanish datsarah_b4fa3fc0:

    # j "..."
    j "..."

# game/script.rpy:2097
translate Spanish datsarah_8309af2e:

    # j "Does it matter if it is?"
    j "¿Importa si es así?"

# game/script.rpy:2098
translate Spanish datsarah_b9c95da9:

    # j "It's just some Street Photography. Caught her one day in town and decided to snap a few photos for my assignment. Nothin' more."
    j "Es solo fotografía callejera. La vi un día por el pueblo y decidí tomarle unas fotos para mi trabajo. Nada más."

# game/script.rpy:2099
translate Spanish datsarah_6998d219:

    # j "This one actually needs to be put into a different scrapbook."
    j "Esta en realidad tiene que ir en otro álbum."

# game/script.rpy:2100
translate Spanish datsarah_52290d3f:

    # "He slides the polaroid into his pants pocket."
    "Él desliza la Polaroid en el bolsillo de sus pantalones."

# game/script.rpy:2105
translate Spanish moozik_ad989bce:

    # j "I think I'll continue my scrapbooking a little later. It can get pretty messy having a bunch of pictures all out at once. You can keep lookin' if you want."
    j "Creo que continuaré mi álbum de recortes un poco más tarde. Puede ser bastante desordenado tener un montón de fotos a la vez. Puedes seguir mirando si quieres."

# game/script.rpy:2106
translate Spanish moozik_4c7573c0:

    # "I flip through the remaining pages of his scrapbook. Even though it's sectioned off by year, there doesn't seem to be any photos from his Senior year."
    "Hojeo las páginas que quedan de su álbum de recortes. A pesar de que está seccionado por año, no parece haber fotos de su último año."

# game/script.rpy:2107
translate Spanish moozik_f88849e7:

    # "I'm guessing this has to do with Jacob and Sarah cutting ties with eachother."
    "Supongo que esto tiene que ver con Jacob y Sarah cortando lazos entre ellos."

# game/script.rpy:2108
translate Spanish moozik_55c37dd1:

    # me "So Jacob, did you have any other friends in school?"
    me "Entonces Jacob, ¿tenías otros amigos en la escuela?"

# game/script.rpy:2109
translate Spanish moozik_22fce8c8:

    # j "Hm...yeah, I did. Monty, Steve and Kenny."
    j "Mm... sí, tenía. Monty, Steve y Kenny."

# game/script.rpy:2110
translate Spanish moozik_8abe5a66:

    # j "The last time they all talked to me was when prom was happening. None of us had dates, but all our moms forced us to go to prom anyways."
    j "La última vez que todos me hablaron fue durante el baile de graduación. Ninguno tenía pareja, pero nuestras mamás nos obligaron a ir de todos modos."

# game/script.rpy:2111
translate Spanish moozik_f4282f50:

    # j "We were all going to hang out together, but I ended up leaving the prom early. I couldn't bare to see her anymore..."
    j "Íbamos a pasar el rato todos juntos, pero terminé yéndome del baile temprano. Ya no soportaba verla..."

# game/script.rpy:2112
translate Spanish moozik_b4fa3fc0:

    # j "..."
    j "..."

# game/script.rpy:2114
translate Spanish moozik_8e90e945:

    # "The man next to me takes in a deep breathe."
    "El hombre a mi lado respira hondo."

# game/script.rpy:2115
translate Spanish moozik_edf47a71:

    # j "I've always wanted to slow dance, never even got the chance to do that."
    j "Siempre quise bailar un lento; nunca tuve ocasión."

# game/script.rpy:2126
translate Spanish slowdance1_3aa5ce97:

    # j "Y-You what?"
    j "¿T-tú qué?"

# game/script.rpy:2127
translate Spanish slowdance1_10dcc330:

    # me "If you want, I can slow dance with you. It's pretty easy!"
    me "Si quieres, puedo bailar un lento contigo. ¡Es bastante fácil!"

# game/script.rpy:2128
translate Spanish slowdance1_2c7812f9:

    # "He just sits there, wide eyed, still in shock by my offer."
    "Simplemente se sienta allí, con los ojos muy abiertos, todavía en estado de shock por mi oferta."

# game/script.rpy:2129
translate Spanish slowdance1_64b34d49:

    # j "You want to...slow dance with me? Right now?"
    j "¿Quieres... bailar un lento conmigo? ¿Ahora mismo?"

# game/script.rpy:2130
translate Spanish slowdance1_7f8435ff:

    # me "Yeah, why not? I know it won't be the same as a prom slow dance, but if it's something you wanna try, I'm down."
    me "Sí, ¿por qué no? Sé que no será igual que un lento en el baile de graduación, pero si quieres probarlo, cuenta conmigo."

# game/script.rpy:2131
translate Spanish slowdance1_e9b283ab:

    # "Jacob immediately gets up from his spot and slides out a box from under the coffee table. He pulls out a record."
    "Jacob inmediatamente se levanta de su lugar y saca una caja de debajo de la mesa de centro. Saca un disco."

# game/script.rpy:2135
translate Spanish slowdance1_bbc340e9:

    # j "There's a lot of ballads and love songs I like from the 1950s. This is one of my favorites."
    j "Hay muchas baladas y canciones de amor que me gustan de la década de 1950. Este es uno de mis favoritos."

# game/script.rpy:2136
translate Spanish slowdance1_cd8e35dc:

    # j "If we're gonna slow dance, I've always wanted to try it to this song..."
    j "Si vamos a bailar un lento, siempre he querido probarlo con esta canción..."

# game/script.rpy:2139
translate Spanish slowdance1_aedc144d:

    # "It was a catchy and soft tune, with some tender sounding lyrics to follow."
    "Era una melodía pegadiza y suave, a la que seguía una letra tierna."

# game/script.rpy:2140
translate Spanish slowdance1_d7eab251:

    # "I get up from my spot and stand in front of Jacob."
    "Me levanto de mi lugar y me paro frente a Jacob."

# game/script.rpy:2141
translate Spanish slowdance1_6ae40701:

    # me "Ok, put one of your hands on my shoulder, and place your other hand around my back."
    me "Ok, pon una mano en mi hombro y la otra en mi espalda."

# game/script.rpy:2146
translate Spanish slowdance1_8e22727c:

    # j "L-Like this?"
    j "¿A-así?"

# game/script.rpy:2147
translate Spanish slowdance1_4ea3197e:

    # me "Yeah, just uh, loosen your grip a bit, you're giving my shoulder a death squeeze."
    me "Sí, solo, eh, afloja un poco el agarre, me estás aplastando el hombro."

# game/script.rpy:2149
translate Spanish slowdance1_b3fae6b7:

    # j "Oops, sorry...I'm still a bit nervous."
    j "Vaya, lo siento ... Todavía estoy un poco nervioso."

# game/script.rpy:2150
translate Spanish slowdance1_a53b157b:

    # me "That's ok! Now, you wanna gently sway your body, side to side."
    me "¡No pasa nada! Ahora, balancea suavemente el cuerpo de un lado a otro."

# game/script.rpy:2152
translate Spanish slowdance1_7b9c6e32:

    # "Jacob follows my lead, and his once tense grip started to relax."
    "Jacob sigue mi guía y su agarre, antes tenso, empieza a relajarse."

# game/script.rpy:2153
translate Spanish slowdance1_3f58d681:

    # me "You're doing good Jacob!"
    me "¡Lo estás haciendo bien, Jacob!"

# game/script.rpy:2155
translate Spanish slowdance1_a89e1bcf:

    # j "Thanks..."
    j "Gracias..."

# game/script.rpy:2157
translate Spanish slowdance1_7e7dcbaf:

    # "I take a step off to the side, guiding his body with mine. We slowly twirl around the floor in eachother's hold."
    "Doy un paso a un lado y guío su cuerpo con el mío. Giramos despacio por el suelo, abrazados."

# game/script.rpy:2158
translate Spanish slowdance1_840aa3f2:

    # "He swallowed hard and his breathing seemed to quicken."
    "Traga saliva con fuerza y su respiración parece acelerarse."

# game/script.rpy:2167
translate Spanish nervo_c9fabaf7:

    # j "Mhm..."
    j "Mhm ..."

# game/script.rpy:2169
translate Spanish nervo_c38e35d1:

    # me "That's ok, but you're getting the hang of it pretty fast!"
    me "No pasa nada, ¡pero le estás agarrando el truco bastante rápido!"

# game/script.rpy:2170
translate Spanish nervo_1e21a989:

    # me "Just take in a deep breathe with me...breathe in...now breathe out."
    me "Solo respira hondo conmigo... inhala... ahora exhala."

# game/script.rpy:2171
translate Spanish nervo_134031a3:

    # "Jacob inhales slowly, repeating my same action."
    "Jacob inhala lentamente, repitiendo mi misma acción."

# game/script.rpy:2172
translate Spanish nervo_aa2028a7:

    # "His whole body shivered as he exhaled."
    "Todo su cuerpo se estremeció mientras exhalaba."

# game/script.rpy:2173
translate Spanish nervo_75029bb0:

    # me "Better?"
    me "¿Mejor?"

# game/script.rpy:2175
translate Spanish nervo_9898686a:

    # j "Yeah, thanks [playerName]. You're a good dance teacher."
    j "Sí, gracias, [playerName]. Enseñas muy bien a bailar."

# game/script.rpy:2176
translate Spanish nervo_809e07c5:

    # me "Heh, it's nothing, really! Keep at it though, you've got some nice footwork."
    me "Je, ¡no es nada, de verdad! Pero sigue así, tienes buen paso."

# game/script.rpy:2177
translate Spanish nervo_4a7fea4b:

    # "The more we swayed, it seemed the closer our bodies got."
    "Cuanto más nos balanceábamos, más parecían acercarse nuestros cuerpos."

# game/script.rpy:2178
translate Spanish nervo_d3260b99:

    # "His body is incredibly warm."
    "Su cuerpo es increíblemente cálido."

# game/script.rpy:2179
translate Spanish nervo_42906619:

    # j "Hey [playerName], there's actually something I've been wantin' to tell you..."
    j "Oye, [playerName], en realidad hay algo que he querido decirte..."

# game/script.rpy:2185
translate Spanish promdate_0d724a51:

    # j "Really?"
    j "¿De verdad?"

# game/script.rpy:2186
translate Spanish promdate_ec493287:

    # me "Yeah. You've got a good rhythm and you're light on your feet."
    me "Sí. Tienes buen ritmo y eres ligero de pies."

# game/script.rpy:2187
translate Spanish promdate_f1ff402a:

    # me "My date, somehow, managed to constantly step on my toes during our slow dance."
    me "Mi pareja, no sé cómo, se las arregló para pisarme los pies todo el tiempo durante el lento."

# game/script.rpy:2188
translate Spanish promdate_0ffc8d73:

    # me "I actually had to put an ice pack on my feet when I got home, haha!"
    me "¡De hecho, tuve que ponerme una compresa de hielo en los pies al llegar a casa, jaja!"

# game/script.rpy:2190
translate Spanish promdate_dd81eada:

    # j "Heh heh! Wow, that does sound pretty bad."
    j "Je je! Vaya, eso suena bastante mal."

# game/script.rpy:2191
translate Spanish promdate_7ef3984c:

    # me "At least the bruises went away after a while. If anything, I wish I went with a different person."
    me "Al menos los moretones se me quitaron con el tiempo. Si acaso, ojalá hubiera ido con otra persona."

# game/script.rpy:2193
translate Spanish promdate_eaf73985:

    # me "Halfway through the party, I found out my date cheated on me. Then I was left alone for the rest of the prom. "
    me "A mitad de la fiesta descubrí que mi pareja me había engañado. Después me quedé sol[letra] el resto del baile."

# game/script.rpy:2195
translate Spanish promdate_15d32564:

    # j "What an asshole. I'm sorry you had to experience that, especially all in the same night."
    j "Qué imbécil. Lamento que hayas tenido que pasar por eso, y más todo en la misma noche."

# game/script.rpy:2196
translate Spanish promdate_59cd5979:

    # me "Meh, it's all in the past now. Although, I'm sure I would of much rather have you as my prom date."
    me "Bah, ya es pasado. Aunque seguro que te habría preferido mil veces a ti como pareja de baile."

# game/script.rpy:2198
translate Spanish promdate_d53315ce:

    # j "Wait, really? Me?"
    j "Espera, ¿de verdad? ¿A mí?"

# game/script.rpy:2199
translate Spanish promdate_bf67f176:

    # me "Yeah, I mean, you're pretty nice and haven't stepped on my toes yet, heh."
    me "Sí, quiero decir, eres bastante amable y no me has pisado los dedos de los pies, je."

# game/script.rpy:2201
translate Spanish promdate_7d359804:

    # j "[playerName]...you don't know how much that means to me to hear that from you."
    j "[playerName]... no sabes cuánto significa para mí oírte decir eso."

# game/script.rpy:2202
translate Spanish promdate_f6dfabca:

    # "I can feel our bodies pressing closer together."
    "Siento cómo nuestros cuerpos se pegan cada vez más el uno al otro."

# game/script.rpy:2203
translate Spanish promdate_d3260b99:

    # "His body is incredibly warm."
    "Su cuerpo es increíblemente cálido."

# game/script.rpy:2204
translate Spanish promdate_42906619:

    # j "Hey [playerName], there's actually something I've been wantin' to tell you..."
    j "Oye, [playerName], en realidad hay algo que he querido decirte..."

# game/script.rpy:2208
translate Spanish dancemusic1_c5ad3313:

    # "My neighbor gets up from his spot and slides out a box from under the coffee table."
    "Mi vecino se levanta y saca una caja de debajo de la mesa de centro."

# game/script.rpy:2211
translate Spanish dancemusic1_ddf255b1:

    # "The box is full of music records. He files through them and pulls one out of it's casing, carefully placing it onto his record player."
    "La caja está llena de discos de vinilo. Los va repasando y saca uno de su funda, colocándolo con cuidado en el tocadiscos."

# game/script.rpy:2213
translate Spanish dancemusic1_bbc340e9:

    # j "There's a lot of ballads and love songs I like from the 1950s. This is one of my favorites."
    j "Hay muchas baladas y canciones de amor que me gustan de la década de 1950. Este es uno de mis favoritos."

# game/script.rpy:2216
translate Spanish dancemusic1_3e6d4c09:

    # "It was a catchy and soft tune, with some tender sounding lyrics to follow. I can hear Jacob mumbling the lyrics to himself."
    "Era una melodía pegadiza y suave, a la que seguía una letra tierna. Oigo a Jacob murmurar la letra para sí mismo."

# game/script.rpy:2218
translate Spanish dancemusic1_201706ca:

    # j "...You're my sunshine on a cloudy day...kisses so sweet and tender...lovin' you is my job baby~..."
    j "...Eres mi sol en un día nublado... besos tan dulces y tiernos ... amarte es mi trabajo, bebé~ ..."

# game/script.rpy:2219
translate Spanish dancemusic1_968c3e7c:

    # "It was pretty endearing."
    "Fue bastante entrañable."

# game/script.rpy:2220
translate Spanish dancemusic1_a63a0137:

    # me "You know, you've got a good voice Jacob."
    me "Sabes, tienes buena voz, Jacob."

# game/script.rpy:2222
translate Spanish dancemusic1_74e3fc67:

    # j "I do?"
    j "¿Sí?"

# game/script.rpy:2224
translate Spanish dancemusic1_17b21600:

    # j "Shucks [playerName], you're just sayin' that. I ain't much of a singer."
    j "Ay, [playerName], lo dices por decir. No soy gran cosa cantando."

# game/script.rpy:2225
translate Spanish dancemusic1_cbd292f3:

    # me "I mean it, you're actually pretty good at singing!"
    me "Lo digo en serio, ¡en realidad eres bastante bueno cantando!"

# game/script.rpy:2226
translate Spanish dancemusic1_eedc841f:

    # "I can see Jacob's face turning redder by the second."
    "Veo que la cara de Jacob se pone más roja a cada segundo."

# game/script.rpy:2227
translate Spanish dancemusic1_77ae3d01:

    # j "Hey [playerName], would it be ok if, um..."
    j "Oye, [playerName], ¿te parecería bien si, eh..."

# game/script.rpy:2229
translate Spanish dancemusic1_81370226:

    # j "If I could hear you sing too?"
    j "¿Si pudiera oírte cantar a ti también?"

# game/script.rpy:2238
translate Spanish cantsing_bedb6903:

    # me "I don't think you should hear my singing, it's pretty bad."
    me "No creo que debas escuchar mi canto, es bastante malo."

# game/script.rpy:2239
translate Spanish cantsing_b7b9b24e:

    # j "Nonsense. I've heard that pretty voice sing before."
    j "Disparates. He oído esa bonita voz cantar antes."

# game/script.rpy:2240
translate Spanish cantsing_b10217a2:

    # me "You've heard me sing before?"
    me "¿Me has escuchado cantar antes?"

# game/script.rpy:2241
translate Spanish cantsing_992a67cf:

    # j "I hear you hummin' to yourself while you're shoppin' sometimes. You can carry a tune."
    j "A veces te oigo tararear mientras compras. Entonas bien."

# game/script.rpy:2242
translate Spanish cantsing_3852f100:

    # me "I don't think that really counts as singing."
    me "No creo que eso realmente cuente como cantar."

# game/script.rpy:2244
translate Spanish cantsing_7e51d078:

    # j "Doesn't matter, your voice is still music to my ears."
    j "No importa, tu voz sigue siendo música para mis oídos."

# game/script.rpy:2250
translate Spanish trysing_6c8d6e8c:

    # me "I guess I can try..."
    me "Supongo que puedo intentarlo ..."

# game/script.rpy:2251
translate Spanish trysing_ee7f2caa:

    # "I think of a song from the top of my head. Maybe something from Bewitched Blood?"
    "Pienso en una canción de memoria, así de repente. ¿Quizá algo de Bewitched Blood?"

# game/script.rpy:2253
translate Spanish trysing_fa51e661:

    # "I clear my throat..."
    "Me aclaro la garganta ..."

# game/script.rpy:2256
translate Spanish trysing_234cad31:

    # me "{size=+10}I AM REBORN FROM THE DEPTHS OF HELL, NOTHING CAN SAVE YOU FROM ME.{/size}"
    me "{size=+10}RENAZCO DE LAS PROFUNDIDADES DEL INFIERNO, NADA PUEDE SALVARTE DE MÍ.{/size}"

# game/script.rpy:2257
translate Spanish trysing_e4025990:

    # me "{size=+10}I AM YOUR DESTRUCTION, SAY YOUR PRAYERS AS YOUR GAZE MEETS THE SKY.{/size}"
    me "{size=+10}SOY TU DESTRUCCIÓN, REZA TUS ORACIONES MIENTRAS TU MIRADA SE ENCUENTRA CON EL CIELO.{/size}"

# game/script.rpy:2258
translate Spanish trysing_1f122da7:

    # me "{size=+10}ASHES RAIN FROM THE HEAVENS ABOVE, HOPE IS GONE, HOPE IS LOST.{/size}"
    me "{size=+10}CAEN CENIZAS DE LOS CIELOS, LA ESPERANZA SE HA IDO, LA ESPERANZA ESTÁ PERDIDA.{/size}"

# game/script.rpy:2259
translate Spanish trysing_c943ec60:

    # me "{size=+10}CURSED WITH BLOOD ON YOUR HANDS, I SEIZE CONTROL.{/size}"
    me "{size=+10}MALDITO CON SANGRE EN TUS MANOS, TOMO EL CONTROL.{/size}"

# game/script.rpy:2260
translate Spanish trysing_069d2be6:

    # me "{size=+10}RRAAAAAAAAAAAAHHHHHHHH!!!!!{/size}"
    me "{size=+10}¡¡¡¡RRAAAAAAAAAAAAHHHHHHHH!!!!!{/size}"

# game/script.rpy:2265
translate Spanish trysing_bdf31feb:

    # j "...Wow!"
    j "...¡Guau!"

# game/script.rpy:2266
translate Spanish trysing_a2ad4ccb:

    # j "I KNEW you were great at singin'!"
    j "¡SABÍA que cantabas genial!"

# game/script.rpy:2267
translate Spanish trysing_cc037e31:

    # me "Oh, thanks!"
    me "¡Oh, gracias!"

# game/script.rpy:2268
translate Spanish trysing_1d3e4df5:

    # "For a moment, I thought the lyrics or my scream at the end would freak him out."
    "Por un momento, pensé que la letra o mi grito al final lo asustarían."

# game/script.rpy:2270
translate Spanish trysing_b296c907:

    # j "Seriously, you've got some strong vocal cords. Ever thought about becoming a singer?"
    j "En serio, tienes unas cuerdas vocales potentes. ¿Alguna vez has pensado en dedicarte al canto?"

# game/script.rpy:2271
translate Spanish trysing_ad646bd6:

    # me "Oh gosh, I don't know about that."
    me "Ay, Dios, no sé yo..."

# game/script.rpy:2272
translate Spanish trysing_2ecd4b48:

    # j "If you ever do, just know that I'll be your #1 fan."
    j "Si alguna vez lo haces, solo quiero que sepas que seré tu fan número uno."

# game/script.rpy:2290
translate Spanish demoend_3b193c59:

    # "...!!!"
    "...!!!"

# game/script.rpy:2291
translate Spanish demoend_561a8e4d:

    # me "Woah, what happened?"
    me "¡Vaya! ¿Qué pasó?"

# game/script.rpy:2292
translate Spanish demoend_23eaf433:

    # j "Looks like we got a power outage."
    j "Parece que tenemos un corte de energía."

# game/script.rpy:2293
translate Spanish demoend_f98efbc9:

    # j "Don't worry though, I have some flashlights nearby. I'll be right back, just stay here, ok?"
    j "Pero tranquilo, tengo unas linternas por aquí cerca. Vuelvo enseguida, tú quédate aquí, ¿vale?"

# game/script.rpy:2294
translate Spanish demoend_f9733b51:

    # "I can somewhat make out Jacob's silhouette as he descends deeper into the pitch black room."
    "Apenas distingo la silueta de Jacob mientras se adentra en la habitación completamente a oscuras."

# game/script.rpy:2295
translate Spanish demoend_6da2a69a:

    # "I can't see a thing in the dark, and the storm clouds outside are muting any source of natural light."
    "No veo nada en la oscuridad, y las nubes de tormenta de fuera bloquean cualquier fuente de luz natural."

# game/script.rpy:2296
translate Spanish demoend_bab5a485:

    # "Regardless, I stay put."
    "De todos modos, me quedo."

# game/script.rpy:2297
translate Spanish demoend_a20cefa7:

    # "..."
    "..."

# game/script.rpy:2298
translate Spanish demoend_4448f2c0:

    # me "Hey, do you need help finding the flashlights?"
    me "Oye, ¿necesitas ayuda para encontrar las linternas?"

# game/script.rpy:2299
translate Spanish demoend_a20cefa7_1:

    # "..."
    "..."

# game/script.rpy:2300
translate Spanish demoend_77d65967:

    # "No response."
    "Sin respuesta."

# game/script.rpy:2301
translate Spanish demoend_d74ffffe:

    # "What's taking Jacob so long?"
    "¿Por qué tarda tanto Jacob?"

# game/script.rpy:2307
translate Spanish shadowput_558bafac:

    # "Maybe he needs help, I don't wanna go too far though. Maybe something around here can help."
    "Tal vez necesita ayuda, no quiero ir demasiado lejos. Quizás algo por aquí pueda ayudar."

# game/script.rpy:2308
translate Spanish shadowput_b32ed641:

    # "I wave my arms in front of me, feeling for my surroundings."
    "Muevo los brazos frente a mí, tanteando lo que hay alrededor."

# game/script.rpy:2311
translate Spanish shadowput_4ed3f765:

    # me "...Jacob? Did you find the flashlights?"
    me "...¿Jacob? ¿Encontraste las linternas?"

# game/script.rpy:2312
translate Spanish shadowput_3820771a:

    # me "..."
    me "..."

# game/script.rpy:2313
translate Spanish shadowput_efa3a5ca:

    # me "Jacob? Are you there?"
    me "¿Jacob? ¿Estás ahí?"

# game/script.rpy:2314
translate Spanish shadowput_3813d0c3:

    # "I only hear my own voice within the room. I'm not imagining things...right?"
    "Solo escucho mi propia voz dentro de la habitación. No me estoy imaginando cosas ... ¿verdad?"

# game/script.rpy:2317
translate Spanish shadowput_f16df513:

    # me "Jacob? Hello!?"
    me "¿Jacob? ¿¡Hola!?"

# game/script.rpy:2318
translate Spanish shadowput_1fdf08ba:

    # "Is there someone else inside the house!?"
    "¿¡Hay alguien más dentro de la casa!?"

# game/script.rpy:2319
translate Spanish shadowput_bb9a5751:

    # "No, impossible, this guy's got locks all over his door..."
    "No, imposible, este tipo tiene cerraduras por toda su puerta ..."

# game/script.rpy:2320
translate Spanish shadowput_f6f3e354:

    # "It's nothing...my imagination is just making me hallucinate these sounds..."
    "No es nada ... mi imaginación me está haciendo alucinar estos sonidos ..."

# game/script.rpy:2321
translate Spanish shadowput_eb56ac4e:

    # "...Right!?"
    "...¿¡Verdad!?"

# game/script.rpy:2324
translate Spanish shadowput_26c6559f:

    # "Is something smelling me!?"
    "¿¡Algo me está oliendo!?"

# game/script.rpy:2325
translate Spanish shadowput_2b9515a1:

    # me "W-What the hell!? Jacob!? Is that you!?"
    me "¿¡Q-Qué demonios!? ¿¡Jacob!? ¿¡Eres tú!?"

# game/script.rpy:2357
translate Spanish theend_22b38917:

    # me "HELLO!? CAN ANYONE HEAR ME!? HELP!!!"
    me "¿¡HOLA!? ¿¡ALGUIEN ME OYE!? ¡¡¡AYUDA!!!"

# game/script.rpy:2368
translate Spanish lightningdeath_d84d9aa4:

    # "I know the storm is bad, but my house is literally next to his."
    "Sé que la tormenta es mala, pero mi casa está literalmente al lado de la suya."

# game/script.rpy:2369
translate Spanish lightningdeath_d5269921:

    # "I should go and take cover at my own home."
    "Debería ir a cubrirme en mi propia casa."

# game/script.rpy:2370
translate Spanish lightningdeath_03255c6b:

    # me "Don't worry Jacob, I'll be ok! See you later."
    me "No te preocupes Jacob, ¡estaré bien! Hasta luego."

# game/script.rpy:2380
translate Spanish lightningdeath_c6da6334:

    # "I take a few steps back into the rain."
    "Retrocedo unos pasos, de vuelta bajo la lluvia."

# game/script.rpy:2381
translate Spanish lightningdeath_bb257c7e:

    # j "[playerName] WAIT-"
    j "¡[playerName], ESPERA-"

# game/script.rpy:2385
translate Spanish lightningdeath_dddb97d2:

    # "A crashing burst of energy sends shockwaves through my entire body."
    "Un estallido atronador de energía envía ondas de choque por todo mi cuerpo."

# game/script.rpy:2386
translate Spanish lightningdeath_dc92a5b5:

    # "There was pain shooting through every single nerve, until eventually..."
    "El dolor me recorría cada nervio hasta que, finalmente..."

# game/script.rpy:2387
translate Spanish lightningdeath_03ef483c:

    # "Everything went numb."
    "Todo se entumeció."

translate Spanish strings:

    # game/script.rpy:124
    old "She/Her"
    new "Ella"

    # game/script.rpy:127
    old "He/Him"
    new "Él"

    # game/script.rpy:130
    old "They/Them"
    new "Elle"

    # game/script.rpy:154
    old "Open door"
    new "Abrir la puerta"

    # game/script.rpy:157
    old "Check peephole"
    new "Revisar la mirilla"

    # game/script.rpy:177
    old "Jacob"
    new "Jacob"

    # game/script.rpy:179
    old "Jeremy"
    new "Jeremy"

    # game/script.rpy:181
    old "Jack"
    new "Jack"

    # game/script.rpy:207
    old "Say goodbye"
    new "Decir adiós"

    # game/script.rpy:209
    old "Chat while he's here"
    new "Charlar mientras está aquí"

    # game/script.rpy:292
    old "Leave him alone"
    new "Dejarlo en paz"

    # game/script.rpy:294
    old "Approach him"
    new "Acercarse a él"

    # game/script.rpy:326
    old "Sure, I'd love to!"
    new "Claro, ¡me encantaría!"

    # game/script.rpy:328
    old "I can't tonight."
    new "No puedo esta noche."

    # game/script.rpy:405
    old "Check outside"
    new "Mirar afuera"

    # game/script.rpy:407
    old "Stay here"
    new "Quedarse aquí"

    # game/script.rpy:508
    old "Let it go"
    new "Dejarlo pasar"

    # game/script.rpy:510
    old "Speak up"
    new "Decir algo"

    # game/script.rpy:564
    old "Have breakfast"
    new "Desayunar"

    # game/script.rpy:566
    old "Skip breakfast"
    new "Saltarme el desayuno"

    # game/script.rpy:582
    old "Get to know him"
    new "Conocerlo mejor"

    # game/script.rpy:584
    old "Keep eating"
    new "Seguir comiendo"

    # game/script.rpy:860
    old "I will let you know."
    new "Te lo haré saber."

    # game/script.rpy:862
    old "I think I'll be fine."
    new "Creo que estaré bien."

    # game/script.rpy:937
    old "Were you taking pictures of me?"
    new "¿Me estabas tomando fotos?"

    # game/script.rpy:939
    old "What are you taking pictures of?"
    new "¿De qué estás tomando fotos?"

    # game/script.rpy:970
    old "Sure I'd love to!"
    new "¡Claro que sí, me encantaría!"

    # game/script.rpy:972
    old "Not right now."
    new "Ahora no."

    # game/script.rpy:1100
    old "Tell him off"
    new "Cantarle las cuarenta"

    # game/script.rpy:1102
    old "Ignore him"
    new "Ignorarlo"

    # game/script.rpy:1137
    old "Keep ignoring him"
    new "Seguir ignorándolo"

    # game/script.rpy:1139
    old "Give up"
    new "Ceder"

    # game/script.rpy:1205
    old "Accept friend request"
    new "Aceptar solicitud de amistad"

    # game/script.rpy:1207
    old "Ignore friend request"
    new "Ignorar la solicitud de amistad"

    # game/script.rpy:1320
    old "I need help looking for some printer ink"
    new "Necesito ayuda para buscar tinta de impresora"

    # game/script.rpy:1322
    old "I'm good"
    new "Estoy bien"

    # game/script.rpy:1539
    old "Answer it"
    new "Contestar"

    # game/script.rpy:1541
    old "Ignore it"
    new "Ignorarlo"

    # game/script.rpy:1547
    old "Answer normally"
    new "Contestar con normalidad"

    # game/script.rpy:1549
    old "Mess with the caller"
    new "Meterse con la persona que llama"

    # game/script.rpy:1793
    old "Go inside Jacob's house"
    new "Entrar en casa de Jacob"

    # game/script.rpy:1795
    old "Go back to your house"
    new "Volver a tu casa"

    # game/script.rpy:1845
    old "Vanilla Cake"
    new "Pastel de vainilla"

    # game/script.rpy:1847
    old "Chocolate Chip Cookies"
    new "Galletas con chispas de chocolate"

    # game/script.rpy:1849
    old "Strawberry Ice Cream"
    new "Helado de fresa"

    # game/script.rpy:1890
    old "Tell Jacob"
    new "Decirle a Jacob"

    # game/script.rpy:1892
    old "Wipe it off for him"
    new "Limpiárselo"

    # game/script.rpy:1997
    old "How's your dad?"
    new "¿Cómo está tu papá?"

    # game/script.rpy:1999
    old "What happened to Lucy?"
    new "¿Qué le pasó a Lucy?"

    # game/script.rpy:2001
    old "Who took the photo?"
    new "¿Quién tomó la foto?"

    # game/script.rpy:2081
    old "Is that Sarah?"
    new "¿Es esa Sarah?"

    # game/script.rpy:2083
    old "Who's that?"
    new "¿Quién es?"

    # game/script.rpy:2117
    old "I'll slow dance with you"
    new "Bailo un lento contigo"

    # game/script.rpy:2119
    old "What song would you slow dance to?"
    new "¿Qué canción elegirías para bailar un lento?"

    # game/script.rpy:2160
    old "Are you still nervous?"
    new "¿Sigues nervioso?"

    # game/script.rpy:2162
    old "You dance better than my prom date"
    new "Bailas mejor que mi pareja del baile de graduación"

    # game/script.rpy:2231
    old "I can't sing for shit"
    new "Canto fatal"

    # game/script.rpy:2233
    old "I'll try"
    new "Lo intentaré"

    # game/script.rpy:2303
    old "Stay put"
    new "Quedarse en el mismo sitio"

    # game/script.rpy:2327
    old "PANIC"
    new "PÁNICO"
    
    old "My name is..."
    new "Me llamo..."

