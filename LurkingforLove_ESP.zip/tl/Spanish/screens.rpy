﻿
# TODO: Translation updated at 2026-10-08 15:32

translate Spanish strings:

    # game/screens.rpy:252
    old "Back"
    new "Volver"

    # game/screens.rpy:253
    old "Skip"
    new "Omitir"

    # game/screens.rpy:254
    old "Save"
    new "Guardar"

    # game/screens.rpy:255
    old "Menu"
    new "Menú"

    # game/screens.rpy:296
    old "Start"
    new "Iniciar"

    # game/screens.rpy:300
    old "History"
    new "Historial"

    # game/screens.rpy:304
    old "Load"
    new "Cargar"

    # game/screens.rpy:306
    old "Preferences"
    new "Preferencias"

    # game/screens.rpy:310
    old "End Replay"
    new "Terminar repetición"

    # game/screens.rpy:314
    old "Main Menu"
    new "Menú principal"

    # game/screens.rpy:316
    old "About"
    new "Acerca de"

    # game/screens.rpy:321
    old "Help"
    new "Ayuda"

    # game/screens.rpy:327
    old "Quit"
    new "Salir"

    # game/screens.rpy:469
    old "Return"
    new "Regresar"

    # game/screens.rpy:553
    old "Version [config.version!t]\n"
    new "Versión [config.version!t]\n"

    # game/screens.rpy:559
    old "Made with {a=https://www.renpy.org/}Ren'Py{/a} [renpy.version_only].\n\n[renpy.license!t]"
    new "Hecho con {a=https://www.renpy.org/}Ren'Py{/a} [renpy.version_only].\n\n[renpy.license!t]"

    # game/screens.rpy:595
    old "Page {}"
    new "Página {}"

    # game/screens.rpy:595
    old "Automatic saves"
    new "Guardados automáticos"

    # game/screens.rpy:595
    old "Quick saves"
    new "Guardados rápidos"

    # game/screens.rpy:637
    old "{#file_time}%A, %B %d %Y, %H:%M"
    new "{#file_time}%A, %d de %B de %Y, %H:%M"

    # game/screens.rpy:637
    old "empty slot"
    new "Ranura vacía"

    # game/screens.rpy:654
    old "<"
    new "<"

    # game/screens.rpy:657
    old "{#auto_page}A"
    new "{#auto_page}A"

    # game/screens.rpy:660
    old "{#quick_page}Q"
    new "{#quick_page}R"

    # game/screens.rpy:666
    old ">"
    new ">"

    # game/screens.rpy:723
    old "Display"
    new "Pantalla"

    # game/screens.rpy:724
    old "Window"
    new "Ventana"

    # game/screens.rpy:725
    old "Fullscreen"
    new "Pantalla completa"

    # game/screens.rpy:730
    old "Unseen Text"
    new "Texto no leído"

    # game/screens.rpy:731
    old "After Choices"
    new "Después de las elecciones"

    # game/screens.rpy:732
    old "Transitions"
    new "Transiciones"

    # game/screens.rpy:745
    old "Text Speed"
    new "Velocidad del texto"

    # game/screens.rpy:749
    old "Auto-Forward Time"
    new "Tiempo de avance automático"

    # game/screens.rpy:756
    old "Music Volume"
    new "Volumen de la música"

    # game/screens.rpy:763
    old "Sound Volume"
    new "Volumen de los efectos"

    # game/screens.rpy:769
    old "Test"
    new "Probar"

    # game/screens.rpy:773
    old "Voice Volume"
    new "Volumen de las voces"

    # game/screens.rpy:784
    old "Mute All"
    new "Silenciar todo"

    # game/screens.rpy:903
    old "The dialogue history is empty."
    new "El historial de diálogos está vacío."

    # game/screens.rpy:971
    old "Keyboard"
    new "Teclado"

    # game/screens.rpy:972
    old "Mouse"
    new "Ratón"

    # game/screens.rpy:975
    old "Gamepad"
    new "Control"

    # game/screens.rpy:988
    old "Enter"
    new "Enter"

    # game/screens.rpy:989
    old "Advances dialogue and activates the interface."
    new "Avanza el diálogo y activa la interfaz."

    # game/screens.rpy:992
    old "Space"
    new "Espacio"

    # game/screens.rpy:993
    old "Advances dialogue without selecting choices."
    new "Avanza el diálogo sin seleccionar opciones."

    # game/screens.rpy:996
    old "Arrow Keys"
    new "Flechas"

    # game/screens.rpy:997
    old "Navigate the interface."
    new "Permiten navegar por la interfaz."

    # game/screens.rpy:1000
    old "Escape"
    new "Escape"

    # game/screens.rpy:1001
    old "Accesses the game menu."
    new "Abre el menú del juego."

    # game/screens.rpy:1004
    old "Ctrl"
    new "Ctrl"

    # game/screens.rpy:1005
    old "Skips dialogue while held down."
    new "Omite diálogos mientras se mantiene presionada."

    # game/screens.rpy:1008
    old "Tab"
    new "Tab"

    # game/screens.rpy:1009
    old "Toggles dialogue skipping."
    new "Activa o desactiva la omisión de diálogos."

    # game/screens.rpy:1012
    old "Page Up"
    new "Re Pág"

    # game/screens.rpy:1013
    old "Rolls back to earlier dialogue."
    new "Retrocede a diálogos anteriores."

    # game/screens.rpy:1016
    old "Page Down"
    new "Av Pág"

    # game/screens.rpy:1017
    old "Rolls forward to later dialogue."
    new "Avanza a diálogos posteriores."

    # game/screens.rpy:1021
    old "Hides the user interface."
    new "Oculta la interfaz."

    # game/screens.rpy:1025
    old "Takes a screenshot."
    new "Toma una captura de pantalla."

    # game/screens.rpy:1029
    old "Toggles assistive {a=https://www.renpy.org/l/voicing}self-voicing{/a}."
    new "Activa o desactiva la {a=https://www.renpy.org/l/voicing}lectura en voz alta{/a}."

    # game/screens.rpy:1033
    old "Opens the accessibility menu."
    new "Abre el menú de accesibilidad."

    # game/screens.rpy:1039
    old "Left Click"
    new "Clic izquierdo"

    # game/screens.rpy:1043
    old "Middle Click"
    new "Clic central"

    # game/screens.rpy:1047
    old "Right Click"
    new "Clic derecho"

    # game/screens.rpy:1051
    old "Mouse Wheel Up\nClick Rollback Side"
    new "Rueda del ratón arriba\nClic en el lado de retroceso"

    # game/screens.rpy:1055
    old "Mouse Wheel Down"
    new "Rueda del ratón abajo"

    # game/screens.rpy:1062
    old "Right Trigger\nA/Bottom Button"
    new "Gatillo derecho\nBotón A/inferior"

    # game/screens.rpy:1066
    old "Left Trigger\nLeft Shoulder"
    new "Gatillo izquierdo\nBotón superior izquierdo"

    # game/screens.rpy:1070
    old "Right Shoulder"
    new "Botón superior derecho"

    # game/screens.rpy:1075
    old "D-Pad, Sticks"
    new "Cruceta y palancas"

    # game/screens.rpy:1079
    old "Start, Guide"
    new "Inicio, Guía"

    # game/screens.rpy:1083
    old "Y/Top Button"
    new "Botón Y/superior"

    # game/screens.rpy:1086
    old "Calibrate"
    new "Calibrar"

    # game/screens.rpy:1151
    old "Yes"
    new "Sí"

    # game/screens.rpy:1152
    old "No"
    new "No"

    # game/screens.rpy:1198
    old "Skipping"
    new "Omitiendo"

    # game/screens.rpy:1396
    old "Gallery"
    new "Galería"

    # game/screens.rpy:1436
    old "Auto"
    new "Auto"

