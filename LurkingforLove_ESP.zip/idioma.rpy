init 999 python:

    def actualizar_genero():
        pronombre = getattr(renpy.store, "he", "he")

        if pronombre == "she":
            renpy.store.letra = "a"
            renpy.store.arti = "la"
            renpy.store.arti_2 = "una"

        elif pronombre == "they":
            renpy.store.letra = "e"
            renpy.store.arti = "le"
            renpy.store.arti_2 = "une"

        else:
            renpy.store.letra = "o"
            renpy.store.arti = "el"
            renpy.store.arti_2 = "un"

    def detectar_genero_es(label, abnormal):
        if label == "continue":
            actualizar_genero()

    config.label_callback = detectar_genero_es

label before_main_menu:
    $ actualizar_genero()
    return

label after_load:
    $ actualizar_genero()
    return

init 1000 python:
    renpy.game.preferences.language = "Spanish"
    
